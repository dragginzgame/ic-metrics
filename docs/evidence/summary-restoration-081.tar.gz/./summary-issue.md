## Defect

Released Metrics 0.8.0 admits `MeasurementSummary::from_parts` with count 2, total 20, maximum 10 and latest 0. No pair of observations can have those fields: the other observation would need to exceed the admitted maximum. Aggregate-only consistency is insufficient once the ordered latest sample is restored.

The optional V1 store delegates to that constructor, so the same inconsistent record currently loads as valid and can be overwritten by a later checkpoint.

## Owning correction

For an exact nonempty count, additionally require `total <= (samples - 1) * maximum + latest`. Retain `MeasurementStateError::InvalidLatest`, the canonical core admission owner, const/no_std and wide arithmetic. A clipped overflowed count cannot impose that upper bound. Recording, valid state, units, identities, wire bytes and host-owned reset/lifecycle policy stay unchanged; no storage reset or compatibility reader is needed.

## Qualification

Focused core and reopened-map regressions reproduce the defect before the correction. Verify exact wide/count-cap boundaries, valid recorded sequences and post-count-overflow restoration. The stored-record test must reject both load and save with the typed error while preserving the original bytes. Finish with native/Wasm Clippy, full CI and all documented package-floor gates. This is local arithmetic/corruption admission; it supplies no IC performance claim or consumer native acceptance.
