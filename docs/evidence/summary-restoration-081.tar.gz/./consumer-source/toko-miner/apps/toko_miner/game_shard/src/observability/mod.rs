//! Public Game Shard telemetry and controller-only operational metrics.

#[cfg(feature = "metrics")]
mod database_metrics;

#[cfg(feature = "metrics")]
pub(crate) mod action_metrics;

use std::{cell::RefCell, time::Duration};

use crate::design::{
    CatalogRecipe, CelestialObject, Creature, Hazard, Item, Location, Machine, MinionType,
    NftCollection, NftProject, NftToken, PlanetCreature, PlanetHazard, Resource, Robot,
    RobotAppearanceOption, Rocket, StarSystem, User, UserPrincipal,
};
use candid::{CandidType, Deserialize};
use ic_timers::{
    InactiveReason, MeasurementSummary, MemoryPageSummary, OrdinaryRuntimeStateSnapshot,
    TimerCadence, TimerCompletion, TimerDirectiveSnapshot, TimerIdentity, TimerInventorySnapshot,
    TimerLastOutcome, TimerRuntimeStateSnapshot, WatchdogAttemptStatus, WatchdogDecision,
    WatchdogReconcileState, WatchdogRegistration, WatchdogRunResult, WatchdogRuntimeStateSnapshot,
    reconcile_watchdog, timer_inventory,
};
use icydb::db::TypedOperationError;
use icydb::traits::EntitySource as _;

const OBSERVABILITY_REFRESH_INTERVAL: Duration = Duration::from_mins(5);

#[derive(CandidType, Clone, Debug, Eq, PartialEq)]
pub struct TableMetric {
    pub name: String,
    pub rows: u64,
}

#[derive(CandidType, Clone, Debug, Eq, PartialEq)]
pub struct EndpointMetric {
    pub name: String,
    pub mode: String,
    pub access: String,
    pub owner: String,
}

#[derive(CandidType, Clone, Debug, Eq, PartialEq)]
pub struct GameShardObservabilitySnapshot {
    pub package_version: String,
    pub canister_version: u64,
    pub cycles: u128,
    pub stable_memory_pages: u64,
    pub stable_memory_bytes: u64,
    pub observed_at_ns: u64,
    pub cache_refreshed_at_ns: u64,
    pub cache_refresh_interval_ns: u64,
    pub cache_refresh_instructions: u64,
    pub cache_refresh_failures: u64,
    pub last_refresh_error: Option<GameShardObservabilityError>,
    pub tables: Vec<TableMetric>,
    pub endpoints: Vec<EndpointMetric>,
}

/// Coarse service state safe to expose without revealing operational costs.
#[derive(CandidType, Clone, Copy, Debug, Eq, PartialEq)]
pub enum GameShardPublicStatus {
    Available,
    Degraded,
}

/// Deliberately public product telemetry without cycles or instruction measurements.
#[derive(CandidType, Clone, Debug, Eq, PartialEq)]
pub struct GameShardPublicMetricsSnapshot {
    pub package_version: String,
    pub canister_version: u64,
    pub status: GameShardPublicStatus,
    pub observed_at_ns: u64,
    pub cache_refreshed_at_ns: u64,
    pub tables: Vec<TableMetric>,
    pub endpoints: Vec<EndpointMetric>,
}

#[derive(CandidType, Clone, Debug, Eq, PartialEq)]
pub struct ObservabilityRefreshReceipt {
    pub refreshed_at_ns: u64,
    pub refresh_instructions: u64,
    pub tables: Vec<TableMetric>,
}

#[derive(CandidType, Clone, Debug, Deserialize, Eq, PartialEq)]
pub enum GameShardObservabilityError {
    NotController,
    CacheNotReady,
    CacheBusy,
    TimerUnavailable,
    Database { code: u16 },
    Adapter,
}

#[derive(CandidType, Clone, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerInventoryMetric {
    pub epoch_canister_version: u64,
    pub epoch_started_at_ns: u64,
    pub observed_at_ns: u64,
    pub timers: Vec<TimerMetric>,
}

#[derive(CandidType, Clone, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerMetric {
    pub owner: String,
    pub subsystem: String,
    pub name: String,
    pub policy: String,
    pub configured_cadence_ns: Option<u64>,
    pub lifetime: String,
    pub state: String,
    pub inactive_reason: Option<String>,
    pub registration: String,
    pub condition: String,
    pub scheduling_mode: String,
    pub latest_directive: Option<String>,
    pub latest_requested_delay_ns: Option<u64>,
    pub latest_armed_delay_ns: Option<u64>,
    pub next_due_at_ns: Option<u64>,
    pub generation: Option<u64>,
    pub watchdog_attempt_generation: Option<u64>,
    pub watchdog_attempt_status: Option<String>,
    pub last_outcome: Option<String>,
    pub last_work_count: Option<u64>,
    pub last_success_at_ns: Option<u64>,
    pub last_failure_at_ns: Option<u64>,
    pub last_unacknowledged_at_ns: Option<u64>,
    pub consecutive_expected_failures: u64,
    pub counters: TimerCounterMetric,
    pub scheduler_performance: TimerPerformanceMetric,
    pub work_performance: TimerPerformanceMetric,
}

#[derive(CandidType, Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerCounterMetric {
    pub schedule_requests: u64,
    pub wakeups_armed: u64,
    pub work_dispatched: u64,
    pub scheduler_started: u64,
    pub work_started: u64,
    pub work_completed: u64,
    pub succeeded: u64,
    pub no_work: u64,
    pub retryable_failure: u64,
    pub invariant_failure: u64,
    pub cancelled: u64,
    pub stale_wakeups: u64,
    pub stale_work: u64,
    pub coalesced: u64,
    pub unacknowledged: u64,
}

#[derive(CandidType, Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerPerformanceMetric {
    pub instructions: TimerMeasurementMetric,
    pub memory_pages: TimerMemoryMetric,
}

#[derive(CandidType, Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerMeasurementMetric {
    pub samples: u64,
    pub total: u128,
    pub latest: Option<u64>,
    pub maximum: Option<u64>,
}

#[derive(CandidType, Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
pub struct TimerMemoryMetric {
    pub samples: u64,
    pub latest: Option<TimerMemorySampleMetric>,
    pub maximum_wasm_growth_pages: Option<u64>,
    pub maximum_stable_growth_pages: Option<u64>,
}

// The suffix keeps the unit explicit at the public Candid boundary.
#[derive(CandidType, Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
#[expect(
    clippy::struct_field_names,
    reason = "the public metric fields retain their explicit page unit"
)]
pub struct TimerMemorySampleMetric {
    pub wasm_start_pages: u64,
    pub wasm_end_pages: u64,
    pub stable_start_pages: u64,
    pub stable_end_pages: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct CachedTableSnapshot {
    refreshed_at_ns: u64,
    refresh_instructions: u64,
    tables: Vec<TableMetric>,
}

#[derive(Default)]
struct ObservabilityCache {
    snapshot: Option<CachedTableSnapshot>,
    last_error: Option<GameShardObservabilityError>,
    refresh_failures: u64,
}

thread_local! {
    static CACHE: RefCell<ObservabilityCache> = RefCell::new(ObservabilityCache::default());
    static REFRESH_TIMER: RefCell<Option<WatchdogRegistration>> = const { RefCell::new(None) };
}

#[cfg(all(target_arch = "wasm32", target_os = "unknown"))]
fn instruction_counter() -> u64 {
    ic_cdk::api::instruction_counter()
}

// Native declaration and unit-test builds do not measure IC instructions.
#[cfg(not(all(target_arch = "wasm32", target_os = "unknown")))]
const fn instruction_counter() -> u64 {
    0
}

#[cfg(not(test))]
fn now_ns() -> u64 {
    ic_cdk::api::time()
}

#[cfg(test)]
const fn now_ns() -> u64 {
    0
}

fn operation_error(error: TypedOperationError) -> GameShardObservabilityError {
    match error {
        TypedOperationError::Database(error) => GameShardObservabilityError::Database {
            code: error.code().raw(),
        },
        TypedOperationError::Adapter(_) => GameShardObservabilityError::Adapter,
    }
}

// Counts use database-owned cardinality; missing metadata remains a typed error.
macro_rules! table_count {
    ($database:expr, $entity:ty) => {{
        TableMetric {
            name: <$entity>::ENTITY.to_owned(),
            rows: $database
                .query::<$entity>()
                .map_err(operation_error)?
                .execute_exact_count()
                .map_err(operation_error)?,
        }
    }};
}

fn endpoint(name: &str, mode: &str, access: &str, owner: &str) -> EndpointMetric {
    EndpointMetric {
        name: name.to_owned(),
        mode: mode.to_owned(),
        access: access.to_owned(),
        owner: owner.to_owned(),
    }
}

type EndpointDefinition = (&'static str, &'static str, &'static str, &'static str);

const ENDPOINT_DEFINITIONS: &[EndpointDefinition] = &[
    ("canic_command", "update", "policy-filtered", "Canic"),
    ("canic_public_status", "query", "public", "Canic"),
    ("canic_observability", "query", "controller", "Canic"),
    ("canic_control_status", "query", "root", "Canic"),
    (
        "canic_admission_status",
        "query",
        "controller or root",
        "Canic",
    ),
    ("icrc10_supported_standards", "query", "public", "Canic"),
    ("game_shard_public_metrics", "query", "public", "Toko Miner"),
    ("game_shard_database_demo", "query", "public", "Toko Miner"),
    (
        "game_shard_observability",
        "query",
        "controller",
        "Toko Miner",
    ),
    (
        "game_shard_timer_inventory",
        "query",
        "controller",
        "Toko Miner",
    ),
    (
        "toko_miner_authorize_login",
        "update",
        "fleet-admission-gated",
        "Toko Miner",
    ),
    ("bootstrap_user", "update", "parent-only", "Toko Miner"),
    ("icydb_metrics", "query", "controller", "IcyDB"),
    ("icydb_metrics_reset", "update", "controller", "IcyDB"),
    ("icydb_schema", "query", "controller", "IcyDB"),
    ("list_industry_catalog", "query", "rank-gated", "Toko Miner"),
    ("list_minerals", "query", "rank-gated", "Toko Miner"),
    (
        "list_nft_collections",
        "query",
        "spoiler-gated",
        "Toko Miner",
    ),
    ("list_celestial_objects", "query", "public", "Toko Miner"),
    ("list_planet_encounters", "query", "public", "Toko Miner"),
    (
        "list_robot_appearance_catalogue",
        "query",
        "public",
        "Toko Miner",
    ),
    (
        "get_my_robot",
        "query",
        "fleet-admission-gated",
        "Toko Miner",
    ),
    (
        "get_my_gameplay",
        "query",
        "fleet-admission-gated",
        "Toko Miner",
    ),
    (
        "get_my_rockets",
        "query",
        "fleet-admission-gated",
        "Toko Miner",
    ),
    (
        "set_my_admin_see_everything",
        "update",
        "admin-user",
        "Toko Miner",
    ),
    (
        "execute_actions",
        "update",
        "fleet-admission-gated",
        "Toko Miner",
    ),
    (
        "refresh_observability_cache",
        "update",
        "controller",
        "Toko Miner",
    ),
];

fn public_endpoints() -> Vec<EndpointMetric> {
    ENDPOINT_DEFINITIONS
        .iter()
        .map(|&(name, mode, access, owner)| endpoint(name, mode, access, owner))
        .collect()
}

fn build_table_snapshot() -> Result<CachedTableSnapshot, GameShardObservabilityError> {
    let started = instruction_counter();
    let database = crate::db().map_err(|error| GameShardObservabilityError::Database {
        code: error.code().raw(),
    })?;
    let tables = vec![
        table_count!(database, User),
        table_count!(database, UserPrincipal),
        table_count!(database, Robot),
        table_count!(database, RobotAppearanceOption),
        table_count!(database, Rocket),
        table_count!(database, Item),
        table_count!(database, Machine),
        table_count!(database, Resource),
        table_count!(database, CatalogRecipe),
        table_count!(database, NftProject),
        table_count!(database, NftCollection),
        table_count!(database, NftToken),
        table_count!(database, Creature),
        table_count!(database, PlanetCreature),
        table_count!(database, Hazard),
        table_count!(database, PlanetHazard),
        table_count!(database, MinionType),
        table_count!(database, StarSystem),
        table_count!(database, CelestialObject),
        table_count!(database, Location),
    ];
    Ok(CachedTableSnapshot {
        refreshed_at_ns: now_ns(),
        refresh_instructions: instruction_counter().saturating_sub(started),
        tables,
    })
}

fn commit_refresh(
    result: Result<CachedTableSnapshot, GameShardObservabilityError>,
) -> Result<CachedTableSnapshot, GameShardObservabilityError> {
    CACHE.with(|slot| {
        let Ok(mut cache) = slot.try_borrow_mut() else {
            return Err(GameShardObservabilityError::CacheBusy);
        };
        match result {
            Ok(snapshot) => {
                cache.snapshot = Some(snapshot.clone());
                cache.last_error = None;
                Ok(snapshot)
            }
            Err(error) => {
                cache.refresh_failures = cache.refresh_failures.saturating_add(1);
                cache.last_error = Some(error.clone());
                Err(error)
            }
        }
    })
}

fn refresh_from_timer() -> WatchdogRunResult {
    let result = icydb::db::with_request_execution(build_table_snapshot);
    let completion = match commit_refresh(result) {
        Ok(snapshot) => TimerCompletion::success(
            u64::try_from(snapshot.tables.len()).expect("bounded table count fits u64"),
        ),
        Err(_) => TimerCompletion::retryable_failure(0),
    };
    WatchdogRunResult::new(completion, WatchdogDecision::Continue)
}

fn refresh_cache() -> Result<ObservabilityRefreshReceipt, GameShardObservabilityError> {
    commit_refresh(build_table_snapshot()).map(|snapshot| ObservabilityRefreshReceipt {
        refreshed_at_ns: snapshot.refreshed_at_ns,
        refresh_instructions: snapshot.refresh_instructions,
        tables: snapshot.tables,
    })
}

/// Refresh the cache after the Game Shard has reconciled its system fixtures.
pub(crate) fn refresh_after_system_fixtures()
-> Result<ObservabilityRefreshReceipt, GameShardObservabilityError> {
    icydb::db::with_request_execution(refresh_cache)
}

fn refresh_timer_identity() -> TimerIdentity {
    TimerIdentity::try_new("toko-miner", "observability", "cache-refresh")
        .unwrap_or_else(|_| ic_cdk::trap("observability timer identity is invalid"))
}

/// Reconstruct the retained observability refresh timer after IcyDB lifecycle work.
pub(crate) fn initialize() {
    #[cfg(all(feature = "metrics", not(test)))]
    database_metrics::initialize();
    let identity = refresh_timer_identity();
    let cadence = TimerCadence::new(OBSERVABILITY_REFRESH_INTERVAL)
        .unwrap_or_else(|_| ic_cdk::trap("observability timer cadence is invalid"));
    let result = REFRESH_TIMER.with(|slot| {
        let Ok(mut registration) = slot.try_borrow_mut() else {
            ic_cdk::trap("observability timer registration is already borrowed");
        };
        reconcile_watchdog(
            &mut registration,
            &identity,
            cadence,
            WatchdogReconcileState::Scheduled,
            |_context| refresh_from_timer(),
        )
    });
    if result.is_err() {
        ic_cdk::trap("observability timer reconciliation failed");
    }
}

fn cached_table_state() -> Result<
    (
        CachedTableSnapshot,
        Option<GameShardObservabilityError>,
        u64,
    ),
    GameShardObservabilityError,
> {
    let (cached, last_refresh_error, cache_refresh_failures) = CACHE.with(|slot| {
        let Ok(cache) = slot.try_borrow() else {
            return Err(GameShardObservabilityError::CacheBusy);
        };
        let cached = cache.snapshot.clone().ok_or_else(|| {
            cache
                .last_error
                .clone()
                .unwrap_or(GameShardObservabilityError::CacheNotReady)
        })?;
        Ok((cached, cache.last_error.clone(), cache.refresh_failures))
    })?;
    Ok((cached, last_refresh_error, cache_refresh_failures))
}

fn public_snapshot() -> Result<GameShardPublicMetricsSnapshot, GameShardObservabilityError> {
    let (cached, last_refresh_error, _) = cached_table_state()?;
    Ok(GameShardPublicMetricsSnapshot {
        package_version: env!("CARGO_PKG_VERSION").to_owned(),
        canister_version: ic_cdk::api::canister_version(),
        status: if last_refresh_error.is_some() {
            GameShardPublicStatus::Degraded
        } else {
            GameShardPublicStatus::Available
        },
        observed_at_ns: now_ns(),
        cache_refreshed_at_ns: cached.refreshed_at_ns,
        tables: cached.tables,
        endpoints: public_endpoints(),
    })
}

fn cached_snapshot() -> Result<GameShardObservabilitySnapshot, GameShardObservabilityError> {
    let (cached, last_refresh_error, cache_refresh_failures) = cached_table_state()?;
    let stable_memory_pages = ic_cdk::api::stable_size();
    Ok(GameShardObservabilitySnapshot {
        package_version: env!("CARGO_PKG_VERSION").to_owned(),
        canister_version: ic_cdk::api::canister_version(),
        cycles: ic_cdk::api::canister_cycle_balance(),
        stable_memory_pages,
        stable_memory_bytes: stable_memory_pages.saturating_mul(65_536),
        observed_at_ns: now_ns(),
        cache_refreshed_at_ns: cached.refreshed_at_ns,
        cache_refresh_interval_ns: u64::try_from(OBSERVABILITY_REFRESH_INTERVAL.as_nanos())
            .expect("five-minute cadence fits u64 nanoseconds"),
        cache_refresh_instructions: cached.refresh_instructions,
        cache_refresh_failures,
        last_refresh_error,
        tables: cached.tables,
        endpoints: public_endpoints(),
    })
}

fn require_controller() -> Result<(), GameShardObservabilityError> {
    let caller = ic_cdk::api::msg_caller();
    controller_access(ic_cdk::api::is_controller(&caller))
}

const fn controller_access(is_controller: bool) -> Result<(), GameShardObservabilityError> {
    if is_controller {
        Ok(())
    } else {
        Err(GameShardObservabilityError::NotController)
    }
}

const fn measurement_metric(summary: MeasurementSummary) -> TimerMeasurementMetric {
    TimerMeasurementMetric {
        samples: summary.samples(),
        total: summary.total(),
        latest: summary.latest(),
        maximum: summary.maximum(),
    }
}

fn memory_metric(summary: MemoryPageSummary) -> TimerMemoryMetric {
    TimerMemoryMetric {
        samples: summary.samples(),
        latest: summary.latest().map(|sample| TimerMemorySampleMetric {
            wasm_start_pages: sample.start().wasm_pages(),
            wasm_end_pages: sample.end().wasm_pages(),
            stable_start_pages: sample.start().stable_pages(),
            stable_end_pages: sample.end().stable_pages(),
        }),
        maximum_wasm_growth_pages: summary.maximum_wasm_growth_pages(),
        maximum_stable_growth_pages: summary.maximum_stable_growth_pages(),
    }
}

fn timer_performance_metric(
    instructions: MeasurementSummary,
    memory_pages: MemoryPageSummary,
) -> TimerPerformanceMetric {
    TimerPerformanceMetric {
        instructions: measurement_metric(instructions),
        memory_pages: memory_metric(memory_pages),
    }
}

fn directive_label(directive: TimerDirectiveSnapshot) -> String {
    match directive {
        TimerDirectiveSnapshot::Stop => "stop".to_owned(),
        TimerDirectiveSnapshot::ContinueImmediately => "continue_immediately".to_owned(),
        TimerDirectiveSnapshot::RetryAfter { delay_ns } => format!("retry_after:{delay_ns}"),
        TimerDirectiveSnapshot::ScheduleAt { deadline_ns } => {
            format!("schedule_at:{deadline_ns}")
        }
        TimerDirectiveSnapshot::RecurAfterCompletion => "recur_after_completion".to_owned(),
    }
}

fn inactive_reason_label(reason: InactiveReason) -> String {
    match reason {
        InactiveReason::NeverScheduled => "never_scheduled".to_owned(),
        InactiveReason::Stopped => "stopped".to_owned(),
        InactiveReason::Cancelled => "cancelled".to_owned(),
        InactiveReason::Abandoned => "abandoned".to_owned(),
        InactiveReason::InvariantFailure => "invariant_failure".to_owned(),
        InactiveReason::ControlFailure(failure) => {
            format!("control_failure:{}", failure.label())
        }
    }
}

fn timer_state(
    state: TimerRuntimeStateSnapshot,
) -> (String, Option<String>, Option<u64>, Option<String>) {
    match state {
        TimerRuntimeStateSnapshot::Inactive { reason } => (
            "inactive".to_owned(),
            Some(inactive_reason_label(reason)),
            None,
            None,
        ),
        TimerRuntimeStateSnapshot::Ordinary(OrdinaryRuntimeStateSnapshot::Scheduled { .. }) => {
            ("ordinary_scheduled".to_owned(), None, None, None)
        }
        TimerRuntimeStateSnapshot::Ordinary(OrdinaryRuntimeStateSnapshot::Running { .. }) => {
            ("ordinary_running".to_owned(), None, None, None)
        }
        TimerRuntimeStateSnapshot::Watchdog(WatchdogRuntimeStateSnapshot::Scheduled { .. }) => {
            ("watchdog_scheduled".to_owned(), None, None, None)
        }
        TimerRuntimeStateSnapshot::Watchdog(WatchdogRuntimeStateSnapshot::AwaitingWork {
            successor_generation,
            attempt_status,
            ..
        }) => (
            "watchdog_awaiting_work".to_owned(),
            None,
            Some(successor_generation),
            Some(
                match attempt_status {
                    WatchdogAttemptStatus::Dispatched => "dispatched",
                    WatchdogAttemptStatus::Running => "running",
                }
                .to_owned(),
            ),
        ),
    }
}

fn last_outcome_label(outcome: TimerLastOutcome) -> String {
    match outcome {
        TimerLastOutcome::Completed(completion) => completion.label().to_owned(),
        TimerLastOutcome::Unacknowledged => "unacknowledged".to_owned(),
    }
}

fn timer_metric(snapshot: &ic_timers::TimerSnapshot) -> TimerMetric {
    let identity = snapshot.identity();
    let policy = snapshot.policy();
    let observability = snapshot.observability();
    let outcomes = observability.outcomes();
    let counters = observability.counters();
    let performance = observability.performance();
    let (state, inactive_reason, watchdog_attempt_generation, watchdog_attempt_status) =
        timer_state(snapshot.state());
    TimerMetric {
        owner: identity.owner().to_owned(),
        subsystem: identity.subsystem().to_owned(),
        name: identity.name().to_owned(),
        policy: policy.label().to_owned(),
        configured_cadence_ns: policy.cadence().map(TimerCadence::as_nanos),
        lifetime: match snapshot.lifetime() {
            ic_timers::DeclarationLifetime::Retained => "retained",
            ic_timers::DeclarationLifetime::RemoveWhenStopped => "remove_when_stopped",
        }
        .to_owned(),
        state,
        inactive_reason,
        registration: snapshot.registration_status().label().to_owned(),
        condition: snapshot.process_condition().label().to_owned(),
        scheduling_mode: snapshot.scheduling_mode().label().to_owned(),
        latest_directive: snapshot.latest_directive().map(directive_label),
        latest_requested_delay_ns: snapshot.latest_requested_delay_ns(),
        latest_armed_delay_ns: snapshot.latest_armed_delay_ns(),
        next_due_at_ns: snapshot.next_deadline_ns(),
        generation: snapshot.generation(),
        watchdog_attempt_generation,
        watchdog_attempt_status,
        last_outcome: outcomes.last_outcome().map(last_outcome_label),
        last_work_count: outcomes.last_work_count(),
        last_success_at_ns: outcomes.last_success_at_ns(),
        last_failure_at_ns: outcomes.last_failure_at_ns(),
        last_unacknowledged_at_ns: outcomes.last_unacknowledged_at_ns(),
        consecutive_expected_failures: outcomes.consecutive_expected_failures(),
        counters: TimerCounterMetric {
            schedule_requests: counters.schedule_requests(),
            wakeups_armed: counters.wakeups_armed(),
            work_dispatched: counters.work_dispatched(),
            scheduler_started: counters.scheduler_started(),
            work_started: counters.work_started(),
            work_completed: counters.work_completed(),
            succeeded: counters.succeeded(),
            no_work: counters.no_work(),
            retryable_failure: counters.retryable_failure(),
            invariant_failure: counters.invariant_failure(),
            cancelled: counters.cancelled(),
            stale_wakeups: counters.stale_wakeups(),
            stale_work: counters.stale_work(),
            coalesced: counters.coalesced(),
            unacknowledged: counters.unacknowledged(),
        },
        scheduler_performance: timer_performance_metric(
            performance.scheduler_instructions(),
            performance.scheduler_memory_pages(),
        ),
        work_performance: timer_performance_metric(
            performance.work_instructions(),
            performance.work_memory_pages(),
        ),
    }
}

fn timer_inventory_metric(inventory: TimerInventorySnapshot) -> TimerInventoryMetric {
    let epoch = inventory.epoch();
    TimerInventoryMetric {
        epoch_canister_version: epoch.canister_version(),
        epoch_started_at_ns: epoch.started_at_ns(),
        observed_at_ns: now_ns(),
        timers: inventory
            .into_timers()
            .into_iter()
            .map(|snapshot| timer_metric(&snapshot))
            .collect(),
    }
}

/// Return the coarse public product telemetry snapshot.
#[ic_cdk::query]
fn game_shard_public_metrics() -> Result<GameShardPublicMetricsSnapshot, GameShardObservabilityError>
{
    public_snapshot()
}

/// Return exact operational measurements to a controller.
#[ic_cdk::query]
fn game_shard_observability() -> Result<GameShardObservabilitySnapshot, GameShardObservabilityError>
{
    require_controller()?;
    cached_snapshot()
}

/// Return the bounded live timer inventory to a controller.
#[ic_cdk::query]
fn game_shard_timer_inventory() -> Result<TimerInventoryMetric, GameShardObservabilityError> {
    require_controller()?;
    timer_inventory()
        .map(timer_inventory_metric)
        .map_err(|_| GameShardObservabilityError::TimerUnavailable)
}

/// Refresh the expensive table counters immediately after controlled deployment work.
#[icydb::request_execution]
#[ic_cdk::update]
fn refresh_observability_cache() -> Result<ObservabilityRefreshReceipt, GameShardObservabilityError>
{
    require_controller()?;
    refresh_cache()
}

#[cfg(test)]
mod tests {
    use super::{
        ENDPOINT_DEFINITIONS, GameShardObservabilityError, MeasurementSummary, NftToken,
        TimerMeasurementMetric, build_table_snapshot, controller_access, measurement_metric,
        operation_error,
    };
    use crate::design::fixture::nft_token_preview_fixtures;
    use crate::design::{NftCollection, NftProject};
    use icydb::traits::EntitySource as _;

    #[test]
    fn timer_instruction_totals_remain_wide_through_candid() {
        let mut summary = MeasurementSummary::default();
        summary.record(u64::MAX);
        summary.record(1);
        let metric = measurement_metric(summary);
        assert_eq!(metric.samples, 2);
        assert_eq!(metric.total, u128::from(u64::MAX) + 1);
        assert_eq!(metric.latest, Some(1));
        assert_eq!(metric.maximum, Some(u64::MAX));
        let wire = candid::encode_one(metric).expect("wide timer Candid");
        let decoded: TimerMeasurementMetric = candid::decode_one(&wire).expect("wide timer reply");
        assert_eq!(decoded, metric);
    }

    #[test]
    fn database_failures_retain_typed_codes() {
        use icydb::{Error, ErrorCode, ErrorOrigin, db::TypedOperationError};

        for code in [
            ErrorCode::QUERY_EXACT_COUNT_METADATA_UNAVAILABLE,
            ErrorCode::RUNTIME_UNSUPPORTED,
            ErrorCode::QUERY_READ_UNBOUNDED_FULL_SCAN_REJECTED,
        ] {
            let error =
                TypedOperationError::Database(Error::from_error_code(code, ErrorOrigin::Query));
            assert_eq!(
                operation_error(error),
                GameShardObservabilityError::Database { code: code.raw() }
            );
        }
    }

    #[test]
    fn protected_metrics_require_controller_authority() {
        assert_eq!(controller_access(true), Ok(()));
        assert_eq!(
            controller_access(false),
            Err(GameShardObservabilityError::NotController)
        );

        for protected_name in [
            "game_shard_observability",
            "game_shard_timer_inventory",
            "refresh_observability_cache",
            "icydb_metrics",
            "icydb_schema",
            "icydb_metrics_reset",
        ] {
            let (_, _, access, _) = ENDPOINT_DEFINITIONS
                .iter()
                .find(|(name, _, _, _)| *name == protected_name)
                .expect("protected metric should remain in the endpoint inventory");
            assert_eq!(*access, "controller");
        }

        let (_, mode, access, owner) = ENDPOINT_DEFINITIONS
            .iter()
            .find(|(name, _, _, _)| *name == "bootstrap_user")
            .expect("parent bootstrap should remain in the endpoint inventory");
        assert_eq!(
            (*mode, *access, *owner),
            ("update", "parent-only", "Toko Miner")
        );
    }

    #[test]
    fn cached_table_refresh_counts_empty_tables() {
        crate::__icydb_generated::__drive_native_database_for_tests()
            .expect("fresh native database startup should complete");

        icydb::db::with_request_execution(|| {
            let snapshot =
                build_table_snapshot().expect("empty database metrics should remain readable");
            for name in [NftProject::ENTITY, NftCollection::ENTITY, NftToken::ENTITY] {
                assert!(snapshot.tables.iter().any(|table| table.name == name));
            }
            assert!(snapshot.tables.iter().all(|table| table.rows == 0));
        });
    }

    #[test]
    fn cached_table_refresh_counts_seeded_catalogues() {
        crate::__icydb_generated::__drive_native_database_for_tests()
            .expect("fresh native database startup should complete");

        icydb::db::with_request_execution(|| {
            crate::mineral::reconcile_mineral_fixtures().expect("Mineral fixtures should load");
            crate::industry::reconcile_industry_fixtures().expect("Industry fixtures should load");
            crate::nft_collection::reconcile_nft_collection_fixtures_for_tests()
                .expect("collection fixtures should load");
        });
        icydb::db::with_request_execution(|| {
            let snapshot = build_table_snapshot().expect("database metrics should remain readable");
            let projects = snapshot
                .tables
                .iter()
                .find(|table| table.name == NftProject::ENTITY)
                .expect("Project table metric should exist");
            assert_eq!(
                projects.rows,
                u64::try_from(crate::design::fixture::NFT_PROJECT_FIXTURES.len())
                    .expect("fixture count fits u64")
            );
            let nft_tokens = snapshot
                .tables
                .iter()
                .find(|table| table.name == NftToken::ENTITY)
                .expect("NftToken table metric should exist");
            assert_eq!(
                nft_tokens.rows,
                u64::try_from(nft_token_preview_fixtures().len()).expect("fixture count fits u64")
            );
        });
    }
}
