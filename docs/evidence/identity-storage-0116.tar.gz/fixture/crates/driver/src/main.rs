//! Frozen matched IC comparison; actual cycles include complete update/setup costs.
use candid::{Principal, decode_args, encode_args};
use ic_testkit::pic::{PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use std::{collections::BTreeMap, error::Error, fs, io::Write, path::PathBuf, time::Duration};
fn main() -> Result<(), Box<dyn Error>> {
    let root = PathBuf::from(std::env::args_os().nth(1).ok_or("root required")?);
    let output = PathBuf::from(std::env::args_os().nth(2).ok_or("output required")?);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new().with_application_subnet().try_build(config)?;
    let mut costs = fs::File::create(output.join("costs.csv"))?;
    writeln!(costs, "variant,kernel,n,case,iterations,repeat,instructions,cycles,sink")?;
    let mut expected = BTreeMap::new();
    for variant in ["baseline", "candidate"] {
        for kernel in ["identity", "decode"] {
            let id = pic.create_canister();
            pic.add_cycles(id, 100_000_000_000_000);
            pic.install_canister(id, fs::read(root.join(format!("{variant}-{kernel}.wasm")))?, encode_args(())?, None);
            let bounds: &[u16] = if kernel == "restore" { &[0, 4, 256] } else { &[4] };
            for &n in bounds {
                let cases = if kernel == "identity" { 16 } else { 32 };
                for case in 0_u8..cases {
                    for iterations in [0_u32, 128] {
                        for repeat in 0..3 {
                            let balance = pic.cycle_balance(id);
                            let reply = pic.update_call(id, Principal::anonymous(), "compare", encode_args((n, case, iterations))?)
                                .map_err(|error| format!("{error:?}"))?;
                            let (instructions, sink): (u64, u128) = decode_args(&reply)?;
                            let key = (kernel, n, case, iterations, repeat);
                            if variant == "baseline" { expected.insert(key, sink); }
                            else if expected.get(&key) != Some(&sink) { return Err("projection mismatch".into()); }
                            writeln!(costs, "{variant},{kernel},{n},{case},{iterations},{repeat},{instructions},{},{sink}", balance - pic.cycle_balance(id))?;
                        }
                    }
                }
            }
        }
    }
    Ok(())
}
