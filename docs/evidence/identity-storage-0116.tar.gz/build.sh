#!/usr/bin/env bash
set -euo pipefail
export RUSTUP_AUTO_INSTALL=0
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${METRICS_TARGET_DIR:?Use the owning Metrics target directory}"
# Resolve workspace-relative dep-info from this source tree, including readback
# outside the repository with a reused target directory.
cd "$root/fixture"
mkdir -p "$METRICS_TARGET_DIR"
build_dir="$(mktemp -d "$METRICS_TARGET_DIR/identity-build.XXXXXX")"
for variant in baseline candidate; do
    rm -rf "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src"
    cp -R "$root/baseline-core/src" "$root/fixture/crates/ic-metrics/src"
    cp -R "$root/$variant-stable/src" "$root/fixture/crates/ic-metrics-stable/src"
    find "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src" -type f -exec touch {} +
    for kernel in identity decode; do
        cp "$root/$kernel-probe.rs" "$root/fixture/crates/probe/src/lib.rs"
        # Retire only this invocation's local-package outputs. Different source
        # variants must never qualify by a shared target's freshness decision.
        if [[ -f "$build_dir/CACHEDIR.TAG" ]]; then
            cargo +1.99.0 clean --locked --offline --manifest-path "$root/fixture/Cargo.toml" --target-dir "$build_dir" \
                --release --target wasm32-unknown-unknown -p ic-metrics -p ic-metrics-stable -p stable-probe
        fi
        cargo +1.99.0 build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$build_dir" --locked --offline -p stable-probe --features unit --release --target wasm32-unknown-unknown
        cp "$build_dir/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/$variant-$kernel.wasm"
    done
done
cargo +1.99.0 build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$build_dir" --locked --offline -p stable-driver
printf '%s\n' "$build_dir/debug/stable-driver" > "$root/driver-path"
