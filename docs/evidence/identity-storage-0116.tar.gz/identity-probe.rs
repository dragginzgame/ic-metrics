//! Matched unit ownership comparison; IC setup is outside the bracket.
use std::hint::black_box;
use ic_memory::ic_stable_structures::{BTreeMap, DefaultMemoryImpl};
use ic_metrics::MeasurementCounter;
use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsStore};

#[ic_cdk::update]
fn compare(_n: u16, case: u8, iterations: u32) -> (u64, u128) {
    assert!(case < 16 && iterations <= 1024);
    let length = [1, 8, 32, 64][usize::from(case % 4)];
    let unit = "x".repeat(length);
    let expected = MetricIdentity::new(&unit, 3).unwrap();
    let key = MetricKey::new("app", "counter").unwrap();
    let mut map = BTreeMap::<Vec<u8>, Vec<u8>, _>::init(DefaultMemoryImpl::default());
    map.remove(&b"app\0counter".to_vec());
    let mut store = MetricsStore::new(map);
    let value = MeasurementCounter::from_parts(1 << 80, false).unwrap();
    store.save(&key, &expected, &value).unwrap();
    let operation = case / 4;
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let identity = match black_box(operation) {
            0 | 3 => MetricIdentity::new(black_box(&unit), 3).unwrap(),
            1 => black_box(&expected).clone(),
            2 => black_box(MetricIdentity::new(black_box(&unit), 3).unwrap()).clone(),
            _ => unreachable!(),
        };
        let identity = black_box(identity);
        assert_eq!(black_box(&identity), black_box(&expected));
        if operation == 3 {
            assert_eq!(store.load(black_box(&key), &identity, &value).unwrap(), Some(value));
            store.save(black_box(&key), &identity, black_box(&value)).unwrap();
        }
        sink = sink.wrapping_add(black_box(length as u128 + 1));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}
