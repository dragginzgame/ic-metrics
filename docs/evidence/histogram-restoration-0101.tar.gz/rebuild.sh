#!/usr/bin/env bash
set -euo pipefail
script="${BASH_SOURCE[0]}"
[[ "$script" == */* ]] || script="./$script"
cd "${script%/*}"
export RUSTUP_AUTO_INSTALL=0
mkdir -p out
for variant in before after; do
    rustc +1.99.0 --crate-name "metrics_$variant" --crate-type rlib --edition=2024 "$variant/src/lib.rs" -o "out/libmetrics_$variant.rlib"
    rustc +1.99.0 --crate-name ic_metrics --crate-type rlib --edition=2024 --target wasm32-unknown-unknown -C opt-level=z -C panic=abort "$variant/src/lib.rs" -o "out/libic_metrics_$variant.rlib"
    rustc +1.99.0 --crate-name admission_probe --crate-type cdylib --edition=2024 --target wasm32-unknown-unknown \
        -C opt-level=z -C lto=fat -C codegen-units=1 -C panic=abort -C strip=symbols \
        probe.rs --extern "ic_metrics=out/libic_metrics_$variant.rlib" -o "out/$variant.wasm"
    cmp "$variant.wasm" "out/$variant.wasm"
done
rustc +1.99.0 --edition=2024 -O compare.rs --extern metrics_before=out/libmetrics_before.rlib --extern metrics_after=out/libmetrics_after.rlib -o out/compare
out/compare > out/comparison.txt
cmp comparison.txt out/comparison.txt
wc -c out/before.wasm out/after.wasm
