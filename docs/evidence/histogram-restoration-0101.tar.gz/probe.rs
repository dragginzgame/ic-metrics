#![no_std]
extern crate ic_metrics;
use ic_metrics::{MeasurementAggregate,MeasurementHistogram,MeasurementStateError};
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { loop {} }
#[unsafe(no_mangle)]
pub extern "C" fn restore(a:u64,b:u64,overflow:u64,samples:u64,total_low:u64,total_high:u64,maximum:u64,flags:u32)->u32 {
 let total=(total_high as u128)<<64 |total_low as u128;
 let Ok(aggregate)=MeasurementAggregate::from_parts(samples,total,if samples==0 {None}else{Some(maximum)},flags&1!=0,flags&2!=0) else{return 1};
 match MeasurementHistogram::from_parts([0,100],[a,b],overflow,[flags&4!=0,flags&8!=0],flags&16!=0,aggregate) {
   Ok(value)=> if value.aggregate().samples()==samples {0}else{2},
   Err(MeasurementStateError::InvalidOverflowFlag)=>3,
   Err(MeasurementStateError::InvalidDistribution)=>4,
   Err(_)=>5,
 }
}
