extern crate metrics_before as before;
extern crate metrics_after as after;
macro_rules! tag {
    ($module:ident, $result:expr) => { match $result {
        Ok(_) => 0,
        Err($module::MeasurementStateError::InvalidEmpty) => 1,
        Err($module::MeasurementStateError::MissingMaximum) => 2,
        Err($module::MeasurementStateError::InvalidOverflowFlag) => 3,
        Err($module::MeasurementStateError::InvalidTotal) => 4,
        Err($module::MeasurementStateError::InvalidLatest) => 5,
        Err($module::MeasurementStateError::InvalidBounds) => 6,
        Err($module::MeasurementStateError::InvalidDistribution) => 7,
    }};
}
fn compare<const N: usize>(bounds: [u64; N], exhaustive: bool) -> (u64,u64) {
    let values=[0,1,u64::MAX];
    let mut comparisons=0; let mut accepted=0;
    for samples in [0,1,2,u64::MAX] {
      for total in [0,1,2,10,u64::MAX as u128,(u64::MAX as u128).pow(2),u128::MAX] {
       for maximum in [None,Some(0),Some(1),Some(10),Some(u64::MAX)] {
        for sample_lost in [false,true] { for total_lost in [false,true] {
         let Ok(old)=before::MeasurementAggregate::from_parts(samples,total,maximum,sample_lost,total_lost) else {continue};
         let new=after::MeasurementAggregate::from_parts(samples,total,maximum,sample_lost,total_lost).unwrap();
         let count_cases=if exhaustive {3usize.pow(N as u32+1)} else {16};
         let flag_cases=if exhaustive {1usize<<(N+1)} else {8};
         for count_seed in 0..count_cases { for flag_seed in 0..flag_cases {
          let counts=std::array::from_fn(|index|values[if exhaustive {(count_seed/3usize.pow(index as u32))%3} else {(count_seed+index)%3}]);
          let flags=std::array::from_fn(|index|flag_seed&(1<<(if exhaustive {index} else {index%3}))!=0);
          let overflow=values[if exhaustive {(count_seed/3usize.pow(N as u32))%3} else {count_seed%3}];
          let overflow_flag=flag_seed&(1<<(if exhaustive {N} else {2}))!=0;
          let left=before::MeasurementHistogram::from_parts(bounds,counts,overflow,flags,overflow_flag,old);
          let right=after::MeasurementHistogram::from_parts(bounds,counts,overflow,flags,overflow_flag,new);
          let l=tag!(before,left); let r=tag!(after,right);
          assert_eq!(l,r,"N={N}, samples={samples}, total={total}, max={maximum:?}, counts={count_seed}, flags={flag_seed}");
          comparisons+=1; accepted+=u64::from(l==0);
         }}
        }}
       }
      }
    }
    (comparisons,accepted)
}
fn main() {
 let cases=[compare([],true),compare([0],true),compare([u64::MAX],true),compare([0,10],true),compare([10,10],true),compare([10,0],true),compare([1,10],true),compare([0,1,10,u64::MAX],true),compare(std::array::from_fn::<_,256,_>(|n| n as u64),false)];
 let total:u64=cases.iter().map(|x|x.0).sum(); let accepted:u64=cases.iter().map(|x|x.1).sum();
 println!("{total} exact admission/error comparisons passed; {accepted} accepted states; widths 0/1/2/4/256");
}
