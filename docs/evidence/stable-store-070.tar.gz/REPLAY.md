# Native durable-store qualification

This bundle freezes the working 0.7.0 product source with unchanged real 0.6.6
metadata/lock, package dry-run artifacts from a disposable 0.7.0 copy, and local
qualification logs. It proves no live IC upgrade, runtime cost or native macOS
acceptance. `source-identity.txt` identifies the base commit and actual compiler.

After extraction, run `sha256sum -c files.sha256` (or `shasum -a 256 -c` on macOS).
Use an owning build directory and the prepared selected registry dependencies:

```sh
cargo test --manifest-path source/Cargo.toml -p ic-metrics --locked state::tests
cargo test --manifest-path source/Cargo.toml -p ic-metrics-stable --locked tests::
```

The complete CI logs retain their original working-checkout scope. Shared tooling
and unrelated repository documentation are not duplicated here; full CI replay
requires the owning checkout and its recorded Shared Tooling snapshot. The frozen
product workspace is sufficient for the focused native storage/restoration tests.

The two .crate files are dry-run payloads, not published artifacts. No version,
index or ref in the real checkout was changed, and no package was uploaded.
