//! One selected arithmetic kernel per independently built canister.
use crate::{ProbeError, ProbeReading, ProbeReply};
use metrics::{MeasurementAggregate, MeasurementHistogram, MeasurementSummary};
#[cfg(feature = "baseline")]
use metrics_baseline as metrics;
#[cfg(not(feature = "baseline"))]
use metrics_current as metrics;
use std::hint::black_box;

const BOUNDS: [u64; 4] = [0, 10_000, 100_000, 1_000_000];
const VARIANTS: usize = cfg!(feature = "count") as usize
    + cfg!(feature = "summary") as usize
    + cfg!(feature = "aggregate") as usize
    + cfg!(feature = "histogram") as usize
    + cfg!(feature = "aggregate-merge") as usize
    + cfg!(feature = "histogram-merge") as usize
    + cfg!(feature = "aggregate-query") as usize
    + cfg!(feature = "histogram-query") as usize;
const _: () = assert!(VARIANTS == 1, "select exactly one experimental kernel");

// Common reply arithmetic for both widths, outside the recording bracket.
fn wide(value: impl Into<u128>) -> u128 {
    value.into()
}
fn aggregate(a: MeasurementAggregate) -> [u128; 11] {
    let mut out = [0; 11];
    out[0] = wide(a.samples());
    out[1] = wide(a.total());
    out[2] = wide(a.maximum().unwrap_or(0));
    out[4] = u128::from(a.samples_saturated()) | (u128::from(a.total_saturated()) << 1);
    out
}
fn histogram(h: &MeasurementHistogram<4>) -> [u128; 11] {
    let mut out = aggregate(h.aggregate());
    for (slot, count) in out[5..9].iter_mut().zip(h.bucket_counts()) {
        *slot = wide(*count);
    }
    out[9] = wide(h.overflow());
    for (i, flag) in h.bucket_saturation().iter().enumerate() {
        out[4] |= u128::from(*flag) << (i + 2);
    }
    out[4] |= u128::from(h.overflow_saturated()) << 6;
    out
}
fn current_histogram() -> Result<MeasurementHistogram<4>, ProbeError> {
    MeasurementHistogram::new(BOUNDS).map_err(|_| ProbeError::Arithmetic)
}
fn bounds_range(h: &MeasurementHistogram<4>, n: u64, d: u64) -> Result<u64, ProbeError> {
    let r = h
        .quantile_bucket(black_box(n), black_box(d))
        .map_err(|_| ProbeError::Arithmetic)?
        .ok_or(ProbeError::Arithmetic)?;
    Ok(r.lower_exclusive()
        .unwrap_or(0)
        .wrapping_add(r.upper_inclusive().unwrap_or(0))
        .wrapping_add(u64::from(r.lower_exclusive().is_some()))
        .wrapping_add(u64::from(r.upper_inclusive().is_some())))
}
#[ic_cdk::update]
fn probe(iterations: u32, value: u64) -> ProbeReply {
    if iterations > 100_000 {
        return Err(ProbeError::TooManyIterations);
    }
    let mut raw_samples = 0_u64;
    #[cfg(feature = "baseline")]
    let mut raw_total = 0_u64;
    #[cfg(not(feature = "baseline"))]
    let mut raw_total = 0_u128;
    let mut summary = MeasurementSummary::EMPTY;
    let mut a = MeasurementAggregate::EMPTY;
    let mut h = current_histogram()?;
    let mut batch = MeasurementAggregate::EMPTY;
    let mut histogram_batch = current_histogram()?;
    for _ in 0..16 {
        batch.record(value);
        histogram_batch.record(value);
    }
    let mut previous = MeasurementAggregate::EMPTY;
    if cfg!(feature = "aggregate-query") || cfg!(feature = "histogram-query") {
        let values = if cfg!(feature = "aggregate-query") && value == u64::MAX {
            [0, value, value, value, value]
        } else {
            [0, 10_000, 100_000, 1_000_000, 1_000_001]
        };
        for (i, v) in values.into_iter().enumerate() {
            a.record(v);
            h.record(v);
            if i == 1 {
                previous = a;
            }
        }
    }
    let mut sink = 0_u128;
    let before = ic_cdk::api::call_context_instruction_counter();
    for _ in 0..iterations {
        if cfg!(feature = "count") {
            metrics::record_sample(&mut raw_samples, &mut raw_total, black_box(value));
        }
        if cfg!(feature = "summary") {
            summary.record(black_box(value));
        }
        if cfg!(feature = "aggregate") {
            a.record(black_box(value));
        }
        if cfg!(feature = "histogram") {
            h.record(black_box(value));
        }
        if cfg!(feature = "aggregate-merge") {
            a.merge(black_box(batch));
        }
        if cfg!(feature = "histogram-merge") {
            h.merge(black_box(&histogram_batch))
                .map_err(|_| ProbeError::Arithmetic)?;
        }
        if cfg!(feature = "aggregate-query") {
            let mean = black_box(a)
                .mean()
                .map_err(|_| ProbeError::Arithmetic)?
                .ok_or(ProbeError::Arithmetic)?;
            let interval = black_box(a)
                .interval_since(black_box(previous))
                .map_err(|_| ProbeError::Arithmetic)?;
            let interval_mean = interval.mean().ok_or(ProbeError::Arithmetic)?;
            sink = sink
                .wrapping_add(wide(mean))
                .wrapping_add(wide(interval.samples()))
                .wrapping_add(wide(interval.total()))
                .wrapping_add(wide(interval_mean));
        }
        if cfg!(feature = "histogram-query") {
            let count = black_box(&h)
                .cumulative_count(black_box(2))
                .map_err(|_| ProbeError::Arithmetic)?;
            sink = sink
                .wrapping_add(wide(count))
                .wrapping_add(wide(bounds_range(black_box(&h), 1, 2)?))
                .wrapping_add(wide(bounds_range(black_box(&h), 95, 100)?));
        }
    }
    let after = ic_cdk::api::call_context_instruction_counter();
    let mut state = if cfg!(feature = "count") {
        let mut s = [0; 11];
        s[0] = wide(raw_samples);
        s[1] = wide(raw_total);
        s
    } else if cfg!(feature = "summary") {
        let mut s = aggregate(summary.aggregate());
        s[3] = wide(summary.latest().unwrap_or(0));
        s
    } else if cfg!(feature = "aggregate")
        || cfg!(feature = "aggregate-merge")
        || cfg!(feature = "aggregate-query")
    {
        aggregate(a)
    } else {
        histogram(&h)
    };
    state[10] = sink;
    Ok(ProbeReading {
        before,
        after,
        state,
    })
}
