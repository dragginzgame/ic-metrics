#!/usr/bin/env bash
# Frozen Linux IC experiment; setup, downloads and product release are separate.
set -euo pipefail
if (($# != 2)); then
  printf 'usage: %s METRICS_TARGET_BUILD_DIRECTORY NEW_RESULT_DIRECTORY\n' "$0" >&2
  exit 2
fi
fixture=$(cd -- "$(dirname -- "$0")" && pwd -P)
build=$1
output=$2
: "${POCKET_IC_BIN:?Supply the explicitly prepared PocketIC 16.1.0 executable}"
if [[ -n ${IC_TESTKIT_POCKET_IC_URL+x} ]]; then
  printf 'This experiment requires its exact local server, not a URL.\n' >&2
  exit 2
fi
if [[ $(rustc --version) != 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]; then
  printf 'This experiment selects Rust 1.99.0.\n' >&2
  exit 2
fi
server_digest=$(sha256sum -- "$POCKET_IC_BIN")
if [[ ${server_digest%% *} != b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]]; then
  printf 'The selected executable differs from the frozen server.\n' >&2
  exit 2
fi
(cd -- "$fixture" && sha256sum -c inputs.sha256)
cargo metadata --offline --locked --manifest-path "$fixture/Cargo.toml" --no-deps --format-version 1 >/dev/null
for prefix in baseline wide; do
  for variant in count summary aggregate histogram aggregate-merge histogram-merge aggregate-query histogram-query; do
    features=$variant
    if [[ $prefix == baseline ]]; then features=baseline,$variant; fi
    cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --target wasm32-unknown-unknown --features "$features" -- -D warnings
    cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --release --target wasm32-unknown-unknown --features "$features"
    cmp -- "$build/wasm32-unknown-unknown/release/arithmetic_cost_probe.wasm" "$fixture/artifacts/$prefix-$variant.wasm"
  done
done
cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver -- -D warnings
cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver
"$build/debug/arithmetic-cost-driver" "$fixture" "$output"
cmp -- "$fixture/run-3/results.csv" "$output/results.csv"
cmp -- "$fixture/run-3/sizes.csv" "$output/sizes.csv"
