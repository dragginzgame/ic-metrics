; ModuleID = 'layout.cf2bdcb2d406c39d-cgu.0'
source_filename = "layout.cf2bdcb2d406c39d-cgu.0"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown"

@LAYOUT = dso_local local_unnamed_addr constant [24 x i8] c"0\00\00\00 \00\00\00@\00\00\00@\00\00\00`\00\00\00\80\00\00\00", align 4, !guid !0

!llvm.ident = !{!1}

!0 = !{i64 -342245979978062038}
!1 = !{!"rustc version 1.99.0 (b940084d7 2026-09-28)"}
