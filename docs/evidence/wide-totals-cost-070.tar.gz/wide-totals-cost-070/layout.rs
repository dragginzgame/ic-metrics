//! Wasm-target storage constants for the same arithmetic sources as the IC probes.
#![no_std]
use metrics::{MeasurementAggregate, MeasurementHistogram, MeasurementInterval, MeasurementSummary};
#[unsafe(no_mangle)]
pub static LAYOUT: [u32; 6] = [
    core::mem::size_of::<MeasurementAggregate>() as u32,
    core::mem::size_of::<MeasurementInterval>() as u32,
    core::mem::size_of::<MeasurementSummary>() as u32,
    core::mem::size_of::<MeasurementHistogram<0>>() as u32,
    core::mem::size_of::<MeasurementHistogram<2>>() as u32,
    core::mem::size_of::<MeasurementHistogram<4>>() as u32,
];
