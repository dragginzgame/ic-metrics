# Frozen wide-total IC arithmetic experiment

This retained Linux artifact owns copied arithmetic source and one private
probe/driver. It is not a product workspace member, dependency, endpoint or CI
gate. All four source-less lock packages are owned here; there are no sibling
path dependencies. Its private package version 0.0.0 selects no product release.

Baseline source is byte-exact released Metrics 0.6.6 at
c651c095d5554e929a9cb96f5089226eda66ee90. Current source is the pending 0.7.0
candidate with wide totals/means and exact native-width division when possible.
The source catalog binds every copied source and private manifest. Rust 1.99.0
is the experiment compiler, not a new arithmetic support floor. All 293 external
lock package identities, checksums and dependency rows match the frozen
arithmetic-cost-061 graph. No product lock is changed. The inspector's newer Host
selection does not replace the separately frozen Testkit graph in this experiment.

Release compilation uses opt-level=z, LTO, one codegen unit, stripped symbols and
panic abort; no Wasm postprocessing. Candid 0.10.37, CDK 0.20.3, Testkit 0.33.3 and
PocketIC client/server 16.1.0 are selected. Testkit owns fallible startup and
protocol/version admission. The explicit server payload digest is
b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db.
The originally admitted official archive digest is
131219d90dcf9bf6f3ed8ee02d8f55504ea24a6db382f5680675b7bd6b7ed3bf.
No server is bundled, installed or rebuilt here; no sibling is built or modified.
The server path is an original execution input, not a replay-directory mandate.

Every update constructs fresh local accumulators. Four bounds are
[0, 10_000, 100_000, 1_000_000]. Initialization and a prepared 16-observation
merge batch are outside the bracket. The bracket contains kernel loops, runtime
black boxes, error handling and checksum arithmetic. Projection and Candid
encoding are outside it. Both versions share u128 reply fields and checksum
arithmetic so encoding does not narrow wide totals. Samples/totals/max/latest,
flags, every bucket and query checksums are independently checked with a u128
oracle. Whole-update cycles are actual balance decreases including setup,
projection, encoding and execution fees, separate from bracketed instructions.
Each canister is funded with 100 trillion additional cycles before installation.
No instruction-to-cycle conversion, native timing, mainnet spending, attribution
or async callback behavior is claimed.

Normal query seeds are [0, 10_000, 100_000, 1_000_000, 1_000_001], with the
first two as the previous aggregate. Aggregate queries check mean, interval,
interval mean and a checksum; histogram queries check cumulative_count(2), p50
and p95 ranges. A separate wide-values cohort seeds [0, MAX, MAX, MAX, MAX].
The current mean and interval then exercise totals beyond u64::MAX. The released
counter returns a typed projection rejection for that cohort; it has no exact
cost-comparison counterpart. No overflow result is misrepresented as an exact
mean. One sample at MAX and 1,000 samples at MAX also independently check recording
and merge saturation differences. Count/bucket overflow is covered by product
boundary tests, not reached by this bounded IC matrix.

run-3 and run-4 are finalized independent server runs. Each validates 841 measured
replies, 16 iteration-limit rejections and one narrow-total projection rejection.
Both CSVs agree byte-for-byte. Every warm and matched-batch case is repeated three
times. Controls remain raw; don't extrapolate a universal per-operation cost.
run-1 and run-2 retain the prior 832-reply matrix before the wide-query cohort.
Their matching source catalog and two original source files are in inputs;
the four query Wasms are in before-wide-query-artifacts. Other variant Wasms
are unchanged. To replay that earlier matrix, use a separate copy with those
original probe/driver files and query Wasms, and compare with run-1.

initial-division.tar.gz freezes the initial direct-u128-division candidate,
its complete sources/lock/driver/Wasms and two 832-reply runs. It also retains a
sandbox-denied loopback startup with no measurements, and the initial host-driver
lint failure plus its source before boxed error payloads. None is relabeled as
this final candidate. The exact native-width branch reduces ordinary query cost
without narrowing wide totals. layouts.json and the Wasm-target LLVM IR bind
storage sizes; they are not native substitutes for IC execution.

logs/product-ci.log records the separately approved full product make ci gate.
It selects the root product graph and unchanged package metadata, not this private
graph. The caller catalog distinguishes committed and dirty reviewed files;
that source review does not qualify downstream native/runtime adoption.

Verify all retained payloads before building. Prepare caches for this exact lock
and the exact owner-admitted server separately; the replay deliberately uses
locked offline resolution and never downloads or installs anything. Supply build
and result directories under the owning Metrics target/. Existing result
folders, altered payloads, compiler/server mismatches, changed Wasms or raw
results fail; there is no fallback server or updated graph.

```sh
# From a fresh extraction:
sha256sum -c inputs.sha256
export POCKET_IC_BIN=/absolute/path/to/the/admitted/pocket-ic
unset IC_TESTKIT_POCKET_IC_URL
bash replay.sh /absolute/metrics/target/evidence/wide-replay/build \
  /absolute/metrics/target/evidence/wide-replay/new-results
```
