#!/usr/bin/env bash
# Frozen evidence only. Provision locked sources and the exact Testkit server separately.
set -euo pipefail
[[ $# == 3 ]] || { printf 'usage: replay.sh TARGET_DIR NEW_RESULT_DIR PREPARED_SERVER_DIR\n' >&2; exit 2; }
fixture="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
export CARGO_TARGET_DIR="$1"
result="$2"
server="$3"
[[ "$CARGO_TARGET_DIR" == /* && "$result" == /* && "$server" == /* && ! -e "$result" ]] || exit 2
cd "$fixture"
cargo clippy -p driver -p protocol --all-targets --locked --offline -- -D warnings
for flags in '' durable upgrade durable,upgrade; do
    args=()
    [[ -z "$flags" ]] || args=(--features "$flags")
    cargo clippy -p probe --lib --target wasm32-unknown-unknown --locked --offline "${args[@]}" -- -D warnings
    cargo build -p probe --target wasm32-unknown-unknown --release --locked --offline "${args[@]}"
    case "$flags" in
        '') name=volatile ;; durable) name=durable ;; upgrade) name=volatile-upgrade ;; *) name=durable-upgrade ;;
    esac
    cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/probe.wasm" "artifacts/$name.wasm"
done
cargo build -p driver --locked --offline
"$CARGO_TARGET_DIR/debug/driver" --fixture "$fixture" --output "$result" --server-directory "$server"
