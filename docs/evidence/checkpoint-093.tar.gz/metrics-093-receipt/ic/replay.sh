#!/usr/bin/env bash
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: replay.sh METRICS_TARGET_DIR FRESH_OUTPUT_DIR' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
build="$1"
: "${POCKET_IC_BIN:?Prepare PocketIC 16.1.0 explicitly}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
for variant in baseline candidate; do
    features=()
    [[ "$variant" != candidate ]] || features=(--features upgrade)
    cargo clippy --manifest-path "$root/Cargo.toml" --target-dir "$build" --offline --locked -p stable-probe --target wasm32-unknown-unknown "${features[@]}" -- -D warnings
    cargo build --manifest-path "$root/Cargo.toml" --target-dir "$build" --offline --locked -p stable-probe --release --target wasm32-unknown-unknown "${features[@]}"
    cmp "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/$variant.wasm"
done
cargo clippy --manifest-path "$root/Cargo.toml" --target-dir "$build" --offline --locked -p stable-driver -- -D warnings
cargo build --manifest-path "$root/Cargo.toml" --target-dir "$build" --offline --locked -p stable-driver
"$build/debug/stable-driver" "$root" "$2"
cmp "$root/run-4/costs.csv" "$2/costs.csv"
