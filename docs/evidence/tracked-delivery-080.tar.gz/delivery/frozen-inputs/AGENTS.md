# IC Metrics Agent Rules

Read [DRAGGINZGAME.md](DRAGGINZGAME.md) first. The reviewed Shared Tooling revision
`c118062a070a2e238f1eb3989b6fd700f369ce1e` and file digests are recorded in
[.shared-tooling.snapshot](.shared-tooling.snapshot). This is the local overlay;
there are no baseline exceptions. Read [the current handoff](docs/status/current.md)
and [the extraction contract](docs/extraction.md) before implementation.

## Ownership

- Own small, allocation-free measurement arithmetic. Keep the library
  dependency-free and `no_std`; consumers own platform counter reads.
- The separately opted-in `ic-metrics-stable` package owns one-map snapshot
  encoding and validated restoration, using `ic-memory`'s exact collection types.
  Its native/Wasm Rust floor is 1.88. Hosts own the allocation key, bootstrap,
  collection lifecycle, identities, synchronization, write cadence and resets.
  Never add stable-memory dependencies to the arithmetic package.
- The private `ic-metrics-wasm-inspect` host binary owns bounded structural
  evidence inspection through IC Host libraries, outside the arithmetic graph.
  Its explicit Rust 1.88 floor is separate from the arithmetic Rust 1.85 floor.
  Source-less lock packages must be workspace-owned; external path dependencies
  are not permitted. Release metadata advances all local workspace rows together.
- Consumer code owns measurement attribution, registries, labels, replication
  policy, reset/restart identity, persistence, lifecycle hooks, and endpoints.
  Do not add dependencies on IcyDB, Canic, `ic-timers`, or `ic-backup`.
- IcyDB's inclusive overlapping spans and Canic's exclusive endpoint accounting
  remain separate consumer contracts. Do not add an attribution-mode switch.
- Units and saturation are explicit. Zero is a valid sample; no samples is a
  different state. Saturated totals are unsuitable for exact interval arithmetic.
  Counter identity must be established before comparing snapshots.
- Native substitutes are not IC measurements. Never add timing benchmarks or
  convert instruction counts into estimated cycles. Permitted performance
  evidence is instruction counts, IC cycles, and raw Wasm bytes.

## Work and validation

- Mutate only this repository unless exact sibling targets are explicitly
  authorized. Preserve unrelated dirty work. Follow the shared
  [contribution rules](rules/contributions.md): an explicit PR request includes
  its topic branch, scoped commits, branch push and PR creation/update. Ordinary
  fixes and continuation authorize local work. Merges, direct integration-branch
  pushes and shared-history rewrites require their own explicit authorization.
- Cargo package/workspace version changes and releases require explicit authority.
  Initial metadata is not a release selection; an ordinary PR does not authorize
  a version bump, tag, release or publication. An explicitly requested standard
  release includes its documented gate, commit, tag and atomic push; publication
  remains a separate effect. Preserve branch protections and required checks.
- This consumer supports `RELEASE_DELIVERY=direct` only. PR release delivery
  needs separately adopted merged-checkout adapters and qualification; ordinary
  contribution PRs retain the shared contribution rules.
- Use Rust edition 2024 and ordinary directory modules. Public APIs need docs;
  invalid input and recoverable failures need typed errors. No string matching
  on errors, production panics, or committed Python tooling.
- Check for active builds before source edits or compilation. Use this repo's
  `target/` and locked dependencies; do not upgrade dependencies as a side effect.
- After Rust edits, run `make fmt`, then selected package checks or named tests.
  Focused commands and host qualification are in [docs/hosts.md](docs/hosts.md).
  Before delivering completed code as ready, run `make ci` and all documented
  package-floor checks, reusing passing evidence for unchanged inputs. Inspection
  alone does not authorize that suite; documentation-only work needs link,
  consistency and diff checks. Releases remain separately authorized.
- Fix warnings in the selected Clippy gate before later validation.
- When shared contracts change, review the IcyDB, Canic, `ic-timers`,
  `ic-backup`, IC Blob Storage test-probe and Toko Miner callers under
  [the downstream contract checks](docs/extraction.md#downstream-contract-checks).
  Each consumer owns its qualification; review does not authorize sibling edits.
- Do not patch snapshot-owned files. Refresh through the upstream distribution
  helper from a clean checkout of a reviewed revision, then verify the snapshot.
- Maintain one numbered, undated pending changelog under the shared rules;
  derive its version from the latest finalized release and the complete batch's
  compatibility impact. This does not authorize package version changes or a
  release. Track follow-up work exclusively in GitHub issues, not local task lists.

## Dependency qualification

- `make check-pins` requires prepared Git, jq and Mike Farah yq; consumer-selected
  tool versions/digests are in the reviewed `ci/tool-versions.env`. Explicit
  `make install-host-tools` prepares jq, yq, ripgrep with PCRE2 and cloc under
  `.tools/host/bin`; `make host-tools-check` verifies the complete set offline.
  Host/IC/Cargo payloads live in the canonical per-user store; checkout paths select
  exact shared generations. Use the same `SHARED_TOOLING_STORE` setting for setup,
  checks and evidence collection. Preserve earlier local bundles and references;
  do not copy payloads or create consumer-owned storage management.
  Explicit `make install-rust-tools` prepares the pinned Cargo tools with the
  standard shared tool-build environment and exact compiler/native/package-lock
  identities, activating `.tools/rust/common/bin` only after the complete set
  passes admission. Application flags/wrappers remain local build policy;
  selected CLI adapters consume the installer's returned path.
  `make rust-tools-check` verifies the managed source cache, Cargo receipts,
  byte identities and common-tool versions offline. Retain prior sets and failed
  build evidence. `install-tools` and `tools-check` run the complete common host, IC and
  Rust sets in order, including under parallel Make; product extensions use the
  shared ordered target lists rather than aggregate prerequisites.
  Shared `make/consumer.mk` composes setup/check, formatting, hooks and releases;
  its included owners retain their contracts. IC executable pins live only in
  `ci/ic-tools.tsv`. The checker and release gates never install tools or unlock graphs.
- Shared structural reviews use [the common methods](audits/README.md), with
  this overlay's allocation, units, counter identity and ownership constraints.
  Source scope is `crates/ic-metrics`, owning tooling and the affected downstream
  contracts in `docs/extraction.md`; focused commands remain in `docs/hosts.md`.
  Existing performance evidence under `docs/evidence` retains its domain scope
  and original identities. Audit adoption schedules no review or broad gate.
