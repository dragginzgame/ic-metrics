//! Host validator for the frozen arithmetic-only IC replay experiment.

use std::{error::Error, fmt, fs, io::Write, path::PathBuf};

use arithmetic_replay_probe::{ProbeError, ProbeReply};
use candid::{Principal, decode_one, encode_args};
use pocket_ic::PocketIcBuilder;

#[derive(Debug)]
enum ReplayError {
    Arguments,
    CounterRegression,
    CycleIncrease,
    ProbeRejected,
    Rejected(pocket_ic::RejectResponse),
    Projection {
        expected: [u64; 7],
        actual: [u64; 7],
    },
}

impl fmt::Display for ReplayError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Rejected(response) => write!(f, "IC replay call rejected: {response:?}"),
            Self::Projection { expected, actual } => write!(
                f,
                "replay projection mismatch: expected {expected:?}, got {actual:?}"
            ),
            _ => write!(f, "replay validation failed: {self:?}"),
        }
    }
}
impl Error for ReplayError {}

fn main() -> Result<(), Box<dyn Error>> {
    let mut arguments = std::env::args_os().skip(1);
    let (Some(server), Some(directory), None) =
        (arguments.next(), arguments.next(), arguments.next())
    else {
        return Err(ReplayError::Arguments.into());
    };
    let directory = PathBuf::from(directory);
    let pic = PocketIcBuilder::new()
        .with_server_binary(PathBuf::from(server))
        .with_application_subnet()
        .build();
    let mut csv = fs::File::create(directory.join("results.csv"))?;
    writeln!(
        csv,
        "variant,phase,value,iterations,repeat,instructions,cycles,samples,total,latest,maximum,first,second,overflow"
    )?;
    let mut sizes = fs::File::create(directory.join("sizes.csv"))?;
    writeln!(sizes, "variant,raw_wasm_bytes")?;
    for variant in ["count", "summary", "histogram"] {
        let wasm = fs::read(directory.join("artifacts").join(format!("{variant}.wasm")))?;
        writeln!(sizes, "{variant},{}", wasm.len())?;
        let canister = pic.create_canister();
        pic.install_canister(canister, wasm, encode_args(())?, None);
        let initial = 100_000_000_000_000_u128;
        let balance = pic.cycle_balance(canister);
        let top_up = initial
            .checked_sub(balance)
            .ok_or(ReplayError::CycleIncrease)?;
        pic.add_cycles(canister, top_up);
        let mut expected = [0_u64; 7];
        let mut cases = vec![("cold", 0_u64, 1_u32, 0_u32)];
        for value in [0, 10_000, 10_001, 100_000, 100_001] {
            for iterations in [0, 1, 1_000] {
                for repeat in 0..3 {
                    cases.push(("warm", value, iterations, repeat));
                }
            }
        }
        for (phase, value, iterations, repeat) in cases {
            expected[0] += u64::from(iterations);
            expected[1] += value * u64::from(iterations);
            if iterations != 0 && variant != "count" {
                expected[2] = value;
                expected[3] = expected[3].max(value);
            }
            if variant == "histogram" {
                let bucket = if value <= 10_000 {
                    4
                } else if value <= 100_000 {
                    5
                } else {
                    6
                };
                expected[bucket] += u64::from(iterations);
            }
            let cycles_before = pic.cycle_balance(canister);
            let response = pic
                .update_call(
                    canister,
                    Principal::anonymous(),
                    "probe",
                    encode_args((iterations, value))?,
                )
                .map_err(ReplayError::Rejected)?;
            let cycles_after = pic.cycle_balance(canister);
            let reply: ProbeReply = decode_one(&response)?;
            let reply = reply.map_err(|_| ReplayError::ProbeRejected)?;
            let [
                before,
                after,
                samples,
                total,
                latest,
                maximum,
                first,
                second,
                overflow,
            ] = reply;
            let actual = [samples, total, latest, maximum, first, second, overflow];
            if actual != expected {
                return Err(ReplayError::Projection { expected, actual }.into());
            }
            let instructions = after
                .checked_sub(before)
                .ok_or(ReplayError::CounterRegression)?;
            let cycles = cycles_before
                .checked_sub(cycles_after)
                .ok_or(ReplayError::CycleIncrease)?;
            writeln!(
                csv,
                "{variant},{phase},{value},{iterations},{repeat},{instructions},{cycles},{samples},{total},{latest},{maximum},{first},{second},{overflow}"
            )?;
        }
        let rejected = pic
            .update_call(
                canister,
                Principal::anonymous(),
                "probe",
                encode_args((100_001_u32, 1_u64))?,
            )
            .map_err(ReplayError::Rejected)?;
        if !matches!(
            decode_one::<ProbeReply>(&rejected)?,
            Err(ProbeError::TooManyIterations)
        ) {
            return Err(ReplayError::ProbeRejected.into());
        }
        let unchanged = pic
            .update_call(
                canister,
                Principal::anonymous(),
                "probe",
                encode_args((0_u32, 0_u64))?,
            )
            .map_err(ReplayError::Rejected)?;
        let unchanged =
            decode_one::<ProbeReply>(&unchanged)?.map_err(|_| ReplayError::ProbeRejected)?;
        let actual = [
            unchanged[2],
            unchanged[3],
            unchanged[4],
            unchanged[5],
            unchanged[6],
            unchanged[7],
            unchanged[8],
        ];
        if actual != expected {
            return Err(ReplayError::Projection { expected, actual }.into());
        }
    }
    println!(
        "138 measured IC replies and 6 admission/state replies validated; inputs/results kept in {}",
        directory.display()
    );
    Ok(())
}
