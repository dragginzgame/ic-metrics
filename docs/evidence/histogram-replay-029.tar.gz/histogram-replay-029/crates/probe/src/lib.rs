//! Frozen replay protocol shared by the host validator and isolated probes.

#[cfg(target_arch = "wasm32")]
mod canister;

/// A rejected probe operation; no invalid operation records a sample.
#[derive(candid::CandidType, serde::Deserialize, Debug)]
pub enum ProbeError {
    /// Static fixture bounds did not satisfy the histogram contract.
    InvalidBounds {
        /// Index of the right-hand invalid bound.
        index: u64,
    },
    /// The fixture's mutable diagnostic state is already borrowed.
    BorrowConflict,
    /// Thread-local diagnostic state is unavailable.
    StateUnavailable,
    /// The bounded probe refuses more than 100,000 repetitions.
    TooManyIterations,
}

/// Counter bracket followed by count, total, latest, maximum and three buckets.
pub type ProbeReply = Result<[u64; 9], ProbeError>;
