use std::cell::RefCell;

use crate::{ProbeError, ProbeReply};

#[cfg(not(any(feature = "count", feature = "summary", feature = "histogram")))]
compile_error!("select exactly one experiment variant");
#[cfg(any(
    all(feature = "count", feature = "summary"),
    all(feature = "count", feature = "histogram"),
    all(feature = "summary", feature = "histogram")
))]
compile_error!("select exactly one experiment variant");

#[cfg(feature = "count")]
type Aggregate = (u64, u64);
#[cfg(feature = "summary")]
type Aggregate = ic_metrics::MeasurementSummary;
#[cfg(feature = "histogram")]
type Aggregate = ic_metrics::MeasurementHistogram<2>;

thread_local! {
    static STATE: RefCell<Option<Aggregate>> = const { RefCell::new(None) };
}

fn empty() -> Result<Aggregate, ProbeError> {
    #[cfg(feature = "count")]
    {
        Ok((0, 0))
    }
    #[cfg(feature = "summary")]
    {
        Ok(ic_metrics::MeasurementSummary::EMPTY)
    }
    #[cfg(feature = "histogram")]
    {
        ic_metrics::MeasurementHistogram::new([10_000, 100_000]).map_err(|error| {
            ProbeError::InvalidBounds {
                index: error.index() as u64,
            }
        })
    }
}

fn record(aggregate: &mut Aggregate, value: u64) {
    #[cfg(feature = "count")]
    ic_metrics::record_sample(&mut aggregate.0, &mut aggregate.1, value);
    #[cfg(any(feature = "summary", feature = "histogram"))]
    aggregate.record(value);
}

fn project(aggregate: &Aggregate) -> [u64; 7] {
    #[cfg(feature = "count")]
    {
        [aggregate.0, aggregate.1, 0, 0, 0, 0, 0]
    }
    #[cfg(feature = "summary")]
    {
        [
            aggregate.samples(),
            aggregate.total(),
            aggregate.latest().unwrap_or(0),
            aggregate.maximum().unwrap_or(0),
            0,
            0,
            0,
        ]
    }
    #[cfg(feature = "histogram")]
    {
        let summary = aggregate.summary();
        [
            summary.samples(),
            summary.total(),
            summary.latest().unwrap_or(0),
            summary.maximum().unwrap_or(0),
            aggregate.bucket_counts()[0],
            aggregate.bucket_counts()[1],
            aggregate.overflow(),
        ]
    }
}

#[ic_cdk::update]
fn probe(iterations: u32, value: u64) -> ProbeReply {
    if iterations > 100_000 {
        return Err(ProbeError::TooManyIterations);
    }
    STATE
        .try_with(|state| {
            let mut state = state
                .try_borrow_mut()
                .map_err(|_| ProbeError::BorrowConflict)?;
            if state.is_none() {
                *state = Some(empty()?);
            }
            let aggregate = state.as_mut().ok_or(ProbeError::StateUnavailable)?;
            let before = ic_cdk::api::call_context_instruction_counter();
            for _ in 0..iterations {
                record(aggregate, std::hint::black_box(value));
            }
            let after = ic_cdk::api::call_context_instruction_counter();
            let [samples, total, latest, maximum, first, second, overflow] = project(aggregate);
            Ok([
                before, after, samples, total, latest, maximum, first, second, overflow,
            ])
        })
        .map_err(|_| ProbeError::StateUnavailable)?
}
