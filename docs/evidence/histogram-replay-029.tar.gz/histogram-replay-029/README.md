# Frozen arithmetic replay, 0.2.9 preparation

This standalone evidence workspace is not an ic-metrics runtime API, dependency,
maintained benchmark framework or CI gate. It compares direct count/total,
summary and two-bound histogram recording. It does not reproduce the unavailable
0.2.6 Canic source-copy experiment or qualify an application.

The copied Metrics Rust and application guide match released 0.2.8
`0eac2b0baa9d03b8f2430a24dfe596d93f5bfc16`. Private fixture package versions
are initial metadata, not another publication. Source/lock/host/server/build/raw
result receipts are under `inputs/`; frozen Wasms are under `artifacts/`.
All 276 external package identities match the captured seed lock. Root package
dependencies, lock and source were not changed. The repository MIT license is
included; dependency licenses remain with their registry packages.

The probe admits at most 100,000 iterations, holds one diagnostic aggregate,
uses bounds [10000, 100000], and brackets only the recording loop with actual
counter-1 reads. It initializes/borrows state before the bracket and projects
the common nine-u64 response afterward. Values pass through black_box and
projections stay observable. The host checks every count/total/latest/maximum/
bucket and observes cycle balance around the whole update, including encoding.
It also validates typed iteration refusal and unchanged subsequent state.
No labels, maps, endpoint attribution, callbacks, traps or application operation
measurements are qualified. Empty/zero/saturation behavior belongs to the core's
existing qualification; this experiment does not measure saturation cost.

## Verify and replay

First verify `inputs.sha256` from this directory. Keep this frozen copy intact.
Prepare Rust 1.99.0 with wasm32-unknown-unknown, the exact locked cache, and the
Linux x86-64 PocketIC 16.0.0 binary separately. Its byte digest is
69e324bdb68d32d878b7a9504b1379f08f8d1921272bacb065b0fabb3d0f3792.
Ordinary replay does not download or install tools and makes localhost calls
only. Root `make ic-tools-check` verifies the selected prepared server.

From the owning repository root, with `fixture` naming this extracted directory:

```sh
export RUSTUP_AUTO_INSTALL=0
export CARGO_TARGET_DIR="$PWD/target"
cargo +1.99.0 fetch --locked --offline --manifest-path "$fixture/Cargo.toml"
cargo +1.99.0 build --locked --offline --manifest-path "$fixture/Cargo.toml" \
  -p arithmetic-replay-driver
run="$(mktemp -d "$PWD/target/evidence/arithmetic-replay.XXXXXX")"
mkdir "$run/artifacts"
cp "$fixture"/artifacts/*.wasm "$run/artifacts/"
target/debug/arithmetic-replay-driver "$PWD/.tools/ic/bin/pocket-ic" "$run"
```

This re-executes the exact frozen Wasms, leaving reference CSV/results unchanged.
Bind fresh observations to their new run, host and server receipts even if the
CSV matches. Linux execution is not native macOS or mainnet qualification.

To rebuild those Wasms with the recorded release profile (opt-level=z, LTO,
one codegen unit, stripped symbols, panic abort), use a separate output directory:

```sh
for variant in count summary histogram; do
  cargo +1.99.0 build --locked --offline --release \
    --manifest-path "$fixture/Cargo.toml" -p arithmetic-replay-probe \
    --target wasm32-unknown-unknown --features "$variant"
  cp target/wasm32-unknown-unknown/release/arithmetic_replay_probe.wasm \
    "$run/artifacts/$variant.wasm"
done
```

Compare rebuilt bytes against the frozen artifact hashes before attributing
measurements to them. Another compiler, target, source path or build configuration
may require a new artifact identity. Do not replace the reference files or infer
generic-N/application costs from a source-equivalent build.

The initial scratch driver had a misplaced module doc comment and used `?` on
PocketIC RejectResponse before adding its typed error adapter. Both failed logs
remain separate. Final source passes warning-denied driver and three-variant
Wasm Clippy, formatting and locked offline builds. These checks do not assert
qualification of the unavailable historical source or other consumers.
