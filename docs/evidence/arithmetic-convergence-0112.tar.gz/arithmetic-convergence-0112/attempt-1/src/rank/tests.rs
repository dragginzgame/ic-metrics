use super::quantile_rank;

#[test]
fn nearest_rank_matches_wide_oracle_across_product_boundaries() {
    for (numerator, denominator) in [
        (1, 1),
        (1, 2),
        (2, 3),
        (95, 100),
        (1, u64::MAX),
        (u64::MAX / 2, u64::MAX),
        (u64::MAX - 1, u64::MAX),
        (u64::MAX, u64::MAX),
    ] {
        let boundary = u64::MAX / numerator;
        for samples in [
            0,
            1,
            2,
            3,
            5,
            100,
            u64::from(u32::MAX),
            u64::from(u32::MAX) + 1,
            boundary - 1,
            boundary,
            boundary.saturating_add(1),
            u64::MAX - 1,
            u64::MAX,
        ] {
            let product = u128::from(samples) * u128::from(numerator);
            let divisor = u128::from(denominator);
            let expected = Some(product / divisor + u128::from(product % divisor != 0));
            assert_eq!(quantile_rank(samples, numerator, denominator), expected);
        }
    }
    // Invalid fractions precede emptiness on both sides of the product boundary.
    for samples in [0, 1, u64::MAX] {
        for (numerator, denominator) in [(0, 0), (0, 1), (1, 0), (u64::MAX, u64::MAX - 1)] {
            assert_eq!(quantile_rank(samples, numerator, denominator), None);
        }
    }
}
