//! Shared integer rank arithmetic; callers own samples, errors and projections.

#[cfg(test)]
mod tests;

// Invalid fractions return None; an admitted empty set has rank zero. Preserve
// native-width division for ordinary products and exact wide ranks otherwise.
pub const fn quantile_rank(samples: u64, numerator: u64, denominator: u64) -> Option<u128> {
    if numerator == 0 || numerator > denominator {
        return None;
    }
    if let Some(product) = samples.checked_mul(numerator) {
        return Some(product.div_ceil(denominator) as u128);
    }
    Some(((samples as u128) * (numerator as u128)).div_ceil(denominator as u128))
}
