#!/usr/bin/env bash
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: replay.sh METRICS_TARGET_DIR FRESH_OUTPUT_DIR' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
build="$1" output="$2"
: "${POCKET_IC_BIN:?Prepare PocketIC 16.1.0 explicitly}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
mkdir -p "$build"
mkdir "$output"
scratch="$(mktemp -d "$build/arithmetic-replay.XXXXXX")"
cp -R "$root/fixture/." "$scratch/"
for attempt in 1 2; do
    for variant in baseline candidate; do
        selection="$root/baseline"
        [[ "$variant" != candidate ]] || selection="$root/attempt-$attempt"
        rm -r "$scratch/crates/ic-metrics/src"
        cp -R "$selection/src" "$scratch/crates/ic-metrics/src"
        find "$scratch/crates/ic-metrics/src" -type f -exec touch {} +
        for kernel in hist samples floor nearest; do
            cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$build" --locked --offline --release -p stable-probe --target wasm32-unknown-unknown --features "$kernel"
            cmp "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$selection/$variant-$kernel.wasm"
            cp "$selection/$variant-$kernel.wasm" "$scratch/$variant-$kernel.wasm"
        done
    done
    cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$build" --locked --offline -p stable-driver
    "$build/debug/stable-driver" "$scratch" "$output/run-$attempt"
    awk -F, 'NR>1 {print $1,$2,$3,$4,$5,$7}' "$root/attempt-$attempt/costs.csv" > "$scratch/expected"
    awk -F, 'NR>1 {print $1,$2,$3,$4,$5,$7}' "$output/run-$attempt/costs.csv" > "$scratch/actual"
    cmp "$scratch/expected" "$scratch/actual"
done
printf 'Both rejected arithmetic experiments reproduced; scratch retained: %s\n' "$scratch"
