# Histogram range-construction experiment

Product baseline: IC Metrics 0.11.6, commit 604276df62e898568a1f388851340dd6525a2d9f.
`baseline-core` freezes that arithmetic source. `candidate-core` changes only
quantile range construction: find the index, then construct one range. The
candidate is rejected; the maintained implementation remains the baseline.

`fixture` is an isolated registry-locked IC experiment, with frozen local package
labels 0.11.5 inherited from its prior harness, not a product release selection.
It uses the current product core sources above. Its stable package is not used
by the probe; retaining that optional workspace member preserves the frozen lock.
The product manifest and lock are retained separately at this directory's root.
No external path dependencies or sibling source are included.

Rust: 1.99.0 (b940084d7 2026-09-28), Linux x86_64; opt-level z, LTO, one codegen
unit, stripped symbols, panic abort; no Wasm postprocessing. PocketIC 16.1.0
Linux x86_64 SHA256 b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db.

The driver installs separate baseline/candidate canisters. Bounds 0/4/256,
11 exact/empty/overflow/invalid cases, 0/128 repetitions and three repeats yield
396 updates. Result sinks include both optional range endpoints; all match.
Instructions bracket only repeated quantile queries and result folding. Actual
cycle charges cover the complete update and setup; they are not estimates or
isolated arithmetic charges. See the source-bound report for the decision.

Run with prepared locked registry sources, Rust/Wasm and the pinned server:

```sh
METRICS_TARGET_DIR=/absolute/ic-metrics/target/quantile-readback \
POCKET_IC_BIN=/absolute/prepared/pocket-ic bash replay.sh
```

Replay uses invocation-owned build caches, cleans only its own local-package
outputs between variants, and requires byte-identical raw Wasms. It leaves
retained build/server/results evidence under the selected owning target.
`SHA256SUMS` enumerates every selected payload except itself. The public archive
contains only explicitly selected Metrics-owned sources, registry manifests/lock,
raw Wasms and experiment observations; prior evidence/private siblings are absent.
