#!/usr/bin/env bash
set -euo pipefail
export RUSTUP_AUTO_INSTALL=0
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${METRICS_TARGET_DIR:?Select an absolute directory under the owning Metrics target}"
: "${POCKET_IC_BIN:?Select the prepared PocketIC 16.1.0 Linux x86_64 executable}"
[[ "$METRICS_TARGET_DIR" == /* ]] || exit 1
[[ "$(rustc +1.99.0 -V)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]] || exit 1
actual="$(shasum -a 256 "$POCKET_IC_BIN")"
[[ "${actual%% *}" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]] || exit 1
mkdir -p "$METRICS_TARGET_DIR"
scratch="$(mktemp -d "$METRICS_TARGET_DIR/quantile-replay.XXXXXX")"
cp -R "$root/." "$scratch/"
bash "$scratch/build.sh"
for variant in baseline candidate; do
    for kernel in hist; do
        cmp "$root/$variant-$kernel.wasm" "$scratch/$variant-$kernel.wasm"
    done
done
driver="$(cat "$scratch/driver-path")"
"$driver" "$scratch" "$scratch/replay-results"
printf 'Byte-identical matched Wasm replay completed: %s\n' "$scratch"
