//! Frozen range-construction comparison. Setup and replies sit outside brackets.
use std::hint::black_box;
use ic_metrics::{MeasurementAggregate as Aggregate, MeasurementHistogram as Histogram};
fn histogram<const N: usize>(case: u8, iterations: u32) -> (u64, u128) {
    let bounds = std::array::from_fn::<_, N, _>(|i| i as u64);
    let mut h = Histogram::new(bounds).unwrap();
    if case < 7 { for sample in [0, 1, (N / 2) as u64, N.saturating_sub(1) as u64, N as u64] { h.record(sample); } }
    if case == 8 || case == 9 {
        let aggregate = Aggregate::from_parts(u64::MAX, 0, Some(0), true, false).unwrap();
        let mut counts = [0; N];
        let mut flags = [false; N];
        let overflow = if N == 0 { u64::MAX } else { counts[0] = u64::MAX; flags[0] = true; 0 };
        h = Histogram::from_parts(bounds, counts, overflow, flags, N == 0, aggregate).unwrap();
    }
    let (n, d) = match case {
        0 => (1, 2), 1 => (95, 100), 2 => (1, u64::MAX),
        3 => (u64::MAX, u64::MAX), 4 => (u64::MAX - 1, u64::MAX),
        5 => (u64::MAX / 5, u64::MAX), 6 => (u64::MAX / 5 + 1, u64::MAX),
        7 | 8 => (1, 2), _ => (0, 0),
    };
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let value = match black_box(&h).quantile_bucket(black_box(n), black_box(d)) {
            Ok(Some(range)) => {
                let lower = range.lower_exclusive().map_or(0, |v| u128::from(v) + 1);
                let upper = range.upper_inclusive().map_or(0, |v| u128::from(v) + 1);
                4 + (lower << 64) + upper
            },
            Ok(None) => 1,
            Err(ic_metrics::HistogramQueryError::InvalidQuantile) => 2,
            Err(ic_metrics::HistogramQueryError::CountOverflow) => 3,
            _ => panic!("unexpected histogram query error"),
        };
        sink = sink.wrapping_add(black_box(value));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}
#[ic_cdk::update]
fn compare(n: u16, case: u8, iterations: u32) -> (u64, u128) {
    assert!(iterations <= 1024 && case < 11);
    match n { 0 => histogram::<0>(case, iterations), 4 => histogram::<4>(case, iterations), 256 => histogram::<256>(case, iterations), _ => panic!("bad bounds") }
}
