#![no_std]
#![no_main]
use core::hint::black_box;
use ic_metrics::MeasurementAggregate;
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { core::arch::wasm32::unreachable() }
#[unsafe(no_mangle)]
pub extern "C" fn run(first: u64, second: u64, empty: u32) -> u128 {
    let mut values = MeasurementAggregate::EMPTY;
    if black_box(empty) == 0 {
        values.record(black_box(first));
        values.record(black_box(second));
    }
    let values = black_box(values);
    #[cfg(not(query))]
    { values.mean().unwrap().unwrap_or(u128::MAX) }
    #[cfg(query)]
    { values.interval_since(MeasurementAggregate::EMPTY).unwrap().mean().unwrap_or(u128::MAX) }
}
