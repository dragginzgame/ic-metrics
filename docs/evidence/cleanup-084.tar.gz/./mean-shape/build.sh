#!/usr/bin/env bash
set -euo pipefail
[[ $# == 3 ]] || { echo 'usage: build.sh BASELINE-SRC CANDIDATE-SRC NEW-OUTPUT' >&2; exit 2; }
probe="${BASH_SOURCE[0]%/*}/probe.rs"
probe="$(cd "${probe%/*}" && pwd -P)/${probe##*/}"
[[ ! -e "$3" && ! -L "$3" ]] || { echo 'output already exists' >&2; exit 1; }
mkdir "$3"
output="$(cd "$3" && pwd -P)"
rustc +1.99.0 -vV > "$output/compiler.txt"
flags=(--edition=2024 --target wasm32-unknown-unknown -C opt-level=z -C lto=fat -C codegen-units=1 -C panic=abort -C strip=symbols -D warnings)
for source in baseline candidate; do
    if [[ "$source" == baseline ]]; then src="$1/lib.rs"; else src="$2/lib.rs"; fi
    mkdir "$output/$source"
    rustc +1.99.0 "${flags[@]}" --crate-type rlib --crate-name ic_metrics "$src" -o "$output/$source/libic_metrics.rlib"
    for mode in record query; do
        cfg=(); [[ "$mode" != query ]] || cfg=(--cfg query)
        rustc +1.99.0 "${flags[@]}" --check-cfg 'cfg(query)' "${cfg[@]}" --crate-type cdylib --crate-name cleanup_probe \
            --extern "ic_metrics=$output/$source/libic_metrics.rlib" "$probe" -o "$output/$source/$mode.wasm"
    done
done
