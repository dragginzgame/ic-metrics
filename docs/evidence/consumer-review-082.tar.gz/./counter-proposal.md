## Demonstrated use

Read-only consumer review finds diagnostic scalar accumulation outside the shared measurement summaries:

- Timers `crates/ic-timers/src/snapshot/metrics.rs`: registration-local event counters use `u64::saturating_add`, with documented conservative treatment of an exact cap as saturated. Lifecycle classification, derived completion totals and registration identity remain Timers-owned.
- Toko `apps/toko_miner/game_shard/src/observability/action_metrics.rs`: replay/rejection/projection-failure/commit counts and intent bytes accumulate separately from instruction observations. Outcome/trap admission, action cohorts and public DTOs remain application-owned.
- Blob `canisters/test/storage_probe/src/ops/resources/mod.rs`: a byte diagnostic independently maintains a checked-add total plus a sticky overflow flag next to the instruction aggregate. This is a test probe, not production storage accounting.

The core currently supplies tracked aggregates/summaries/histograms, but no scalar counter. `MeasurementAggregate::record(1)` can already count events exactly; assess that simpler alternative before adding a type. Authoritative budgets, journal debt, spending, credits and lifecycle decisions are outside this proposal.

## Proposed investigation

Evaluate a small allocation-free, dependency-free, const-compatible scalar accumulator with explicit sticky actual overflow, checked addition/merge/restoration and exact-cap behavior. Select numeric width from real consumer quantity and report contracts; require checked projections at narrower DTO boundaries. Zero increments do not clear existing overflow. Typed failures, units, counter/window identity, resets and once-per-window alerts retain their established owners. Do not add platform reads, registries, labels or logging.

Avoid a count/total/maximum tuple for a scalar quantity when it has no observation distribution. Do not extract domain outcome classification or paired memory-page/lifecycle semantics. Keep existing sample aggregates unchanged. Start with the arithmetic requirement; any optional-store support needs its own explicit storage-kind/layout and retained-reader compatibility review, preserving current V1 records.

## Acceptance

Review the concrete producers and consumers, compare the existing-aggregate alternative, choose one current public contract, qualify zero/exact-cap/actual-overflow/merge/restore boundaries and the arithmetic native/Wasm Rust 1.85 floor. Any performance claim needs matched raw Wasm bytes and actual IC instruction/cycle evidence; native timing and estimated cycles are not evidence. Consumer public-type/DTO adoption remains separately owned, and should not block the already-published Metrics 0.8 recording migration.

This issue records a proposal, not a shipped API, approved sibling edit or release/version effect.
