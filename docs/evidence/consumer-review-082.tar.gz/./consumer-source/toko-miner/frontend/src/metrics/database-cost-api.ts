//! Reads one bounded Canic cache; IcyDB owns entity counters and window times.

import { Actor } from '@icp-sdk/core/agent';

import type {
  _SERVICE,
  PublicMetricsSnapshot,
} from '../generated/game-shard.service';
import { createTokoMinerAgent } from '../ic/canister-environment';
import { publicMetricsIdl } from './canic-public-metrics';

export interface DatabaseEntityCost {
  readonly path: string;
  readonly hits: bigint;
  readonly total: bigint;
  readonly maximum: bigint;
}

export type DatabaseCostSnapshot =
  | { readonly state: 'Disabled' | 'Unavailable' }
  | {
      readonly state: 'Fresh' | 'Stale';
      readonly sampledAtNs: bigint;
      readonly staleAfterNs: bigint;
      readonly windowStartMs: bigint;
      readonly windowEndMs: bigint;
      readonly entities: readonly DatabaseEntityCost[];
    };

export async function queryDatabaseCosts(
  canisterId: string,
): Promise<DatabaseCostSnapshot> {
  const agent = await createTokoMinerAgent();
  const actor = Actor.createActor<Pick<_SERVICE, 'canic_public_status'>>(
    publicMetricsIdl,
    { agent, canisterId },
  );
  const result = await actor.canic_public_status({
    Metrics: {
      family: { application: null },
      page: { offset: 0n, limit: 256n },
    },
  });
  if ('Err' in result || !('Metrics' in result.Ok)) {
    throw new Error('The published database snapshot is unavailable.');
  }
  return decodeDatabaseCosts(result.Ok.Metrics);
}

/** Reject incomplete snapshots rather than presenting partial costs as complete. */
export function decodeDatabaseCosts(
  snapshot: PublicMetricsSnapshot,
): DatabaseCostSnapshot {
  const invalid = () =>
    new Error('The published database snapshot is incomplete or invalid.');
  if (!('application' in snapshot.family)) throw invalid();
  if ('Disabled' in snapshot.state) return { state: 'Disabled' };
  if ('Unavailable' in snapshot.state) return { state: 'Unavailable' };
  const published = snapshot.metrics.entries;
  const rows = published.filter((row) => row.name.startsWith('icydb.'));
  const sampledAtNs = snapshot.sampled_at_ns[0];
  if (
    snapshot.truncated ||
    published.length > 256 ||
    rows.length > 194 ||
    BigInt(published.length) !== snapshot.metrics.total ||
    sampledAtNs === undefined
  )
    throw invalid();
  const values = new Map<string, bigint>();
  for (const row of rows) {
    if (
      !('Gauge' in row.kind) ||
      row.observed_at_ns !== sampledAtNs ||
      row.canister_id.length ||
      row.name.length > 128 ||
      values.has(row.name) ||
      row.value < 0n ||
      row.value > 18_446_744_073_709_551_615n
    )
      throw invalid();
    const window = /^icydb\.window_(start|end)_ms$/.test(row.name);
    const entity =
      /^icydb\.entity\.(.+)\.(hits|instructions_total|instructions_max)$/.exec(
        row.name,
      );
    const unit = window
      ? 'milliseconds'
      : entity?.[2] === 'hits'
        ? 'executions'
        : 'instructions';
    if ((!window && !entity) || row.unit !== unit) throw invalid();
    values.set(row.name, row.value);
  }
  const windowStartMs = values.get('icydb.window_start_ms');
  const windowEndMs = values.get('icydb.window_end_ms');
  if (
    windowStartMs === undefined ||
    windowEndMs === undefined ||
    windowStartMs > windowEndMs ||
    windowEndMs > 8_640_000_000_000_000n
  )
    throw invalid();
  const paths = new Set(
    rows.flatMap((row) => {
      const match =
        /^icydb\.entity\.(.+)\.(hits|instructions_total|instructions_max)$/.exec(
          row.name,
        );
      return match?.[1] ? [match[1]] : [];
    }),
  );
  if (paths.size > 64) throw invalid();
  const entities = [...paths]
    .map((path): DatabaseEntityCost => {
      const hits = values.get(`icydb.entity.${path}.hits`);
      const total = values.get(`icydb.entity.${path}.instructions_total`);
      const maximum = values.get(`icydb.entity.${path}.instructions_max`);
      if (
        hits === undefined ||
        total === undefined ||
        maximum === undefined ||
        maximum > total ||
        (hits === 0n && total !== 0n)
      )
        throw invalid();
      return { path, hits, total, maximum };
    })
    .sort((left, right) =>
      left.total === right.total
        ? left.path.localeCompare(right.path)
        : left.total > right.total
          ? -1
          : 1,
    );
  return {
    state: 'Stale' in snapshot.state ? 'Stale' : 'Fresh',
    sampledAtNs,
    staleAfterNs: snapshot.stale_after_ns,
    windowStartMs,
    windowEndMs,
    entities,
  };
}

export function averageInstructions(entity: DatabaseEntityCost): string {
  if (entity.hits === 0n) return 'Unavailable';
  if (
    entity.hits === 18_446_744_073_709_551_615n ||
    entity.total === 18_446_744_073_709_551_615n
  )
    return 'Unavailable (counter limit)';
  const tenths = (entity.total * 10n) / entity.hits;
  return `${(tenths / 10n).toLocaleString('en-GB')}.${tenths % 10n}`;
}

export function costBarPercent(total: bigint, largest: bigint): number {
  return largest === 0n ? 0 : Number((total * 10_000n) / largest) / 100;
}

export function formatDatabaseCounter(value: bigint): string {
  const bound = value === 18_446_744_073_709_551_615n ? '≥ ' : '';
  return `${bound}${value.toLocaleString('en-GB')}`;
}
