## Observed boundary

Current game-shard `observability/database_metrics.rs` publishes only entity hits, wide instruction total and maximum from IcyDB. `frontend/src/metrics/database-cost-api.ts` reconstructs a fractional mean and renders a lower-bound prefix by comparing values with `u64::MAX`. A total equal to `u64::MAX` is an ordinary exact `u128` total in Metrics 0.7/0.8; numeric caps do not establish actual overflow.

IcyDB's prepared 0.272 tracked-report contract in icydb#354 carries `samples_saturated`, `total_saturated` and an optional producer-admitted mean. Its current reviewed source is bf444afeb463 plus independent dirty work. Toko currently selects IcyDB 0.271; this issue owns the report bridge/client adoption of the new quality contract, not permission to silently upgrade that dependency.

## Owning correction

Carry source quality through the bounded application provider and database-cost decoder/display. Show unavailable exact means on actual overflow, retain empty/zero distinctions, and avoid declaring an exactly reached cap overflowed. An exact fractional projection may use integer arithmetic only after producer quality admission; do not reconstruct false flags from raw totals or missing fields. Preserve wide BigInt values without floating-point truncation, window/coverage identity and Gauge semantics; the IcyDB window does not establish lifetime counter continuity.

Coordinate the provider/DTO/generated client contract and capacity limits together. Adding quality fields must not silently truncate a complete report, exceed the existing public cache/page limit or publish partial entity selections. Use the pre-1.0 owning cut and retained-client disposition required by the actual consumer contract; no database/stable-data reset is implied by heap diagnostics.

## Acceptance

Test the real backend-to-wire-to-UI path for empty, measured zero, exact count/total caps, totals above u64, actual count/total overflow, missing/malformed quality and complete bounded coverage. Replace the current synthetic impossible total/maximum fixture with producer-representable observations where appropriate. Qualify the owning selected graph/native/runtime boundaries separately from Metrics arithmetic evidence.

Toko#48 owns the separate raw action-cohort recording migration; Toko#45 retains its original wide-total scope. No Toko files, versions or dependencies were edited by this read-only review.
