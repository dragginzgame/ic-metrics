#!/usr/bin/env bash
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: replay.sh METRICS_TARGET_DIR FRESH_OUTPUT_DIR' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
build="$1"
: "${POCKET_IC_BIN:?Prepare PocketIC 16.1.0 explicitly}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
mkdir -p "$build"
scratch="$(mktemp -d "$build/equality-replay.XXXXXX")"
cp -R "$root/fixture/." "$scratch/"
for variant in baseline candidate; do
    source="$root/baseline-core/src"
    features=(--features upgrade)
    if [[ "$variant" == candidate ]]; then
        source="$root/fixture/crates/ic-metrics/src"
        features=()
    fi
    rm -r "$scratch/crates/ic-metrics/src"
    cp -R "$source" "$scratch/crates/ic-metrics/src"
    # Copies may preserve timestamps older than the previous build. Force Cargo
    # to inspect the selected owner source rather than reusing its predecessor.
    find "$scratch/crates/ic-metrics/src" -type f -exec touch {} +
    cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$build" --offline --locked -p stable-probe --release --target wasm32-unknown-unknown "${features[@]}"
    cmp "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/fixture/$variant.wasm"
    rustc --edition=2024 --crate-name ic_metrics --crate-type rlib "$source/lib.rs" -o "$scratch/libic_metrics_$variant.rlib"
    status=0
    rustc --edition=2024 "$root/constant-pattern.rs" --extern "ic_metrics=$scratch/libic_metrics_$variant.rlib" -o "$scratch/pattern-$variant" > "$scratch/pattern-$variant.log" 2>&1 || status=$?
    if [[ "$variant" == baseline ]]; then [[ "$status" == 0 ]]; else [[ "$status" != 0 ]]; fi
done
cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$build" --offline --locked -p stable-driver
"$build/debug/stable-driver" "$root/fixture" "$2"
# Instruction counts and equality results are the decision inputs. Whole-update
# cycle observations remain in each CSV with their construction/ingress scope.
awk -F, 'NR>1 {print $1,$2,$3,$4,$5,$7}' "$root/results/costs.csv" > "$scratch/expected"
awk -F, 'NR>1 {print $1,$2,$3,$4,$5,$7}' "$2/costs.csv" > "$scratch/actual"
cmp "$scratch/expected" "$scratch/actual"
printf 'Equality experiment and constant-pattern rejection reproduced; scratch retained: %s\n' "$scratch"
