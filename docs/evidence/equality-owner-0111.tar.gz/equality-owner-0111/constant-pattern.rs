use ic_metrics::MeasurementHistogram;
const EMPTY: MeasurementHistogram<0> = match MeasurementHistogram::new([]) {
    Ok(value) => value,
    Err(_) => panic!("invalid fixture bounds"),
};
fn main() {
    assert!(matches!(EMPTY, EMPTY));
}
