//! Frozen matched equality experiment using the separately prepared server.
use candid::{Principal, decode_args, encode_args};
use ic_testkit::pic::{PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use std::{error::Error, fs, io::Write, path::PathBuf, time::Duration};
fn main() -> Result<(), Box<dyn Error>> {
    let root = PathBuf::from(std::env::args_os().nth(1).ok_or("root required")?);
    let output = PathBuf::from(std::env::args_os().nth(2).ok_or("output required")?);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new().with_application_subnet().try_build(config)?;
    let mut costs = fs::File::create(output.join("costs.csv"))?;
    writeln!(costs, "variant,n,case,repeat,instructions,cycles,equal")?;
    for variant in ["baseline", "candidate"] {
        let id = pic.create_canister();
        pic.add_cycles(id, 100_000_000_000_000);
        pic.install_canister(id, fs::read(root.join(format!("{variant}.wasm")))?, encode_args(())?, None);
        for n in [0_u16, 1, 4, 8, 256] {
            for case in 0_u8..4 {
                for repeat in 0..3 {
                    let balance = pic.cycle_balance(id);
                    let reply = pic.update_call(id, Principal::anonymous(), "compare", encode_args((n, case))?)
                        .map_err(|error| format!("{error:?}"))?;
                    let (instructions, equal): (u64, bool) = decode_args(&reply)?;
                    if equal != (case < 2) { return Err("equality result mismatch".into()); }
                    writeln!(costs, "{variant},{n},{case},{repeat},{instructions},{},{equal}", balance - pic.cycle_balance(id))?;
                }
            }
        }
    }
    Ok(())
}
