//! Frozen equality-only IC experiment; construction and encoding are outside the bracket.
use ic_metrics::MeasurementHistogram;
use std::hint::black_box;
fn measure<const N: usize>(case: u8) -> (u64, bool) {
    let mut before = MeasurementHistogram::new(std::array::from_fn::<_, N, _>(|i| i as u64)).unwrap();
    if case != 0 { before.record(0); }
    let mut after = before;
    if case == 2 { after.record(0); }
    if case == 3 { after.record(u64::MAX); }
    let before = black_box(before);
    let after = black_box(after);
    let start = ic_cdk::api::instruction_counter();
    let mut equal = false;
    for _ in 0..64 {
        let left = black_box(&after);
        let right = black_box(&before);
        #[cfg(feature = "upgrade")]
        { equal = if N < 4 { left == right } else { left.overflow() == right.overflow() && left.aggregate() == right.aggregate() && left == right }; }
        #[cfg(not(feature = "upgrade"))]
        { equal = left == right; }
        black_box(equal);
    }
    (ic_cdk::api::instruction_counter() - start, equal)
}
#[ic_cdk::update]
fn compare(n: u16, case: u8) -> (u64, bool) {
    match n { 0 => measure::<0>(case), 1 => measure::<1>(case), 4 => measure::<4>(case), 8 => measure::<8>(case), 256 => measure::<256>(case), _ => unreachable!() }
}
