#!/usr/bin/env bash
set -euo pipefail
[[ $# == 1 ]] || { echo 'usage: replay.sh METRICS_TARGET_DIRECTORY' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${POCKET_IC_BIN:?Select the prepared PocketIC 16.1.0 executable}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
(cd "$root" && shasum -a 256 -c SHA256SUMS)
mkdir -p "$1"
scratch="$(mktemp -d "$1/sample-selection.XXXXXX")"
cp -R "$root/." "$scratch/"
for variant in baseline candidate; do
    rm -r "$scratch/crates/ic-metrics/src"
    cp -R "$scratch/$variant/src" "$scratch/crates/ic-metrics/src"
    find "$scratch/crates/ic-metrics/src" -type f -exec touch {} +
    cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$1/build" --locked --offline --release -p stable-probe --target wasm32-unknown-unknown --features samples > "$scratch/rebuild-$variant.log" 2>&1
    cmp "$1/build/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/$variant-samples.wasm"
done
cargo build --manifest-path "$scratch/Cargo.toml" --target-dir "$1/build" --locked --offline -p stable-driver > "$scratch/rebuild-driver.log" 2>&1
"$1/build/debug/stable-driver" "$scratch" "$scratch/replayed-results"
cmp "$root/results/costs.csv" "$scratch/replayed-results/costs.csv"
echo "Exact Wasm bytes and all IC observations reproduced: $scratch"
