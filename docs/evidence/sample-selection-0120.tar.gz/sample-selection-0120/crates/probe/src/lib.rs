//! Matched sample-selection probe; all inputs and copies are outside the instruction bracket.
use std::hint::black_box;
#[ic_cdk::update]
fn compare(case: u8, iterations: u32) -> (u64, u128) {
    assert!(case < 60 && iterations <= 8);
    let length = [5, 8, 32, 256, 1024][usize::from(case / 12)];
    let pattern = (case / 3) % 4;
    let (n,d) = match case % 3 { 0 => (1,2), 1 => (95,100), _ => (u64::MAX,u64::MAX) };
    let original: Vec<f64> = (0..length).map(|i| {
        let value = match pattern { 0 => (i*17)%length, 1 => i, 2 => length-i-1, _ => i%3 };
        if value == 0 && pattern == 3 { -0.0 } else { 5.0 * f64::from(value as u32) }
    }).collect();
    let mut values = original.clone();
    let mut instructions = 0;
    let mut sink = 0_u128;
    for _ in 0..iterations {
        values.copy_from_slice(&original);
        let start = ic_cdk::api::instruction_counter();
        let r = ic_metrics::summarize_samples(black_box(&mut values), black_box(n), black_box(d)).unwrap().unwrap();
        instructions += ic_cdk::api::instruction_counter() - start;
        let bits = r.minimum.to_bits() ^ r.maximum.to_bits() ^ r.mean.to_bits() ^ r.median.to_bits() ^ r.quantile.to_bits();
        sink = sink.wrapping_add(u128::from(bits)).wrapping_add(r.count as u128);
        black_box(sink);
    }
    (instructions,sink)
}
