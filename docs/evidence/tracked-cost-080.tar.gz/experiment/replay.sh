#!/usr/bin/env bash
# Frozen Linux IC comparison. Explicit preparation is separate from replay.
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: replay.sh OWNED-TARGET-DIRECTORY NEW-RESULT-DIRECTORY' >&2; exit 2; }
fixture="$(cd -P "${BASH_SOURCE[0]%/*}" && pwd)"
build=$1
output=$2
: "${POCKET_IC_BIN:?Supply the prepared PocketIC 16.1.0 executable}"
[[ "$(uname -s):$(uname -m)" == Linux:x86_64 ]] || { echo 'This frozen experiment selects Linux x86_64.' >&2; exit 2; }
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]] || { echo 'This experiment selects Rust 1.99.0.' >&2; exit 2; }
[[ -z ${IC_TESTKIT_POCKET_IC_URL+x} ]] || { echo 'This frozen comparison requires its exact local server.' >&2; exit 2; }
digest=$(sha256sum -- "$POCKET_IC_BIN")
[[ ${digest%% *} == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]] || { echo 'Selected server differs from the frozen server.' >&2; exit 2; }
(cd "$fixture" && sha256sum -c inputs.sha256)
for prefix in baseline tracked; do
    for variant in count summary aggregate histogram aggregate-merge histogram-merge aggregate-query histogram-query scaled-query; do
        features=$variant
        [[ "$prefix" != baseline ]] || features="baseline,$variant"
        cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --target wasm32-unknown-unknown --features "$features" -- -D warnings
        cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --release --target wasm32-unknown-unknown --features "$features"
        cmp "$build/wasm32-unknown-unknown/release/arithmetic_cost_probe.wasm" "$fixture/artifacts/$prefix-$variant.wasm"
    done
done
cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver -- -D warnings
cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver
"$build/debug/arithmetic-cost-driver" "$fixture" "$output"
cmp "$fixture/run-1/results.csv" "$output/results.csv"
cmp "$fixture/run-1/sizes.csv" "$output/sizes.csv"
