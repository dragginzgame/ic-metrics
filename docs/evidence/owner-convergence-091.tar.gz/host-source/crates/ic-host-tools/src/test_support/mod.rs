use ic_host_fs::read::hash_file;

use ic_host_process::tool::{AdmittedTool, ExecutionContext, OutputLimits, ToolSpec};
use std::{
    ffi::OsString,
    fs,
    path::{Path, PathBuf},
    sync::{
        Mutex, MutexGuard,
        atomic::{AtomicU64, Ordering},
    },
    time::Duration,
};

static PROCESS_FIXTURES: Mutex<()> = Mutex::new(());
static SEQUENCE: AtomicU64 = AtomicU64::new(0);

pub const LIMITS: OutputLimits = OutputLimits {
    stdout: ic_host_process::tool::OutputLimit::Terminate(256 * 1024),
    stderr: ic_host_process::tool::OutputLimit::Terminate(256 * 1024),
    timeout: Some(Duration::from_secs(5)),
};
pub const VERSION: &str = "test-host-tool version 1";

pub struct Fixture {
    pub root: PathBuf,
    _guard: MutexGuard<'static, ()>,
}

impl Fixture {
    pub fn new() -> Self {
        // Serialize mutable executable-fixture writes against subprocess fork
        // within this test binary; no production executable-busy retry is added.
        let guard = PROCESS_FIXTURES
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let root = loop {
            let candidate = std::env::temp_dir().join(format!(
                "ic-host-tools-test-{}-{}",
                std::process::id(),
                SEQUENCE.fetch_add(1, Ordering::Relaxed)
            ));
            match fs::create_dir(&candidate) {
                Ok(()) => break candidate,
                Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
                Err(error) => panic!("cannot create fixture {}: {error}", candidate.display()),
            }
        };
        Self {
            root: root.canonicalize().unwrap(),
            _guard: guard,
        }
    }

    pub fn context<'a>(&'a self, environment: &'a [(OsString, OsString)]) -> ExecutionContext<'a> {
        ExecutionContext {
            current_dir: &self.root,
            environment,
        }
    }

    pub fn tool(&self) -> AdmittedTool {
        let path = Path::new(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/fixtures/tool.sh"
        ))
        .canonicalize()
        .unwrap();
        let identity = hash_file(&path, 1024 * 1024).unwrap();
        AdmittedTool::admit(
            &ToolSpec {
                executable: &path,
                sha256: identity.sha256,
                executable_bytes: 1024 * 1024,
                version_arguments: &[OsString::from("--version")],
                version_identity: VERSION,
            },
            &self.context(&[]),
            LIMITS,
        )
        .unwrap()
    }

    pub fn source(&self) -> PathBuf {
        let source = self.root.join("source.wasm");
        fs::write(&source, b"\0asm\x01\0\0\0").unwrap();
        source
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        if std::thread::panicking() {
            eprintln!("Failed tools fixture retained: {}", self.root.display());
            return;
        }
        let _ = fs::remove_dir_all(&self.root);
    }
}
