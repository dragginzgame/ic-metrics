//! Independent state oracle, upgrades and raw IC costs for the frozen fixture.
use candid::{Principal, decode_one, encode_args};
use ic_testkit::pic::{PocketIc, PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use stable_protocol::{Measured, ProbeError, Snapshot};
use std::{error::Error, fmt, fs, io::Write, path::PathBuf, time::Duration};

#[derive(Debug)]
enum Failure {
    Arguments,
    Check(&'static str),
    Rejected(ic_testkit::pic::RejectResponse),
    Probe(ProbeError),
}
impl fmt::Display for Failure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Arguments => f.write_str("expected fixture and fresh output directories"),
            Self::Check(name) => write!(f, "qualification failed: {name}"),
            Self::Rejected(rejection) => write!(f, "IC rejection: {rejection}"),
            Self::Probe(error) => write!(f, "typed probe failure: {error:?}"),
        }
    }
}
impl Error for Failure {}
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn check(ok: bool, name: &'static str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(Failure::Check(name).into())
    }
}
fn update(pic: &PocketIc, id: Principal, method: &str, args: Vec<u8>) -> Result<Vec<u8>> {
    Ok(pic
        .update_call(id, Principal::anonymous(), method, args)
        .map_err(Failure::Rejected)?)
}
fn read(
    pic: &PocketIc,
    id: Principal,
    epoch: u64,
) -> Result<std::result::Result<Snapshot, ProbeError>> {
    Ok(decode_one(
        &pic.query_call(
            id,
            Principal::anonymous(),
            "snapshot",
            encode_args((epoch,))?,
        )
        .map_err(Failure::Rejected)?,
    )?)
}
fn action(pic: &PocketIc, id: Principal, method: &str, args: Vec<u8>) -> Result<()> {
    decode_one::<std::result::Result<(), ProbeError>>(&update(pic, id, method, args)?)?
        .map_err(Failure::Probe)?;
    Ok(())
}
fn expected(id: u8, build: u8, append: Option<u64>) -> Snapshot {
    let max = u128::from(u64::MAX);
    let count = 4 + u128::from(append.is_some());
    let total = 2 * max + 9 + u128::from(append.unwrap_or(0));
    let a = vec![count, total, 1, max, 0, 0];
    let mut s = a.clone();
    s.extend([1, u128::from(append.unwrap_or(9))]);
    let mut h = a.clone();
    h.extend([1, 1 + u128::from(append.is_some()), 2, 0, 0, 0]);
    Snapshot {
        aggregate: a,
        summary: s,
        histogram: h,
        capped: vec![max, u128::MAX, 1, max, 1, 1],
        bucket_cap: vec![max, 0, 1, 0, 1, 0, max, 0, 1, 0],
        overflow_cap: vec![max, max * max, 1, max, 1, 0, 0, max, 0, 1],
        zero: vec![1, 0, 1, 0, 0, 0, 1, 0],
        empty: vec![0, 0, 0, 0, 0, 0, 0, 0],
        missing: true,
        memory_id: id,
        build,
    }
}
fn main() -> Result<()> {
    let mut args = std::env::args_os().skip(1);
    let (Some(root), Some(output), None) = (args.next(), args.next(), args.next()) else {
        return Err(Failure::Arguments.into());
    };
    let root = PathBuf::from(root);
    let output = PathBuf::from(output);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new()
        .with_application_subnet()
        .try_build(config)?;
    let mut cases = fs::File::create(output.join("qualification.tsv"))?;
    writeln!(cases, "case\tresult")?;
    let mut states = fs::File::create(output.join("states.txt"))?;
    let mut sizes = fs::File::create(output.join("sizes.csv"))?;
    writeln!(sizes, "variant,raw_wasm_bytes")?;
    let mut costs = fs::File::create(output.join("costs.csv"))?;
    writeln!(
        costs,
        "variant,iterations,cadence,repeat,nonce,before,after,instructions,cycles_before,cycles_after,cycles,samples,total"
    )?;
    let mut nonce = 0_u64;
    for durable in [false, true] {
        let variant = if durable { "durable" } else { "volatile" };
        let wasm = fs::read(root.join("artifacts").join(format!("{variant}.wasm")))?;
        let upgrade = fs::read(
            root.join("artifacts")
                .join(format!("{variant}-upgrade.wasm")),
        )?;
        writeln!(sizes, "{variant},{}", wasm.len())?;
        writeln!(sizes, "{variant}-upgrade,{}", upgrade.len())?;
        let id = pic.create_canister();
        pic.add_cycles(id, 100_000_000_000_000);
        pic.install_canister(id, wasm.clone(), encode_args(())?, None);
        check(
            read(&pic, id, 0)? == Err(ProbeError::Missing),
            "absent store before seed",
        )?;
        action(&pic, id, "seed", encode_args((0_u64,))?)?;
        let initial = read(&pic, id, 0)?.map_err(Failure::Probe)?;
        writeln!(states, "{variant} initial: {initial:?}")?;
        let memory_id = initial.memory_id;
        check(
            initial == expected(memory_id, 0, None),
            "mixed rows, flags, zeros and missing",
        )?;
        action(&pic, id, "seed", encode_args((0_u64,))?)?;
        check(
            read(&pic, id, 0)? == Ok(initial.clone()),
            "idempotent checkpoint",
        )?;
        if durable {
            for (which, error) in [
                (0_u8, ProbeError::Identity),
                (1, ProbeError::Bounds),
                (2, ProbeError::Regression),
            ] {
                let result = decode_one::<std::result::Result<(), ProbeError>>(&update(
                    &pic,
                    id,
                    "reject",
                    encode_args((which, 0_u64))?,
                )?)?;
                check(result == Err(error), "typed incompatible checkpoint")?;
                check(
                    read(&pic, id, 0)? == Ok(initial.clone()),
                    "refusal preserves every row",
                )?;
            }
            let response = pic
                .query_call(
                    id,
                    Principal::anonymous(),
                    "query_append",
                    encode_args((0_u64, 5_u64))?,
                )
                .map_err(Failure::Rejected)?;
            check(
                decode_one::<std::result::Result<(), ProbeError>>(&response)? == Ok(()),
                "query executes write",
            )?;
            check(
                read(&pic, id, 0)? == Ok(initial.clone()),
                "query writes discarded",
            )?;
            check(
                matches!(pic.update_call(
                    id,
                    Principal::anonymous(),
                    "trap_after_write",
                    encode_args((0_u64, 5_u64))?,
                )
                , Err(ref rejection) if rejection.error_code == ic_testkit::pocket_ic::ErrorCode::CanisterCalledTrap),
                "intentional update trap",
            )?;
            check(
                read(&pic, id, 0)? == Ok(initial.clone()),
                "trapping update rolls back",
            )?;
        }
        pic.upgrade_canister(id, upgrade, encode_args(())?, None)
            .map_err(Failure::Rejected)?;
        if durable {
            writeln!(states, "durable after upgrade: {:?}", read(&pic, id, 0)?)?;
            check(
                read(&pic, id, 0)? == Ok(expected(memory_id, 1, None)),
                "upgrade retains all rows and ID",
            )?;
            action(&pic, id, "append", encode_args((0_u64, 5_u64))?)?;
            writeln!(states, "durable continued: {:?}", read(&pic, id, 0)?)?;
            check(
                read(&pic, id, 0)? == Ok(expected(memory_id, 1, Some(5))),
                "continued recording after upgrade",
            )?;
            pic.upgrade_canister(id, wasm, encode_args(())?, None)
                .map_err(Failure::Rejected)?;
            check(
                read(&pic, id, 0)? == Ok(expected(memory_id, 0, Some(5))),
                "second upgrade retains continuation",
            )?;
            action(&pic, id, "reset", encode_args((0_u64,))?)?;
            writeln!(states, "durable reset: {:?}", read(&pic, id, 1)?)?;
            check(
                read(&pic, id, 0)? == Err(ProbeError::Identity),
                "old reset epoch refused",
            )?;
            check(
                read(&pic, id, 1)? == Ok(expected(memory_id, 0, None)),
                "explicit same-message reset retains ID",
            )?;
        } else {
            check(
                read(&pic, id, 0)? == Err(ProbeError::Missing),
                "volatile heap cleared on upgrade",
            )?;
        }
        writeln!(cases, "{variant}-lifecycle\tPASS")?;
        // Costs have a separately installed fresh map and deterministic row order.
        let cost = pic.create_canister();
        pic.add_cycles(cost, 100_000_000_000_000);
        pic.install_canister(
            cost,
            fs::read(root.join("artifacts").join(format!("{variant}.wasm")))?,
            encode_args(())?,
            None,
        );
        for iterations in [0_u32, 1, 16, 256] {
            for cadence in [1_u32, 16, 256] {
                for repeat in 0..3 {
                    nonce += 1;
                    let before = pic.cycle_balance(cost);
                    let reply = decode_one::<std::result::Result<Measured, ProbeError>>(&update(
                        &pic,
                        cost,
                        "measure",
                        encode_args((iterations, cadence, nonce))?,
                    )?)?
                    .map_err(Failure::Probe)?;
                    let after = pic.cycle_balance(cost);
                    check(
                        reply.samples == u64::from(iterations)
                            && reply.total == u128::from(iterations) * 7,
                        "cost independent arithmetic oracle",
                    )?;
                    let instructions = reply
                        .after
                        .checked_sub(reply.before)
                        .ok_or(Failure::Check("instruction regression"))?;
                    let cycles = before
                        .checked_sub(after)
                        .ok_or(Failure::Check("cycle balance increase"))?;
                    writeln!(
                        costs,
                        "{variant},{iterations},{cadence},{repeat},{nonce},{},{},{instructions},{before},{after},{cycles},{},{}",
                        reply.before, reply.after, reply.samples, reply.total
                    )?;
                }
            }
        }
        let bad = decode_one::<std::result::Result<Measured, ProbeError>>(&update(
            &pic,
            cost,
            "measure",
            encode_args((1025_u32, 1_u32, nonce + 1))?,
        )?)?;
        check(bad == Err(ProbeError::Input), "bounded cost workload")?;
        writeln!(cases, "{variant}-cost-oracles\tPASS")?;
    }
    println!("Mixed-row upgrades, message rollback/reset and 72 cost replies passed");
    Ok(())
}
