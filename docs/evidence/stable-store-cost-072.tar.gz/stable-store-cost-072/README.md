# Frozen one-map IC storage qualification

This Linux evidence artifact owns a copied arithmetic/store source, private
canister, protocol and driver. It adds no product endpoint, CI gate, Testkit
dependency or maintained server caller. Private version 0.0.0 is initial fixture
metadata, not a selected product release. Only the five local packages lack a
registry source; no external path dependencies or mutable sibling sources exist.

The 16 copied product Rust files match released Metrics 0.7.1
`569a388bb0066bb51ede6095d88b40a65f36e82a` exactly. Private manifests select this
experiment's graph rather than reproducing published metadata. The graph locks
Testkit 0.34.2, PocketIC 16.1.0, IC Memory 0.35.14, all four Host packages 0.14.4,
CDK 0.20.3 and Candid 0.10.38. `inputs` binds source, selected rows and the separate
product graph. Rust 1.99.0 is the experiment compiler; library floors stay 1.85
for arithmetic and 1.88 for the store/inspector. Release compilation uses
opt-level=z, LTO, one codegen unit, symbol stripping and panic abort, with no
Wasm postprocessing.

Testkit owns fallible server startup and protocol/version admission. Select an
explicitly prepared PocketIC 16.1.0 payload with SHA-256
`b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db`;
the previously admitted official archive hash is
`131219d90dcf9bf6f3ed8ee02d8f55504ea24a6db382f5680675b7bd6b7ed3bf`.
No server is bundled, downloaded or installed here. Original execution uses an
owner-prepared server outside Metrics; replay selects exact bytes independently
of that original location. No sibling source is edited or built.

The durable host bootstraps its one `app.metrics.v1` application map through
`MemoryRuntime` in init/post-upgrade. Governance allocations remain separate.
Eight namespaced rows retain an aggregate, summary, two-bound histogram, actual
count/total overflow flags, bucket/overflow flags, measured-zero summary and empty
summary. Wide/capped values are synthetic restored test states, not purported
platform measurements. The driver checks them independently with u128 arithmetic.
One absent namespace is distinct from both empty and measured zero.

The driver checks identical saves, incompatible epochs/bounds and numeric
regressions without row changes, a query that writes but leaves retained state
unchanged, and an explicit update trap (`CanisterCalledTrap`) rolling back all
writes. It performs two actual upgrades of the same canister, checks build markers,
all fields/flags and the retained application memory ID, then continues recording.
A same-message explicit reset advances the host-selected epoch without changing
that ID; the old epoch is refused. The matched volatile canister loses its heap
state on upgrade. No async callback, mainnet or consumer attribution claim follows.

Cost canisters are separately installed/funded, starting with a fresh map and
deterministic row order. Every update records zero, one, 16 or 256 observations
of value seven. Cadences are one, 16 or 256 observations per checkpoint, each
repeated three times, using a fresh namespaced row per call. Volatile recording
uses the same arithmetic/reply path with no stable checkpoint. The zero-iteration
controls write no row. A workload above 1,024 returns a typed input refusal.

Raw counters bracket recording and checkpoint loops, including the store's
bounded load/validation/encoding/write path. Key construction, lifecycle bootstrap,
result projection and Candid encoding are outside this bracket. Actual whole-update
cycle-balance decreases include execution/ingress/reply costs; initial bootstrap,
installation and upgrades are excluded. Each canister receives 100 trillion extra
cycles before install. Growing B-tree state/row order affects repeat costs. Retain
the full trajectory rather than claiming a universal per-write price or subtracting
controls into an estimated cycle conversion. Raw Wasm bytes compare the complete
matched fixture binaries, not isolated library size.

`run-2` and `run-3` are independent server runs. All 72 measured replies, four
qualification outcomes, raw state observations and size rows agree byte-for-byte.
The driver executes the lifecycle assertions before writing a successful outcome.
`run-1` retains the initial failure: the assertion expected implicit trap code 502
rather than explicit trap code 503. Its preceding successful volatile costs and
earlier durable checks remain partial evidence, not a full pass. The original
driver is retained in `initial`. Probe/driver initial Clippy failures and their
source are retained there and in `logs`; warnings are fixed before execution.

To replay after preparing the selected locked cache and exact server explicitly:

```sh
export POCKET_IC_BIN=/absolute/path/to/admitted/pocket-ic
unset IC_TESTKIT_POCKET_IC_URL
bash replay.sh /absolute/metrics/target/stable-store-rebuild-072 \
  /absolute/metrics/target/evidence/stable-store-replay-072
```

`inputs.sha256` binds all payloads, including source, lock, script, Wasms and
successful/failed outputs. Replay checks every hash, rebuilds all four Wasms
byte-for-byte with warning-denied Clippy, builds the host driver, then compares
all four raw result files on a fresh server. Caches and the server remain separate
explicit inputs. Product CI/native consumer acceptance is not part of this replay.
