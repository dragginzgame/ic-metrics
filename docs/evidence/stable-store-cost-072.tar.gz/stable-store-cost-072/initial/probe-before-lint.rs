//! Frozen host-owned lifecycle and storage workload for Metrics issue 64.
use ic_metrics::{MeasurementAggregate as A, MeasurementHistogram as H, MeasurementSummary as S};
use stable_protocol::{Measured, ProbeError as E, Snapshot};
use std::cell::RefCell;

#[derive(Clone)]
struct Values {
    a: A,
    s: S,
    h: H<2>,
    cap: A,
    bc: H<1>,
    oc: H<1>,
    zero: S,
    empty: S,
}

#[cfg(feature = "durable")]
mod storage {
    use super::*;
    use ic_memory::{
        GenericAllocationPolicy, MemoryAllocationPool, MemoryAuthority, MemoryRequest,
        MemoryRuntime, RuntimeMemory, SchemaMetadata, SealedDeclarationSnapshot,
        ic_stable_structures::{BTreeMap, DefaultMemoryImpl},
    };
    use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsStore, StoreError};

    struct Host {
        store: MetricsStore<RuntimeMemory<DefaultMemoryImpl>>,
        id: u8,
    }
    thread_local! { static HOST: RefCell<Option<Host>> = const { RefCell::new(None) }; }
    fn error(e: StoreError) -> E {
        match e {
            StoreError::IdentityMismatch => E::Identity,
            StoreError::BoundsMismatch => E::Bounds,
            StoreError::StateRegression => E::Regression,
            _ => E::Storage,
        }
    }
    fn key(ns: &str, name: &str) -> Result<MetricKey, E> {
        MetricKey::new(ns, name).map_err(error)
    }
    fn identity(epoch: u64) -> Result<MetricIdentity, E> {
        MetricIdentity::new("instructions", epoch).map_err(error)
    }
    pub fn open() {
        let pool = MemoryAllocationPool::new(
            vec![MemoryAuthority::new("app", "app.").expect("fixture authority")],
            vec![],
        )
        .expect("fixture pool");
        let declarations = SealedDeclarationSnapshot::new(&[MemoryRequest::new(
            "app",
            "app.metrics.v1",
            SchemaMetadata::default(),
        )
        .expect("fixture request")])
        .expect("fixture declarations");
        let mut runtime =
            MemoryRuntime::new(DefaultMemoryImpl::default()).expect("fixture runtime");
        runtime
            .bootstrap(&declarations, &pool, &GenericAllocationPolicy)
            .expect("fixture bootstrap");
        let id = runtime
            .memory_id("app.metrics.v1")
            .expect("fixture binding");
        let store = MetricsStore::new(BTreeMap::init(
            runtime.open_memory("app.metrics.v1").expect("fixture map"),
        ));
        HOST.with(|h| *h.borrow_mut() = Some(Host { store, id }));
    }
    pub fn read(epoch: u64) -> Result<(Values, u8), E> {
        HOST.with(|h| {
            let h = h.borrow();
            let host = h.as_ref().ok_or(E::Missing)?;
            let store = &host.store;
            let i = identity(epoch)?;
            Ok((
                Values {
                    a: store
                        .load(&key("a", "work")?, &i, &A::EMPTY)
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    s: store
                        .load(&key("s", "work")?, &i, &S::EMPTY)
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    h: store
                        .load(
                            &key("h", "work")?,
                            &i,
                            &H::new([0, 10]).map_err(|_| E::Input)?,
                        )
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    cap: store
                        .load(&key("a", "cap")?, &i, &A::EMPTY)
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    bc: store
                        .load(
                            &key("h", "bucket-cap")?,
                            &i,
                            &H::new([0]).map_err(|_| E::Input)?,
                        )
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    oc: store
                        .load(
                            &key("h", "overflow-cap")?,
                            &i,
                            &H::new([0]).map_err(|_| E::Input)?,
                        )
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    zero: store
                        .load(&key("s", "zero")?, &i, &S::EMPTY)
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                    empty: store
                        .load(&key("s", "empty")?, &i, &S::EMPTY)
                        .map_err(error)?
                        .ok_or(E::Missing)?,
                },
                host.id,
            ))
        })
    }
    pub fn write(v: &Values, epoch: u64) -> Result<(), E> {
        HOST.with(|h| {
            let mut h = h.borrow_mut();
            let host = h.as_mut().ok_or(E::Missing)?;
            let store = &mut host.store;
            let i = identity(epoch)?;
            store.save(&key("a", "work")?, &i, &v.a).map_err(error)?;
            store.save(&key("s", "work")?, &i, &v.s).map_err(error)?;
            store.save(&key("h", "work")?, &i, &v.h).map_err(error)?;
            store.save(&key("a", "cap")?, &i, &v.cap).map_err(error)?;
            store
                .save(&key("h", "bucket-cap")?, &i, &v.bc)
                .map_err(error)?;
            store
                .save(&key("h", "overflow-cap")?, &i, &v.oc)
                .map_err(error)?;
            store.save(&key("s", "zero")?, &i, &v.zero).map_err(error)?;
            store
                .save(&key("s", "empty")?, &i, &v.empty)
                .map_err(error)?;
            Ok(())
        })
    }
    pub fn reject(which: u8, epoch: u64) -> Result<(), E> {
        HOST.with(|h| {
            let mut h = h.borrow_mut();
            let host = h.as_mut().ok_or(E::Missing)?;
            let i = identity(epoch)?;
            match which {
                0 => host
                    .store
                    .save(&key("a", "work")?, &identity(epoch + 1)?, &A::EMPTY),
                1 => host.store.save(
                    &key("h", "work")?,
                    &i,
                    &H::new([0, 11]).map_err(|_| E::Input)?,
                ),
                2 => host.store.save(&key("a", "work")?, &i, &A::EMPTY),
                _ => return Err(E::Input),
            }
            .map_err(error)
        })
    }
    pub fn reset(epoch: u64) -> Result<(), E> {
        HOST.with(|h| {
            let mut h = h.borrow_mut();
            let host = h.as_mut().ok_or(E::Missing)?;
            let i = identity(epoch)?;
            for (ns, name) in [
                ("a", "work"),
                ("s", "work"),
                ("h", "work"),
                ("a", "cap"),
                ("h", "bucket-cap"),
                ("h", "overflow-cap"),
                ("s", "zero"),
                ("s", "empty"),
            ] {
                if !host.store.remove(&key(ns, name)?, &i).map_err(error)? {
                    return Err(E::Missing);
                }
            }
            Ok(())
        })
    }
    pub fn checkpoint(name: &str, a: &A) -> Result<(), E> {
        HOST.with(|h| {
            let mut h = h.borrow_mut();
            let host = h.as_mut().ok_or(E::Missing)?;
            host.store
                .save(&key("cost", name)?, &identity(0)?, a)
                .map_err(error)
        })
    }
    pub fn missing(epoch: u64) -> Result<bool, E> {
        HOST.with(|h| {
            let h = h.borrow();
            let host = h.as_ref().ok_or(E::Missing)?;
            Ok(host
                .store
                .load(&key("absent", "work")?, &identity(epoch)?, &A::EMPTY)
                .map_err(error)?
                .is_none())
        })
    }
}

#[cfg(not(feature = "durable"))]
mod storage {
    use super::*;
    thread_local! { static HEAP: RefCell<Option<(Values,u64)>> = const { RefCell::new(None) }; }
    pub fn open() {}
    pub fn read(epoch: u64) -> Result<(Values, u8), E> {
        HEAP.with(|h| {
            let h = h.borrow();
            let (v, e) = h.as_ref().ok_or(E::Missing)?;
            if *e != epoch {
                return Err(E::Identity);
            }
            Ok((v.clone(), 0))
        })
    }
    pub fn write(v: &Values, epoch: u64) -> Result<(), E> {
        HEAP.with(|h| *h.borrow_mut() = Some((v.clone(), epoch)));
        Ok(())
    }
    pub fn checkpoint(_: &str, _: &A) -> Result<(), E> {
        Ok(())
    }
    pub fn missing(_: u64) -> Result<bool, E> {
        Ok(true)
    }
    pub fn reject(which: u8, _: u64) -> Result<(), E> {
        Err(match which {
            0 => E::Identity,
            1 => E::Bounds,
            2 => E::Regression,
            _ => E::Input,
        })
    }
    pub fn reset(_: u64) -> Result<(), E> {
        HEAP.with(|h| *h.borrow_mut() = None);
        Ok(())
    }
}

#[ic_cdk::init]
fn init() {
    storage::open();
}
#[ic_cdk::post_upgrade]
fn post_upgrade() {
    storage::open();
}

fn aggregate(a: A) -> Vec<u128> {
    vec![
        u128::from(a.samples()),
        a.total(),
        u128::from(a.maximum().is_some()),
        u128::from(a.maximum().unwrap_or(0)),
        u128::from(a.samples_saturated()),
        u128::from(a.total_saturated()),
    ]
}
fn summary(s: S) -> Vec<u128> {
    let mut v = aggregate(s.aggregate());
    v.extend([
        u128::from(s.latest().is_some()),
        u128::from(s.latest().unwrap_or(0)),
    ]);
    v
}
fn histogram<const N: usize>(h: &H<N>) -> Vec<u128> {
    let mut v = aggregate(h.aggregate());
    v.extend(h.bucket_counts().iter().copied().map(u128::from));
    v.push(u128::from(h.overflow()));
    v.extend(h.bucket_saturation().iter().copied().map(u128::from));
    v.push(u128::from(h.overflow_saturated()));
    v
}

#[ic_cdk::query]
fn snapshot(epoch: u64) -> Result<Snapshot, E> {
    let (v, id) = storage::read(epoch)?;
    Ok(Snapshot {
        aggregate: aggregate(v.a),
        summary: summary(v.s),
        histogram: histogram(&v.h),
        capped: aggregate(v.cap),
        bucket_cap: histogram(&v.bc),
        overflow_cap: histogram(&v.oc),
        zero: summary(v.zero),
        empty: summary(v.empty),
        missing: storage::missing(epoch)?,
        memory_id: id,
        build: u8::from(cfg!(feature = "upgrade")),
    })
}

#[ic_cdk::update]
fn seed(epoch: u64) -> Result<(), E> {
    let mut a = A::EMPTY;
    let mut s = S::EMPTY;
    let mut h = H::new([0, 10]).map_err(|_| E::Input)?;
    for value in [0, u64::MAX, u64::MAX, 9] {
        a.record(value);
        s.record(value);
        h.record(value);
    }
    let cap =
        A::from_parts(u64::MAX, u128::MAX, Some(u64::MAX), true, true).map_err(|_| E::Input)?;
    let bc = H::from_parts(
        [0],
        [u64::MAX],
        0,
        [true],
        false,
        A::from_parts(u64::MAX, 0, Some(0), true, false).map_err(|_| E::Input)?,
    )
    .map_err(|_| E::Input)?;
    let oc = H::from_parts(
        [0],
        [0],
        u64::MAX,
        [false],
        true,
        A::from_parts(
            u64::MAX,
            u128::from(u64::MAX).pow(2),
            Some(u64::MAX),
            true,
            false,
        )
        .map_err(|_| E::Input)?,
    )
    .map_err(|_| E::Input)?;
    let mut zero = S::EMPTY;
    zero.record(0);
    storage::write(
        &Values {
            a,
            s,
            h,
            cap,
            bc,
            oc,
            zero,
            empty: S::EMPTY,
        },
        epoch,
    )
}

#[ic_cdk::update]
fn append(epoch: u64, value: u64) -> Result<(), E> {
    let (mut v, _) = storage::read(epoch)?;
    v.a.record(value);
    v.s.record(value);
    v.h.record(value);
    storage::write(&v, epoch)
}

#[ic_cdk::query]
fn query_append(epoch: u64, value: u64) -> Result<(), E> {
    append(epoch, value)
}

#[ic_cdk::update]
fn trap_after_write(epoch: u64, value: u64) {
    append(epoch, value).expect("fixture append before intentional trap");
    ic_cdk::trap("intentional fixture rollback");
}

#[ic_cdk::update]
fn reject(which: u8, epoch: u64) -> Result<(), E> {
    storage::reject(which, epoch)
}

#[ic_cdk::update]
fn reset(epoch: u64) -> Result<(), E> {
    let next = epoch.checked_add(1).ok_or(E::Input)?;
    storage::reset(epoch)?;
    seed(next)
}

#[ic_cdk::update]
fn measure(iterations: u32, cadence: u32, nonce: u64) -> Result<Measured, E> {
    if iterations > 1024 || cadence == 0 || cadence > 1024 {
        return Err(E::Input);
    }
    let name = format!("cohort-{nonce}");
    let mut a = A::EMPTY;
    let before = ic_cdk::api::instruction_counter();
    for index in 1..=iterations {
        a.record(std::hint::black_box(7));
        if index % cadence == 0 {
            storage::checkpoint(&name, &a)?;
        }
    }
    if iterations % cadence != 0 {
        storage::checkpoint(&name, &a)?;
    }
    let after = ic_cdk::api::instruction_counter();
    Ok(Measured {
        before,
        after,
        samples: a.samples(),
        total: a.total(),
    })
}
