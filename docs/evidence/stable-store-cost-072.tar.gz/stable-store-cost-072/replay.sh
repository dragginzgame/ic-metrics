#!/usr/bin/env bash
# Frozen Linux IC evidence. Explicit prepared caches/server; no installation.
set -euo pipefail
if (($# != 2)); then
    printf 'usage: %s METRICS_TARGET_BUILD_DIRECTORY NEW_RESULT_DIRECTORY\n' "$0" >&2
    exit 2
fi
fixture=$(cd -P -- "$(dirname -- "$0")" && pwd)
build=$1
output=$2
: "${POCKET_IC_BIN:?Supply the owner-prepared PocketIC 16.1.0 executable}"
if [[ -n ${IC_TESTKIT_POCKET_IC_URL+x} ]]; then
    printf 'This experiment requires its exact local server, not a URL.\n' >&2
    exit 2
fi
if [[ $(rustc --version) != 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]; then
    printf 'This experiment selects Rust 1.99.0.\n' >&2
    exit 2
fi
server_digest=$(sha256sum -- "$POCKET_IC_BIN")
if [[ ${server_digest%% *} != b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]]; then
    printf 'The selected executable differs from the frozen server.\n' >&2
    exit 2
fi
(cd -- "$fixture" && sha256sum -c inputs.sha256)
cargo metadata --offline --locked --manifest-path "$fixture/Cargo.toml" --no-deps --format-version 1 >/dev/null
for variant in volatile durable; do
    for revision in initial upgrade; do
        features=''
        [[ $variant != durable ]] || features=durable
        [[ $revision != upgrade ]] || features="${features:+$features,}upgrade"
        cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-probe --target wasm32-unknown-unknown --features "$features" -- -D warnings
        cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-probe --release --target wasm32-unknown-unknown --features "$features"
        name=$variant
        [[ $revision != upgrade ]] || name=$variant-upgrade
        cmp -- "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$fixture/artifacts/$name.wasm"
    done
done
cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-driver -- -D warnings
cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-driver
"$build/debug/stable-driver" "$fixture" "$output"
for payload in costs.csv sizes.csv qualification.tsv states.txt; do
    cmp -- "$fixture/run-2/$payload" "$output/$payload"
done
