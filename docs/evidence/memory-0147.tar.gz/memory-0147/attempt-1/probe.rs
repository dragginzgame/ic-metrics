//! Frozen IC probe; hosts own fresh/load decisions, cadence, epochs and map leases.
use ic_memory::{
    DefaultMemoryImpl, GenericAllocationPolicy, MemoryAllocationPool, MemoryAuthority,
    MemoryRequest, MemoryRuntime, RuntimeOpenError, SealedDeclarationSnapshot,
};
use ic_metrics::{
    MeasurementAggregate as A, MeasurementCounter as C, MeasurementHistogram as H,
    MeasurementSummary as S,
};
use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsStore, StoreError};
use ic_platform::cdk::api;
use ic_storage::adapter::StableBTreeMap;
use protocol::{Error as E, Measured, Observe, Op, Operate, Reply, Request, Response, Snapshot};
use std::cell::RefCell;

const STORE: &str = "app.metrics.v1";
const COUNTERS: [&str; 4] = ["lifetime", "zero", "cap", "overflow"];
const ROWS: [&str; 8] = [
    "lifetime",
    "zero",
    "cap",
    "overflow",
    "aggregate",
    "summary",
    "histogram",
    "empty",
];

#[derive(Clone)]
struct Values {
    epoch: u64,
    counters: [C; 4],
    aggregate: A,
    summary: S,
    histogram: H<2>,
    empty: A,
}
struct Host {
    runtime: MemoryRuntime<DefaultMemoryImpl>,
    store: MetricsStore<DefaultMemoryImpl>,
    volatile: Option<Values>,
    id: u8,
    setup_instructions: u64,
}
thread_local! { static HOST: RefCell<Option<Host>> = const { RefCell::new(None) }; }

fn required<T, F: std::fmt::Display>(value: Result<T, F>) -> T {
    value.unwrap_or_else(|error| api::trap(format!("fixture setup/codec: {error}")))
}
fn error(error: StoreError) -> E {
    match error {
        StoreError::IdentityMismatch => E::Identity,
        StoreError::StateRegression => E::Regression,
        StoreError::BoundsMismatch => E::Bounds,
        StoreError::KindMismatch => E::Kind,
        _ => E::Storage,
    }
}
fn key(name: &str) -> Result<MetricKey, E> {
    let namespace = if COUNTERS.contains(&name) {
        "counter"
    } else if name == "empty" {
        "empty"
    } else {
        "cohort"
    };
    MetricKey::new(namespace, name).map_err(error)
}
fn identity(epoch: u64) -> Result<MetricIdentity, E> {
    MetricIdentity::new("items", epoch).map_err(error)
}
fn open(retained: bool) {
    let before = api::instruction_counter();
    let pool = required(MemoryAllocationPool::new(
        vec![required(MemoryAuthority::new("app", "app."))],
        vec![],
    ));
    let declarations = required(SealedDeclarationSnapshot::new(vec![required(
        MemoryRequest::new("app", STORE),
    )]));
    let mut runtime = required(MemoryRuntime::new(DefaultMemoryImpl::default()));
    required(runtime.bootstrap(&declarations, &pool, &GenericAllocationPolicy));
    let id = required(runtime.memory_id(STORE));
    let memory = required(runtime.open_memory(STORE));
    // No format fallback: installation is known fresh, upgrades are known retained.
    let map = if retained {
        StableBTreeMap::load(memory)
    } else {
        StableBTreeMap::new(memory)
    };
    HOST.with_borrow_mut(|host| {
        *host = Some(Host {
            runtime,
            store: MetricsStore::new(map),
            setup_instructions: api::instruction_counter() - before,
            volatile: None,
            id,
        })
    });
}
#[ic_platform::cdk::init]
fn init() {
    open(false);
}
#[ic_platform::cdk::post_upgrade]
fn post_upgrade() {
    open(true);
}

fn read(host: &Host, epoch: u64) -> Result<Values, E> {
    if !cfg!(feature = "durable") {
        let values = host.volatile.clone().ok_or(E::Missing)?;
        return if values.epoch == epoch {
            Ok(values)
        } else {
            Err(E::Identity)
        };
    }
    let id = identity(epoch)?;
    let mut counters = [C::ZERO; 4];
    for (target, name) in counters.iter_mut().zip(COUNTERS) {
        *target = host
            .store
            .load_counter(&key(name)?, &id)
            .map_err(error)?
            .ok_or(E::Missing)?;
    }
    Ok(Values {
        epoch,
        counters,
        aggregate: host
            .store
            .load_aggregate(&key("aggregate")?, &id)
            .map_err(error)?
            .ok_or(E::Missing)?,
        summary: host
            .store
            .load_summary(&key("summary")?, &id)
            .map_err(error)?
            .ok_or(E::Missing)?,
        histogram: host
            .store
            .load_histogram(&key("histogram")?, &id, &[0, 10])
            .map_err(error)?
            .ok_or(E::Missing)?,
        empty: host
            .store
            .load_aggregate(&key("empty")?, &id)
            .map_err(error)?
            .ok_or(E::Missing)?,
    })
}
fn save(host: &mut Host, values: &Values) -> Result<(), E> {
    if !cfg!(feature = "durable") {
        host.volatile = Some(values.clone());
        return Ok(());
    }
    let id = identity(values.epoch)?;
    for (value, name) in values.counters.iter().zip(COUNTERS) {
        host.store
            .save_counter(&key(name)?, &id, value)
            .map_err(error)?;
    }
    host.store
        .save_aggregate(&key("aggregate")?, &id, &values.aggregate)
        .map_err(error)?;
    host.store
        .save_summary(&key("summary")?, &id, &values.summary)
        .map_err(error)?;
    host.store
        .save_histogram(&key("histogram")?, &id, &values.histogram)
        .map_err(error)?;
    host.store
        .save_aggregate(&key("empty")?, &id, &values.empty)
        .map_err(error)
}
fn seed(host: &mut Host, epoch: u64) -> Result<(), E> {
    let mut values = Values {
        epoch,
        counters: [
            required(C::from_parts(u128::from(u64::MAX) + 5, false)),
            C::ZERO,
            required(C::from_parts(u128::MAX, false)),
            required(C::from_parts(u128::MAX, true)),
        ],
        aggregate: A::EMPTY,
        summary: S::EMPTY,
        histogram: required(H::new([0, 10])),
        empty: A::EMPTY,
    };
    for sample in [0, u64::MAX, u64::MAX] {
        values.aggregate.record(sample);
        values.summary.record(sample);
        values.histogram.record(sample);
    }
    save(host, &values)
}
fn record(host: &mut Host, epoch: u64, amount: u64) -> Result<(), E> {
    let mut values = read(host, epoch)?;
    values.counters[0].add(u128::from(amount));
    values.aggregate.record(amount);
    values.summary.record(amount);
    values.histogram.record(amount);
    save(host, &values)
}
fn snapshot(host: &Host, epoch: u64) -> Result<Snapshot, E> {
    let v = read(host, epoch)?;
    let a = v.aggregate;
    let s = v.summary.aggregate();
    let h = v.histogram.aggregate();
    Ok(Snapshot {
        setup_instructions: host.setup_instructions,
        counters: v.counters.map(C::total),
        counter_overflow: v.counters.map(C::total_overflowed),
        aggregate: [
            u128::from(a.samples()),
            a.total(),
            u128::from(a.maximum().ok_or(E::Input)?),
        ],
        summary: [
            u128::from(s.samples()),
            s.total(),
            u128::from(s.maximum().ok_or(E::Input)?),
            u128::from(v.summary.latest().ok_or(E::Input)?),
        ],
        histogram: [
            u128::from(h.samples()),
            h.total(),
            u128::from(h.maximum().ok_or(E::Input)?),
            u128::from(v.histogram.bucket_counts()[0]),
            u128::from(v.histogram.bucket_counts()[1]),
            u128::from(v.histogram.overflow()),
            u128::from(h.samples_overflowed() || h.total_overflowed()),
        ],
        empty: v.empty == A::EMPTY,
        missing: host
            .store
            .load_counter(
                &MetricKey::new("missing", "row").map_err(error)?,
                &identity(epoch)?,
            )
            .map_err(error)?
            .is_none(),
        memory_id: host.id,
        build: cfg!(feature = "upgrade"),
        exclusive: matches!(
            host.runtime.open_memory(STORE),
            Err(RuntimeOpenError::AlreadyOpen { .. })
        ),
    })
}
fn reopen() -> Result<(), E> {
    HOST.with_borrow_mut(|slot| {
        let Host {
            runtime,
            store,
            volatile,
            id,
            setup_instructions,
        } = slot.take().ok_or(E::Missing)?;
        let map = store.into_map();
        if !matches!(
            runtime.open_memory(STORE),
            Err(RuntimeOpenError::AlreadyOpen { .. })
        ) {
            return Err(E::Lease);
        }
        drop(map);
        let map = StableBTreeMap::load(runtime.open_memory(STORE).map_err(|_| E::Lease)?);
        *slot = Some(Host {
            runtime,
            store: MetricsStore::new(map),
            volatile,
            id,
            setup_instructions,
        });
        Ok(())
    })
}
fn measure(host: &mut Host, request: &Request) -> Result<Measured, E> {
    if request.iterations > 256 || request.cadence == 0 {
        return Err(E::Input);
    }
    let key = MetricKey::new("cost", &format!("counter-{}", request.nonce)).map_err(error)?;
    let id = identity(0)?;
    let mut counter = C::ZERO;
    let before = api::instruction_counter();
    for index in 1..=request.iterations {
        counter.add(7);
        if cfg!(feature = "durable")
            && (index % request.cadence == 0 || index == request.iterations)
        {
            host.store
                .save_counter(&key, &id, &counter)
                .map_err(error)?;
        }
        std::hint::black_box(counter);
    }
    let after = api::call_context_instruction_counter();
    Ok(Measured {
        instructions: after - before,
        total: counter.total(),
        samples: request.iterations,
    })
}
fn dispatch(request: Request) -> Response {
    if matches!(request.op, Op::Reopen) {
        reopen()?;
    }
    HOST.with_borrow_mut(|slot| {
        let host = slot.as_mut().ok_or(E::Missing)?;
        match request.op {
            Op::Seed => seed(host, request.epoch)?,
            Op::Read | Op::Reopen => (),
            Op::Record | Op::TrapRecord => {
                record(host, request.epoch, request.amount)?;
                if matches!(request.op, Op::TrapRecord) {
                    api::trap("intentional checkpoint rollback");
                }
            }
            Op::Reset => {
                if cfg!(feature = "durable") {
                    for name in ROWS {
                        if !host
                            .store
                            .remove(&key(name)?, &identity(request.epoch)?)
                            .map_err(error)?
                        {
                            return Err(E::Missing);
                        }
                    }
                }
                host.volatile = None;
                seed(host, request.amount)?;
                return snapshot(host, request.amount).map(Reply::Snapshot);
            }
            Op::WrongBounds => {
                host.store
                    .load_histogram(&key("histogram")?, &identity(request.epoch)?, &[0, 11])
                    .map_err(error)?;
                return Err(E::Input);
            }
            Op::Regress => {
                host.store
                    .save_counter(&key("lifetime")?, &identity(request.epoch)?, &C::ZERO)
                    .map_err(error)?;
                return Err(E::Input);
            }
            Op::WrongKind => {
                host.store
                    .load_counter(&key("aggregate")?, &identity(request.epoch)?)
                    .map_err(error)?;
                return Err(E::Input);
            }
            Op::Measure => return measure(host, &request).map(Reply::Measured),
        }
        snapshot(host, request.epoch).map(Reply::Snapshot)
    })
}
fn admit_input() -> Result<(), String> {
    if ic_platform::ic0::msg_arg_data_size() > 256 {
        Err("fixture request exceeds allowance".into())
    } else {
        Ok(())
    }
}
fn decode_update(bytes: Vec<u8>) -> Request {
    required(ic_wire::decode_request::<Operate>(&bytes))
}
fn encode_update(response: Response) -> Vec<u8> {
    required(ic_wire::encode_response::<Operate>(&response))
        .as_bytes()
        .to_vec()
}
fn decode_query(bytes: Vec<u8>) -> Request {
    required(ic_wire::decode_request::<Observe>(&bytes))
}
fn encode_query(response: Response) -> Vec<u8> {
    required(ic_wire::encode_response::<Observe>(&response))
        .as_bytes()
        .to_vec()
}
#[ic_platform::cdk::update(
    hidden = true,
    guard = "admit_input",
    decode_with = "decode_update",
    encode_with = "encode_update"
)]
fn operate(request: Request) -> Response {
    dispatch(request)
}
#[ic_platform::cdk::query(
    hidden = true,
    guard = "admit_input",
    decode_with = "decode_query",
    encode_with = "encode_query"
)]
fn observe(request: Request) -> Response {
    dispatch(request)
}
