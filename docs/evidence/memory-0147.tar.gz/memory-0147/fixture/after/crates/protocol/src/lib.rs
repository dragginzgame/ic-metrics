//! Frozen, bounded experiment messages; no production endpoints or schemas.
use ic_wire::{Limits, Method, Wire};

#[derive(Clone, Copy, Debug, Wire)]
pub enum Op {
    #[wire(id = 0)]
    Seed,
    #[wire(id = 1)]
    Read,
    #[wire(id = 2)]
    Record,
    #[wire(id = 3)]
    TrapRecord,
    #[wire(id = 4)]
    Reset,
    #[wire(id = 5)]
    Reopen,
    #[wire(id = 6)]
    WrongBounds,
    #[wire(id = 7)]
    Regress,
    #[wire(id = 8)]
    WrongKind,
    #[wire(id = 9)]
    Measure,
}

#[derive(Clone, Debug, Wire)]
pub struct Request {
    #[wire(id = 1)]
    pub op: Op,
    #[wire(id = 2)]
    pub epoch: u64,
    #[wire(id = 3)]
    pub amount: u64,
    #[wire(id = 4)]
    pub iterations: u64,
    #[wire(id = 5)]
    pub cadence: u64,
    #[wire(id = 6)]
    pub nonce: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Wire)]
pub enum Error {
    #[wire(id = 0)]
    Input,
    #[wire(id = 1)]
    Missing,
    #[wire(id = 2)]
    Identity,
    #[wire(id = 3)]
    Regression,
    #[wire(id = 4)]
    Bounds,
    #[wire(id = 5)]
    Kind,
    #[wire(id = 6)]
    Storage,
    #[wire(id = 7)]
    Lease,
}

#[derive(Clone, Debug, PartialEq, Eq, Wire)]
pub struct Snapshot {
    #[wire(id = 1)]
    pub counters: [u128; 4],
    #[wire(id = 2)]
    pub counter_overflow: [bool; 4],
    #[wire(id = 3)]
    pub aggregate: [u128; 3],
    #[wire(id = 4)]
    pub summary: [u128; 4],
    #[wire(id = 5)]
    pub histogram: [u128; 7],
    #[wire(id = 6)]
    pub empty: bool,
    #[wire(id = 7)]
    pub missing: bool,
    #[wire(id = 8)]
    pub memory_id: u8,
    #[wire(id = 9)]
    pub build: bool,
    #[wire(id = 10)]
    pub exclusive: bool,
    #[wire(id = 11)]
    pub setup_instructions: u64,
}

#[derive(Clone, Debug, Wire)]
pub struct Measured {
    #[wire(id = 1)]
    pub instructions: u64,
    #[wire(id = 2)]
    pub total: u128,
    #[wire(id = 3)]
    pub samples: u64,
}

#[derive(Clone, Debug, Wire)]
#[allow(clippy::large_enum_variant)] // Fixed bounded messages avoid another heap allocation.
pub enum Reply {
    #[wire(id = 1)]
    Snapshot(Snapshot),
    #[wire(id = 2)]
    Measured(Measured),
}
pub type Response = Result<Reply, Error>;
pub struct Operate;
pub struct Observe;
const REQUEST: Limits = Limits {
    bytes: 256,
    allocation: 4096,
    nodes: 64,
    depth: 8,
};
const RESPONSE: Limits = Limits {
    bytes: 4096,
    allocation: 65536,
    nodes: 512,
    depth: 16,
};
impl Method for Operate {
    type Request = Request;
    type Response = Response;
    const ID: u64 = 0x0001_4601;
    const NAME: &'static str = "operate";
    const REQUEST_LIMITS: Limits = REQUEST;
    const RESPONSE_LIMITS: Limits = RESPONSE;
}
impl Method for Observe {
    type Request = Request;
    type Response = Response;
    const ID: u64 = 0x0001_4602;
    const NAME: &'static str = "observe";
    const REQUEST_LIMITS: Limits = REQUEST;
    const RESPONSE_LIMITS: Limits = RESPONSE;
}
