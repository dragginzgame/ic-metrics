//! Frozen, explicit IC qualification. Testkit owns server lifecycle and Wire calls.
use clap::Parser;
use ic_platform::Principal;
use ic_testkit::pic::{
    self, ErrorCode, PocketIc, PocketIcBuilder, PocketIcCallFailure, PocketIcStartupConfig,
    WireCallError,
};
use protocol::{Error, Observe, Op, Operate, Reply, Request, Snapshot};
use std::{
    error::Error as StdError,
    fs,
    io::{self, Write},
    path::PathBuf,
    time::Duration,
};
type Result<T> = std::result::Result<T, Box<dyn StdError>>;
#[derive(Parser)]
struct Args {
    #[arg(long)]
    fixture: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[arg(long)]
    server_directory: PathBuf,
}
fn ensure(condition: bool, message: &str) -> Result<()> {
    if condition {
        Ok(())
    } else {
        Err(io::Error::other(message).into())
    }
}
fn request(op: Op, epoch: u64, amount: u64) -> Request {
    Request {
        op,
        epoch,
        amount,
        iterations: 0,
        cadence: 1,
        nonce: 0,
    }
}
fn call(pic: &PocketIc, id: Principal, req: &Request) -> Result<protocol::Response> {
    Ok(pic::update_wire::<Operate>(
        pic,
        id,
        Principal::anonymous(),
        req,
    )?)
}
fn snap(reply: protocol::Response) -> Result<Snapshot> {
    match reply {
        Ok(Reply::Snapshot(value)) => Ok(value),
        other => Err(io::Error::other(format!("expected snapshot: {other:?}")).into()),
    }
}
fn refused(reply: protocol::Response, expected: Error) -> Result<()> {
    ensure(
        matches!(reply, Err(actual) if actual == expected),
        "incorrect typed refusal",
    )
}
fn expected(id: u8, build: bool, additions: &[u64]) -> Snapshot {
    let max = u128::from(u64::MAX);
    let extra: u128 = additions.iter().map(|v| u128::from(*v)).sum();
    let n = 3 + additions.len() as u128;
    let total = 2 * max + extra;
    let zeros = 1 + additions.iter().filter(|v| **v == 0).count() as u128;
    let small = additions.iter().filter(|v| **v > 0 && **v <= 10).count() as u128;
    let large = 2 + additions.iter().filter(|v| **v > 10).count() as u128;
    Snapshot {
        setup_instructions: 0,
        counters: [max + 5 + extra, 0, u128::MAX, u128::MAX],
        counter_overflow: [false, false, false, true],
        aggregate: [n, total, max],
        summary: [
            n,
            total,
            max,
            u128::from(*additions.last().unwrap_or(&u64::MAX)),
        ],
        histogram: [n, total, max, zeros, small, large, 0],
        empty: true,
        missing: true,
        memory_id: id,
        build,
        exclusive: true,
    }
}
fn check_snapshot(
    actual: Snapshot,
    mut wanted: Snapshot,
    label: &str,
    states: &mut fs::File,
) -> Result<()> {
    writeln!(states, "{label}\t{actual:?}")?;
    ensure(
        actual.setup_instructions > 0,
        "setup instructions not observed",
    )?;
    wanted.setup_instructions = actual.setup_instructions;
    ensure(
        actual == wanted,
        &format!("snapshot mismatch at {label}: expected {wanted:?}"),
    )
}
fn create(pic: &PocketIc, wasm: &[u8]) -> Principal {
    let id = pic.create_canister();
    pic.add_cycles(id, 100_000_000_000_000);
    pic.install_canister(id, wasm.to_vec(), vec![], None);
    id
}
fn qualify(
    pic: &PocketIc,
    initial: &[u8],
    upgraded: &[u8],
    durable: bool,
    checks: &mut fs::File,
    states: &mut fs::File,
) -> Result<()> {
    let mode = if durable { "durable" } else { "volatile" };
    let id = create(pic, initial);
    refused(call(pic, id, &request(Op::Read, 0, 0))?, Error::Missing)?;
    let first = snap(call(pic, id, &request(Op::Seed, 0, 0))?)?;
    let memory_id = first.memory_id;
    check_snapshot(
        first,
        expected(memory_id, false, &[]),
        &format!("{mode}-seed"),
        states,
    )?;
    let query =
        pic::query_wire::<Observe>(pic, id, Principal::anonymous(), &request(Op::Record, 0, 7))?;
    check_snapshot(
        snap(query)?,
        expected(memory_id, false, &[7]),
        &format!("{mode}-query-transient"),
        states,
    )?;
    check_snapshot(
        snap(call(pic, id, &request(Op::Read, 0, 0))?)?,
        expected(memory_id, false, &[]),
        &format!("{mode}-query-discard"),
        states,
    )?;
    let trap = pic::update_wire::<Operate>(
        pic,
        id,
        Principal::anonymous(),
        &request(Op::TrapRecord, 0, 7),
    );
    let trapped = match trap {
        Err(WireCallError::Call { source, .. }) => {
            matches!(*source, PocketIcCallFailure::Rejected(ref r) if r.error_code == ErrorCode::CanisterCalledTrap)
        }
        _ => false,
    };
    ensure(trapped, "expected structured intentional canister trap")?;
    check_snapshot(
        snap(call(pic, id, &request(Op::Read, 0, 0))?)?,
        expected(memory_id, false, &[]),
        &format!("{mode}-trap-rollback"),
        states,
    )?;
    refused(call(pic, id, &request(Op::Read, 1, 0))?, Error::Identity)?;
    if durable {
        for (op, error) in [
            (Op::WrongBounds, Error::Bounds),
            (Op::WrongKind, Error::Kind),
            (Op::Regress, Error::Regression),
        ] {
            refused(call(pic, id, &request(op, 0, 0))?, error)?;
        }
    }
    check_snapshot(
        snap(call(pic, id, &request(Op::Reopen, 0, 0))?)?,
        expected(memory_id, false, &[]),
        &format!("{mode}-lease-transfer"),
        states,
    )?;
    check_snapshot(
        snap(call(pic, id, &request(Op::Record, 0, 7))?)?,
        expected(memory_id, false, &[7]),
        &format!("{mode}-record"),
        states,
    )?;
    pic.upgrade_canister(id, upgraded.to_vec(), vec![], None)
        .map_err(PocketIcCallFailure::Rejected)?;
    if durable {
        check_snapshot(
            snap(call(pic, id, &request(Op::Read, 0, 0))?)?,
            expected(memory_id, true, &[7]),
            "durable-first-upgrade",
            states,
        )?;
        check_snapshot(
            snap(call(pic, id, &request(Op::Record, 0, 0))?)?,
            expected(memory_id, true, &[7, 0]),
            "durable-zero-continuation",
            states,
        )?;
        pic.upgrade_canister(id, initial.to_vec(), vec![], None)
            .map_err(PocketIcCallFailure::Rejected)?;
        check_snapshot(
            snap(call(pic, id, &request(Op::Read, 0, 0))?)?,
            expected(memory_id, false, &[7, 0]),
            "durable-second-upgrade",
            states,
        )?;
        check_snapshot(
            snap(call(pic, id, &request(Op::Reset, 0, 1))?)?,
            expected(memory_id, false, &[]),
            "durable-reset-new-epoch",
            states,
        )?;
        refused(call(pic, id, &request(Op::Read, 0, 0))?, Error::Identity)?;
        check_snapshot(
            snap(call(pic, id, &request(Op::Read, 1, 0))?)?,
            expected(memory_id, false, &[]),
            "durable-reset-retained",
            states,
        )?;
    } else {
        refused(call(pic, id, &request(Op::Read, 0, 0))?, Error::Missing)?;
    }
    writeln!(
        checks,
        "{mode}\tabsence,wide/cap/overflow/zero,empty,query-discard,trap-rollback,identity,lease-transfer,upgrade\tPASS"
    )?;
    if durable {
        writeln!(
            checks,
            "durable\tbounds,kind,regression,two-upgrades,zero-continuation,explicit-reset\tPASS"
        )?;
    }
    Ok(())
}
fn costs(pic: &PocketIc, wasm: &[u8], durable: bool, out: &mut fs::File) -> Result<()> {
    let id = create(pic, wasm);
    let mut nonce = 0;
    for repeat in 0..3 {
        for iterations in [0, 1, 16, 256] {
            for cadence in [1, 16, 256] {
                nonce += 1;
                let req = Request {
                    op: Op::Measure,
                    epoch: 0,
                    amount: 0,
                    iterations,
                    cadence,
                    nonce,
                };
                let before = pic.cycle_balance(id);
                let result = call(pic, id, &req)?;
                let after = pic.cycle_balance(id);
                let Ok(Reply::Measured(value)) = result else {
                    return Err(io::Error::other("cost response kind").into());
                };
                ensure(
                    value.samples == iterations && value.total == u128::from(iterations) * 7,
                    "cost arithmetic",
                )?;
                let cycles = before
                    .checked_sub(after)
                    .ok_or_else(|| io::Error::other("cycle balance increased"))?;
                ensure(cycles > 0, "no IC cycles charged")?;
                writeln!(
                    out,
                    "{},{repeat},{iterations},{cadence},{nonce},{},{cycles}",
                    if durable { "durable" } else { "volatile" },
                    value.instructions
                )?;
            }
        }
    }
    let mut invalid = request(Op::Measure, 0, 0);
    invalid.iterations = 257;
    refused(call(pic, id, &invalid)?, Error::Input)?;
    invalid.iterations = 1;
    invalid.cadence = 0;
    refused(call(pic, id, &invalid)?, Error::Input)
}
fn main() -> Result<()> {
    let args = Args::parse();
    fs::create_dir(&args.output)?;
    let server_binary = pic::server_assets::check(&args.server_directory)?;
    let owned = PocketIcStartupConfig::Spawn {
        server_binary,
        timeout: Duration::from_secs(30),
        server_hard_ttl: Some(Duration::from_secs(300)),
        server_idle_ttl: Some(Duration::from_secs(60)),
        server_output_files: Some((
            args.output.join("server.stdout"),
            args.output.join("server.stderr"),
        )),
    }
    .build_instance(PocketIcBuilder::new().with_application_subnet())?;
    for graph in ["before", "after"] {
        let output = args.output.join(graph);
        fs::create_dir(&output)?;
        let mut checks = fs::File::create(output.join("qualification.tsv"))?;
        let mut states = fs::File::create(output.join("states.txt"))?;
        let mut sizes = fs::File::create(output.join("sizes.csv"))?;
        let mut cost = fs::File::create(output.join("costs.csv"))?;
        writeln!(sizes, "artifact,raw_bytes")?;
        writeln!(
            cost,
            "mode,repeat,iterations,cadence,nonce,instructions,cycles"
        )?;
        for mode in ["durable", "volatile"] {
            let initial = fs::read(args.fixture.join(format!("{graph}/artifacts/{mode}.wasm")))?;
            let upgraded = fs::read(
                args.fixture
                    .join(format!("{graph}/artifacts/{mode}-upgrade.wasm")),
            )?;
            writeln!(sizes, "{mode}.wasm,{}", initial.len())?;
            writeln!(sizes, "{mode}-upgrade.wasm,{}", upgraded.len())?;
            qualify(
                &owned.instance,
                &initial,
                &upgraded,
                mode == "durable",
                &mut checks,
                &mut states,
            )?;
            costs(&owned.instance, &initial, mode == "durable", &mut cost)?;
        }
    }
    let initial = fs::read(args.fixture.join("before/artifacts/durable.wasm"))?;
    let upgraded = fs::read(args.fixture.join("after/artifacts/durable-upgrade.wasm"))?;
    let mut checks = fs::File::create(args.output.join("cross-graph-qualification.tsv"))?;
    let mut states = fs::File::create(args.output.join("cross-graph-states.txt"))?;
    qualify(
        &owned.instance,
        &initial,
        &upgraded,
        true,
        &mut checks,
        &mut states,
    )?;
    println!(
        "IC same-graph and old-to-new upgrade, lease, bootstrap and checkpoint qualification passed"
    );
    Ok(())
}
