#!/usr/bin/env bash
# Frozen comparison only; provision locked sources and admitted server separately.
set -euo pipefail
[[ $# == 3 ]] || { printf 'usage: replay.sh TARGET_ROOT NEW_RESULT_DIR PREPARED_SERVER_DIR\n' >&2; exit 2; }
fixture="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
output_targets="$1"
result="$2"
server="$3"
[[ "$output_targets" == /* && "$result" == /* && "$server" == /* && ! -e "$result" ]] || exit 2
for graph in before after; do
    cd "$fixture/$graph"
    export CARGO_TARGET_DIR="$output_targets/$graph"
    for flags in '' durable upgrade durable,upgrade; do
        args=()
        [[ -z "$flags" ]] || args=(--features "$flags")
        cargo clippy -p probe --lib --target wasm32-unknown-unknown --locked --offline "${args[@]}" -- -D warnings
        cargo build -p probe --target wasm32-unknown-unknown --release --locked --offline "${args[@]}"
        case "$flags" in
            '') name=volatile ;; durable) name=durable ;; upgrade) name=volatile-upgrade ;; *) name=durable-upgrade ;;
        esac
        cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/probe.wasm" "artifacts/$name.wasm"
    done
done
cd "$fixture/host"
export CARGO_TARGET_DIR="$output_targets/host"
cargo clippy -p driver -p protocol --all-targets --locked --offline -- -D warnings
cargo build -p driver --locked --offline
"$CARGO_TARGET_DIR/debug/driver" --fixture "$fixture" --output "$result" --server-directory "$server"
