//! Independent projection oracle and real IC execution for frozen kernels.
use arithmetic_cost_probe::{ProbeError, ProbeReply};
use candid::{Principal, decode_one, encode_args};
use ic_testkit::pic::{PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use std::{error::Error, fmt, fs, io::Write, path::PathBuf, time::Duration};

const VARIANTS: [&str; 8] = [
    "baseline-record",
    "candidate-record",
    "baseline-cumulative",
    "candidate-cumulative",
    "baseline-quantile",
    "candidate-quantile",
    "baseline-cohort",
    "candidate-cohort",
];
#[derive(Debug)]
enum ReplayError {
    Arguments,
    CounterRegression,
    CycleIncrease,
    ProbeRejected,
    Rejected(ic_testkit::pic::RejectResponse),
    Projection {
        expected: [u64; 11],
        actual: [u64; 11],
    },
}
impl fmt::Display for ReplayError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Rejected(r) => write!(f, "IC call rejected: {r:?}"),
            Self::Projection { expected, actual } => {
                write!(f, "expected {expected:?}, got {actual:?}")
            }
            _ => write!(f, "replay failed: {self:?}"),
        }
    }
}
impl Error for ReplayError {}
fn expected(variant: &str, iterations: u32, numerator: u64, denominator: u64) -> [u64; 11] {
    let mut s = [0; 11];
    if variant.ends_with("record") {
        let count = u64::from(iterations);
        let total = u128::from(count) * u128::from(numerator);
        s[0] = count;
        s[1] = total.min(u128::from(u64::MAX)) as u64;
        if count != 0 {
            s[2] = numerator;
        }
        if total > u128::from(u64::MAX) {
            s[4] = 2;
        }
        let index = match numerator {
            0 => 5,
            1..=10_000 => 6,
            10_001..=100_000 => 7,
            100_001..=1_000_000 => 8,
            _ => 9,
        };
        s[index] = count;
    } else {
        s[0] = 5;
        s[1] = 2_110_001;
        s[2] = 1_000_001;
        s[5..10].copy_from_slice(&[1, 1, 1, 1, 1]);
        let per_iteration = if variant.ends_with("cumulative") {
            3
        } else if variant.ends_with("cohort") {
            1_110_006
        } else {
            // Independent quotient/remainder rank oracle, then explicit bucket table.
            let product = 5 * u128::from(numerator);
            let divisor = u128::from(denominator);
            let rank = product / divisor + u128::from(product % divisor != 0);
            match rank {
                1 => 1,
                2 => 10_002,
                3 => 110_002,
                4 => 1_100_002,
                _ => 1_000_001,
            }
        };
        s[10] = per_iteration * u64::from(iterations);
    }
    s
}
fn main() -> Result<(), Box<dyn Error>> {
    let mut args = std::env::args_os().skip(1);
    let (Some(directory), Some(output), None) = (args.next(), args.next(), args.next()) else {
        return Err(ReplayError::Arguments.into());
    };
    let directory = PathBuf::from(directory);
    let output = PathBuf::from(output);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new()
        .with_application_subnet()
        .try_build(config)?;
    let mut csv = fs::File::create(output.join("results.csv"))?;
    writeln!(
        csv,
        "variant,phase,numerator,denominator,iterations,repeat,before,after,instructions,cycles_before,cycles_after,cycles,samples,total,maximum,latest,flags,bucket0,bucket1,bucket2,bucket3,overflow,sink"
    )?;
    let mut sizes = fs::File::create(output.join("sizes.csv"))?;
    writeln!(sizes, "variant,raw_wasm_bytes")?;
    let mut validated = 0;
    for variant in VARIANTS {
        let wasm = fs::read(directory.join("artifacts").join(format!("{variant}.wasm")))?;
        writeln!(sizes, "{variant},{}", wasm.len())?;
        let canister = pic.create_canister();
        // Fund before install; installation costs are outside all balance readings.
        pic.add_cycles(canister, 100_000_000_000_000);
        pic.install_canister(canister, wasm, encode_args(())?, None);
        let fractions = if variant.ends_with("record") {
            vec![
                (0, 1),
                (10_000, 1),
                (10_001, 1),
                (100_000, 1),
                (1_000_000, 1),
                (1_000_001, 1),
                (u64::MAX, 1),
            ]
        } else if variant.ends_with("quantile") {
            vec![
                (1, 2),
                (95, 100),
                (1, u64::MAX),
                (u64::MAX / 5, u64::MAX),
                (u64::MAX / 5 + 1, u64::MAX),
                (u64::MAX - 1, u64::MAX),
                (u64::MAX, u64::MAX),
            ]
        } else {
            vec![(1, 2)]
        };
        let mut cases = vec![("cold", 1, 2, 1, 0)];
        for (n, d) in fractions {
            for iterations in [0, 1, 1_000] {
                for repeat in 0..3 {
                    cases.push(("warm", n, d, iterations, repeat));
                }
            }
        }
        for (phase, numerator, denominator, iterations, repeat) in cases {
            let cycles_before = pic.cycle_balance(canister);
            let response = pic
                .update_call(
                    canister,
                    Principal::anonymous(),
                    "probe",
                    encode_args((iterations, numerator, denominator))?,
                )
                .map_err(ReplayError::Rejected)?;
            let cycles_after = pic.cycle_balance(canister);
            let reply =
                decode_one::<ProbeReply>(&response)?.map_err(|_| ReplayError::ProbeRejected)?;
            let expectation = expected(variant, iterations, numerator, denominator);
            if reply.state != expectation {
                return Err(ReplayError::Projection {
                    expected: expectation,
                    actual: reply.state,
                }
                .into());
            }
            let instructions = reply
                .after
                .checked_sub(reply.before)
                .ok_or(ReplayError::CounterRegression)?;
            let cycles = cycles_before
                .checked_sub(cycles_after)
                .ok_or(ReplayError::CycleIncrease)?;
            write!(
                csv,
                "{variant},{phase},{numerator},{denominator},{iterations},{repeat},{},{},{instructions},{cycles_before},{cycles_after},{cycles}",
                reply.before, reply.after
            )?;
            for part in reply.state {
                write!(csv, ",{part}")?;
            }
            writeln!(csv)?;
            validated += 1;
        }
        let response = pic
            .update_call(
                canister,
                Principal::anonymous(),
                "probe",
                encode_args((100_001_u32, 1_u64, 2_u64))?,
            )
            .map_err(ReplayError::Rejected)?;
        if !matches!(
            decode_one::<ProbeReply>(&response)?,
            Err(ProbeError::TooManyIterations)
        ) {
            return Err(ReplayError::ProbeRejected.into());
        }
        writeln!(
            csv,
            "{variant},admission-rejected,1,2,100001,0,,,,,,,,,,,,,,,,,"
        )?;
    }
    println!("Validated {validated} measured replies and 8 typed admission rejections.");
    Ok(())
}
