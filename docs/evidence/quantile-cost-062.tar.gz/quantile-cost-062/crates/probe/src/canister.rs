//! Selected source and query kernel; no product canister API.
use crate::{ProbeError, ProbeReading, ProbeReply};
use metrics::MeasurementHistogram;
#[cfg(feature = "baseline")]
use metrics_baseline as metrics;
#[cfg(feature = "candidate")]
use metrics_current as metrics;
use std::hint::black_box;
const _: () =
    assert!(cfg!(feature = "baseline") as usize + cfg!(feature = "candidate") as usize == 1);
const _: () = assert!(
    cfg!(feature = "record") as usize
        + cfg!(feature = "quantile") as usize
        + cfg!(feature = "cumulative") as usize
        + cfg!(feature = "cohort") as usize
        == 1
);

fn range(h: &MeasurementHistogram<4>, n: u64, d: u64) -> Result<u64, ProbeError> {
    let r = h
        .quantile_bucket(black_box(n), black_box(d))
        .map_err(|_| ProbeError::Arithmetic)?
        .ok_or(ProbeError::Arithmetic)?;
    Ok(r.lower_exclusive()
        .unwrap_or(0)
        .wrapping_add(r.upper_inclusive().unwrap_or(0))
        .wrapping_add(u64::from(r.lower_exclusive().is_some()))
        .wrapping_add(u64::from(r.upper_inclusive().is_some())))
}
#[ic_cdk::update]
fn probe(iterations: u32, numerator: u64, denominator: u64) -> ProbeReply {
    if iterations > 100_000 {
        return Err(ProbeError::TooManyIterations);
    }
    let mut h = MeasurementHistogram::new([0, 10_000, 100_000, 1_000_000])
        .map_err(|_| ProbeError::Arithmetic)?;
    if !cfg!(feature = "record") {
        for v in [0, 10_000, 100_000, 1_000_000, 1_000_001] {
            h.record(v);
        }
    }
    let mut sink = 0_u64;
    let before = ic_cdk::api::call_context_instruction_counter();
    for _ in 0..iterations {
        if cfg!(feature = "record") {
            h.record(black_box(numerator));
        }
        if cfg!(feature = "quantile") {
            sink = sink.wrapping_add(range(black_box(&h), numerator, denominator)?);
        }
        if cfg!(feature = "cumulative") {
            sink = sink.wrapping_add(
                black_box(&h)
                    .cumulative_count(black_box(2))
                    .map_err(|_| ProbeError::Arithmetic)?,
            );
        }
        if cfg!(feature = "cohort") {
            sink = sink
                .wrapping_add(
                    black_box(&h)
                        .cumulative_count(black_box(2))
                        .map_err(|_| ProbeError::Arithmetic)?,
                )
                .wrapping_add(range(black_box(&h), 1, 2)?)
                .wrapping_add(range(black_box(&h), 95, 100)?);
        }
    }
    let after = ic_cdk::api::call_context_instruction_counter();
    let a = h.aggregate();
    let mut state = [0; 11];
    state[0] = a.samples();
    state[1] = a.total();
    state[2] = a.maximum().unwrap_or(0);
    state[4] = u64::from(a.samples_saturated()) | (u64::from(a.total_saturated()) << 1);
    state[5..9].copy_from_slice(h.bucket_counts());
    state[9] = h.overflow();
    state[10] = sink;
    for (index, flag) in h.bucket_saturation().iter().enumerate() {
        state[4] |= u64::from(*flag) << (index + 2);
    }
    state[4] |= u64::from(h.overflow_saturated()) << 6;
    Ok(ProbeReading {
        before,
        after,
        state,
    })
}
