#!/usr/bin/env bash
# Frozen Linux experiment: explicit pre-admitted server, no setup/download effects.
set -euo pipefail
if (($# != 2)); then
  printf 'usage: %s REPOSITORY_TARGET_DIRECTORY NEW_RESULT_DIRECTORY\n' "$0" >&2
  exit 2
fi
fixture=$(cd -- "$(dirname -- "$0")" && pwd -P)
build=$1
output=$2
: "${POCKET_IC_BIN:?Select the owner-admitted PocketIC 16.1.0 binary explicitly}"
if [[ -n ${IC_TESTKIT_POCKET_IC_URL+x} ]]; then
  printf 'This frozen experiment requires its exact local binary, not a URL.\n' >&2
  exit 2
fi
if [[ $(rustc --version) != 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]; then
  printf 'The frozen compiler selection is Rust 1.99.0.\n' >&2
  exit 2
fi
server_digest=$(sha256sum -- "$POCKET_IC_BIN")
if [[ ${server_digest%% *} != b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]]; then
  printf 'The selected server does not match the frozen executable.\n' >&2
  exit 2
fi
(cd -- "$fixture" && sha256sum -c inputs.sha256)
cargo metadata --offline --locked --no-deps --format-version 1 --manifest-path "$fixture/Cargo.toml" >/dev/null
for variant in baseline-record candidate-record baseline-cumulative candidate-cumulative baseline-quantile candidate-quantile baseline-cohort candidate-cohort; do
  cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --target wasm32-unknown-unknown --features "${variant/-/,}" -- -D warnings
  cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-probe --release --target wasm32-unknown-unknown --features "${variant/-/,}"
  cmp -- "$build/wasm32-unknown-unknown/release/arithmetic_cost_probe.wasm" "$fixture/artifacts/$variant.wasm"
done
cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver -- -D warnings
cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p arithmetic-cost-driver
"$build/debug/arithmetic-cost-driver" "$fixture" "$output"
cmp -- "$fixture/run-1/results.csv" "$output/results.csv"
cmp -- "$fixture/run-1/sizes.csv" "$output/sizes.csv"
