# Frozen quantile fast-path comparison, pending Metrics 0.6.2

This is an independent frozen evidence artifact, not a maintained package or
server framework. Its virtual root/catalog/lock own its copied source and private
probe/driver. Root Metrics package versions remain 0.6.1. All 293 external
identities exactly reuse the previous frozen arithmetic-cost-061 graph; the
captured Backup seed is a selection receipt, not consumer qualification. No
external or sibling path packages are used. Each private manifest inherits its
own root selections; private copied packages are renamed only in their manifests.

Baseline src/ matches released 0.6.1 at
39b357eb4e53051b5ad9afcfcd0a8c147c68a524. Candidate src/ matches the Metrics
working source at that HEAD plus inputs/source.patch, adding checked-u64
multiplication/division to quantile_rank and retaining exact u128 arithmetic
when the product overflows. The copied complete trees include the packaged
application guide and tests. The graph/source hashes and original resolution
paths are retained in inputs/. Experimental package metadata is not a release
or support-floor selection. Rust 1.99.0 is the frozen measurement compiler;
maintained Metrics has separate actual Rust 1.85 checks.

One of four kernels (record, cumulative, single quantile, reporting cohort) is
compiled for each source. Each update starts with fresh local histogram state
and the four inclusive bounds [0, 10,000, 100,000, 1,000,000]. Query seeds are
[0, 10,000, 100,000, 1,000,000, 1,000,001]; setup and projection/encoding stay
outside the IC instruction bracket. The bracket includes the loop, black-boxed
references/fractions, typed result handling and checksum. Quantile outputs encode
lower/upper values and their presence bits in the checksum. The host's independent
wide quotient/remainder oracle and explicit bucket table validate the results.
The common reply also projects all aggregate/bucket/overflow state and flags.

Query fractions cover p50, p95, 1/MAX, MAX/5/MAX, (MAX/5+1)/MAX, (MAX-1)/MAX and
MAX/MAX. With five samples, MAX/5 is the exact u64 product cap; the next numerator
requires the wide fallback. These are observations of actual API execution,
without forging internal counters. Recording inputs cover every finite bucket,
overflow, exact maximum total and actual total overflow. Each case has 0, 1 and
1,000 iterations with three warm repeats and a separate cold call. Each source's
cohort queries cumulative_count(2), p50 and p95 in the same order.

The host admits at most 100,000 iterations; each Wasm rejects 100,001 with the
typed error. Only valid query fractions are timed; maintained histogram tests
cover invalid fractions, empty/zero, saturation and read-only behavior. Cycle
balance decreases cover whole updates including setup, Candid and fees. Counter
deltas cover the selected loop. They are separately observed metrics, never
converted into each other. No native timings or estimated/mainnet cycles appear.

run-1/results.csv contains 296 measured replies and eight typed rejections.
The fresh-extraction run retains its own raw server streams and CSVs. All eight Wasms rebuilt byte-for-byte; both raw result/size CSVs agree exactly.
Recording/cumulative Wasms also agree byte-for-byte across sources. The complete
source/projection/instruction/cycle checks are retained in inputs/measurement-verification.txt. Cold and zero-loop controls
are retained separately. Costs apply to these eight canister artifacts, N=4,
profile and synthetic five-sample query workload; not consumers, other bounds,
cardinalities, persistence, endpoints, lifecycle, attribution or native macOS.
A result is a bucket range, not an exact observation percentile.

IC Testkit 0.33.3 owns fallible bounded startup and raw stdout/stderr retention;
PocketIC client/server 16.1.0, CDK 0.20.3 and Candid 0.10.37 are locked. The previous
explicit owner server check and server/CLI/archive hashes are retained unchanged.
Fresh startup admits the selected server each run, without automatic download.
The executable hash is b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db.
The CLI hash binds the checked executable, not current dirty sibling source.
Each application-subnet canister receives an additional 100 trillion cycles
before install; the actual measured balances are retained. No sibling was built
or modified. The original 0.6.1 evidence archive is unchanged.

Verify inputs.sha256 after extraction. replay.sh requires the exact admitted
server and compiler, prepared caches for this lock, a repository target/ build
path and a new result directory. It runs locked offline warning-denied Clippy,
rebuilds and compares all eight Wasms, then reproduces and compares raw CSVs.
It never installs a tool, downloads a server or updates dependencies. Explicit
URL configuration, wrong hashes, missing cache, mismatched projections, changed
Wasm or changed raw results fail without fallback.

```sh
# From the extracted quantile-cost-062 directory:
sha256sum -c inputs.sha256
export POCKET_IC_BIN=/absolute/path/to/owner-admitted/pocket-ic
unset IC_TESTKIT_POCKET_IC_URL
bash replay.sh /absolute/metrics/target/evidence/quantile-rebuild-062 \
  /absolute/metrics/target/evidence/quantile-results-062
```

Profile: opt-level=z, LTO, one codegen unit, stripped symbols, panic abort, no
Wasm postprocessing. All eight kernels and the final driver pass warnings-as-errors
Clippy and locked builds. The initial maintained-test Clippy failure (two lossless
casts) and preliminary checks are retained separately; corrected final-source
checks do not relabel the initial result. Full maintained delivery qualification
is recorded separately from these experimental measurements.
