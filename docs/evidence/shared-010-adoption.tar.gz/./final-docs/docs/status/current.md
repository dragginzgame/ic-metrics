# Current handoff

IC Metrics owns allocation-free, dependency-free `no_std` arithmetic. Consumers
own sampling, attribution, units, identities, registries, lifecycle and endpoints.
[The extraction contract](../extraction.md) owns integration boundaries;
[host qualification](../hosts.md) owns setup, focused checks and delivery gates.

## Pending 0.9.1

Shared Tooling 0.10.0 `ed9c26f015691859f67b50b512a94709dcdc0c6c` is adopted
through its reviewed exporter from a clean committed source. The snapshot retains
104 payloads and 91 roots. Its default host/Rust and IC catalogs are required
companions; all 26 tool variables and 15 IC rows match the prior selections.
No exception catalog or tool-version change is needed. Make now takes the shared
defaults directly; a host override does not select Rust pins. Release preflight
binds the selected Rust catalog and rejects changes during preparation.

Actual common setup, offline checks, formatting, hook, ShellCheck and workflow
lint pass. Full CI passes in 293 seconds; arithmetic Rust 1.85 and stable/inspector
Rust 1.88 floors pass. Eight checkpoints match 150 frozen inputs on the selected
0.9.0 package graph: Host 0.17.1, Memory 0.36.2 and collections 0.7.2.
[The adoption receipt](../evidence/shared-010-adoption.md) binds these sources,
checks and limits. Final standalone prose and the corrected 0.9.1 notes receive
separate link/diff/consistency and release-admission checks; compiled inputs stay
unchanged. Existing tools, logs, archives and release state remain retained.

The source capture follows local finalized release 0.9.0
`fe4d14f2a24138794878a17a354885a1e7222487`. Its package metadata, incoming lock,
Rust implementation, index and refs remain unchanged by this adoption.
This contributor-tooling batch is compatible with the published library; notes
select 0.9.1 without changing Cargo versions. Actual native macOS qualification
remains with [#70](https://github.com/dragginzgame/ic-metrics/issues/70).
Linux execution and cross-compilation do not establish hosted macOS acceptance.
No release, commit or publication is performed by this batch.

## Delivered 0.9.0

Local finalized release source is `fe4d14f2a24138794878a17a354885a1e7222487`.
The current arithmetic API removes unreachable mean/interval cases under the
exact-count invariant ([#69](https://github.com/dragginzgame/ic-metrics/issues/69))
and names actual overflow explicitly. Flags use `*_overflowed`; histogram flags
are `bucket_overflowed()` and `overflow_count_overflowed()`, while `overflow()`
remains the count above the last bound. Remaining overflow errors use
`SampleCountOverflow`, `TotalOverflow`, `CountOverflow` and `InvalidOverflowFlag`.
Consumer-owned DTO/wire names and policies remain at their owner.

Stable kind/codec/continuity dispatch requires a privately constructible
zero-sized capability ([#71](https://github.com/dragginzgame/ic-metrics/issues/71)).
Generic `DurableMetric` store operations remain supported. Clipping, exact caps,
empty/zero observations, V1 bytes and host lifecycle stay unchanged; no data reset
or compatibility alias is introduced. The six read-only consumer reviews remain
bound to their original inputs and [owning issues](../extraction.md#downstream-contract-checks).

[The API-boundary receipt](../evidence/api-cut-090.md) retains its original
Host 0.17.0/Memory 0.36.1 graph, 254-second CI, byte-identical nine Wasm probes
and seven V1 records. [The earlier error-cut receipt](../evidence/error-cut-090.md)
retains its original Host 0.16 graph and measured mean/scaled/interval reductions.
Those records do not qualify later dependency graphs, IC costs or applications.
[Archive distribution review](https://github.com/dragginzgame/ic-metrics/issues/72)
stays separate from this tooling adoption; frozen originals remain unchanged.

## Delivered 0.8.4

Local finalized release source is `0baae3a49b0bb2c42b32dfe8005b33d07e7e11d7`.
The release contains private mean ownership cleanup and Memory 0.36.1 selection.
[Its frozen preparation](../evidence/cleanup-084.tar.gz) retains the 377-second
CI/floor qualification and byte-identical mean probes on its original inputs.
Earlier [decoder](../evidence/decoder-083.md) and
[Memory adoption](../evidence/memory-083.md) receipts retain their earlier graphs.
None qualifies pending 0.9 or establishes later hosted release acceptance.

Hosts coordinate their Memory 0.36 adoption through
[Canic #527](https://github.com/dragginzgame/canic/issues/527),
[IcyDB #355](https://github.com/dragginzgame/icydb/issues/355) and
[Blob Storage #64](https://github.com/dragginzgame/ic-blob-storage/issues/64).
Local adapter qualification does not establish those applications' acceptance.

Earlier [0.8.2 publication verification](../evidence/release-082.md) retains its
exact archives, source and initial CI observations. Publication does not complete
native acceptance.
[Released 0.8.1 acceptance](../evidence/release-081.md)
retains its own complete Linux, Intel, Apple Silicon and Rust-floor receipts.

`MeasurementCounter` is available for scalar wide totals, merging, restoration
and exact totals/deltas. It keeps no observation statistics or stored kind.
The stable adapter still admits aggregate, summary and histogram only; no kind
is repurposed or data reset. [The counter record](../evidence/counter-082.md)
and [cleanup record](../evidence/cleanup-082.md) retain their pre-release sources,
including the 261-second final CI/floor proof and separate raw Wasm comparison.
Historical measurements do not establish later application costs.

The current lock selects Host 0.17.1, Memory 0.36.2 and Syn 3.0.9. Arithmetic
stays on Rust 1.85; stable and private inspector stay on 1.88. Current qualification
is recorded above. [The earlier tooling receipt](../evidence/adoption-082-shared-0910.md)
retains its original revision and graph; later snapshots do not relabel its proof.
Metrics retains direct-only release delivery and all earlier evidence/tool generations.

## Consumer and API follow-up

The [six-consumer review](../evidence/consumer-review-082.md) binds its read-only
caller observations. Current adoption/reporting work stays with the
[owning issues](../extraction.md#downstream-contract-checks), including Toko's
[database quality bridge](https://github.com/dragginzgame/toko-miner/issues/49).
[Metrics #10](https://github.com/dragginzgame/ic-metrics/issues/10) retains Canic's
original held-HTTP/native qualification. [Canic #450](https://github.com/dragginzgame/canic/issues/450#issuecomment-6126296388)
and [#491](https://github.com/dragginzgame/canic/issues/491#issuecomment-6126296804)
retain the scoped repair and Auth blocker; no new passing runtime/macOS proof
is claimed. Logs remain in Canic's `.tmp/metrics-qualification-20261012/`.
[#69](https://github.com/dragginzgame/ic-metrics/issues/69) and
[#71](https://github.com/dragginzgame/ic-metrics/issues/71) own the selected
error and stable-boundary cuts. This batch edits Metrics only and performs no release effects.
