# Host support and qualification

| Native host | Required support | Configured runner |
| --- | --- | --- |
| Linux x86_64 | Library build and development tooling | `ubuntu-24.04` |
| macOS Intel | Library build and development tooling | `macos-15-intel` |
| macOS Apple Silicon | Library build and development tooling | `macos-15` |

All three hosts run the complete native suite. Bash 3.2 checks on Linux and Wasm
cross-compilation do not establish native macOS acceptance. Routine CI retains
the latest workflow/ref run through cancellation; a cancelled run never qualifies
its source. Native jobs have a 60-minute budget for cold setup and validation.
The [shared host rules](supported-hosts.md) own the common support contract.

## Prerequisites and focused checks

Prepare the pinned Rust 1.99.0 development toolchain with rustfmt, Clippy and
`wasm32-unknown-unknown`. Prepare Rust 1.85.0 and 1.88.0, including their Wasm
targets, for the advertised package floors:

| Package | Rust floor | Floor gate |
| --- | --- | --- |
| `ic-metrics` | 1.85, native and Wasm | `make msrv` |
| `ic-metrics-stable` | 1.88, native and Wasm | `make stable-msrv` |
| Private `ic-metrics-wasm-inspect` | 1.88, native | `make wasm-inspect-msrv` |

Use Git, GNU Make, Bash 3.2 or newer and standard Unix utilities. The
[local setup guide](local-setup.md#bootstrap-prerequisites) owns system bootstrap,
installer dependencies and the pinned common host, IC and Cargo-tool inventory.
The reviewed [Make interface](make-interface.md) routes common setup, formatting,
hooks and releases; product gates remain local.

```sh
make install-tools
make tools-check
export PATH="$PWD/.tools/host/bin:$PWD/.tools/ic/bin:$PWD/.tools/rust/common/bin:$PATH"
make install-hooks
```

Setup is explicit; checks never install tools or unlock the selected graph.
The reviewed snapshot owns default pins in `ci/tool-versions.env` and
`ci/ic-tools.tsv`; host, Rust and IC exceptions are independently selected
under the shared catalog contract. Use the same optional
`SHARED_TOOLING_STORE` setting for setup, checking and evidence collection.
Host/IC/Cargo paths select admitted shared generations; earlier sets and failed
candidates remain retained. Build-policy/compiler/native identity changes require
explicit Cargo-tool setup. Application flags and wrappers remain separate from
[the standard tool-build environment](local-setup.md#standard-cargo-tool-build-environment).

After Rust edits, run `make fmt`. It sorts workspace manifests and formats Rust;
`make fmt-check` is read-only. Select the affected package's focused checks:

| Scope | Commands |
| --- | --- |
| Arithmetic | `make check check-wasm clippy docs-check`; named `cargo test -p ic-metrics --locked <test-name>` |
| Durable adapter | `make stable-check`; named `cargo test -p ic-metrics-stable --locked <test-name>` |
| Host inspector | `make wasm-inspect-check` |
| Snapshot/pins | `make shared-tooling-check check-pins pin-tools-check` |
| Local tools/hooks | `make local-tools-test hook-check` |
| Release/evidence adapters | `make release-tools-check ci-evidence-check` |
| Maintained docs | `make check-doc-links`, consistency review and `git diff --check` |

Keep compilation checks sequential when they share `target/`; check for active
builds before source mutation or compilation. Bare Cargo commands select the
arithmetic package. Builds use locked dependencies. The arithmetic graph has no
third-party dependency, platform reader, IC feature or server harness. Native
stable tests use `VectorMemory` for storage/codec reopening, not IC execution.
The inspector tests argument/file/budget admission, report publication and typed
output failure; invocation inputs remain under `target/evidence/wasm-inspect-cli/`.

## Full delivery and release gates

Before delivering completed code, run `make ci`, then `make msrv`,
`make stable-msrv` and `make wasm-inspect-msrv`, reusing passing evidence only
for unchanged inputs. Full CI admits tools and pins before compilation, denies
Clippy warnings, and checks builds, docs and tests for all three packages.
Inspection and documentation-only work use narrower checks. Validation authority
and release effects are governed by [AGENTS.md](../AGENTS.md).

Release/publication are separate maintainer actions under
[the release contract](releases.md). Standard release preflight prepares the
locked dependency cache and selected Cargo tools before offline validation;
standalone preflight only fetches/checks offline. Preparation and late checks
bind the selected release commit rather than newer working-tree metadata.
Neither validation nor release performs artifact cleanup.

## Native evidence

The workflow captures exact source inputs and host/compiler identities before
setup, records setup/check/native outcomes and keeps stdout/stderr on failures.
Tool candidate selection preserves admitted failed inputs and diagnostics;
collection failure remains nonzero. Formatter logs outside the fixture scratch
root are included. Uploads retain `native-ci.tar.gz` and its checksum for 30 days,
including hidden release/index/configuration evidence inside the outer tar.

Release, hook and evidence fixtures substitute only their declared effects;
actual Git index, Make dispatch, receipt admission and failure retention retain
independent checks. These fixtures perform no real Metrics release or registry
publication. The admission fixture isolates parent validation/failure/summary
paths. Successful cleanup affects only invocation-owned scratch, while failed
inputs stay under `target/evidence/native-ci/`. Substitute execution does not
prove live GitHub release recovery or canister measurement behavior.

[Released 0.8.1 acceptance](evidence/release-081.md) verifies all three native
receipts and the complete Rust-floor run on its exact published source.
[The current handoff](status/current.md) binds pending work to separate local
qualification. Earlier host/reader/release observations remain in their evidence
owners and the verbatim guides retained by [the cleanup receipt](evidence/cleanup-082.md).
They are not current platform readers, validation commands or acceptance of a
later dependency graph. Actual IC execution and callback attribution belong to
the owning consumers under [the extraction contract](extraction.md#downstream-contract-checks).
