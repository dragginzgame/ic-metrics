# Historical handoff through 0.7.3

This is the frozen handoff before Shared Tooling 0.9.2 adoption, including the
initial pending 0.7.4 snapshot-selection cleanup. It retains original source,
validation and issue observations; use [the current handoff](current.md) for
current authority. All text below is preserved from the earlier handoff.

---

# Current handoff

ic-metrics owns allocation-free, dependency-free `no_std` arithmetic. Consumers
own platform reads, attribution, identities, registries, persistence and endpoints.
See [the extraction contract](../extraction.md).

## Pending 0.7.4 snapshot selection cleanup

The same reviewed Shared Tooling 0.9.0 revision now selects 89 explicit roots;
12 internal helpers follow their canonical companion declarations. Preview
reports 101 KEEP rows, and all 101 payload paths, hashes and modes remain exact.
Direct local commands, governance documents and evidence entrypoints stay selected.
Package metadata, lock, pins, Git index and refs remain unchanged. The compatible
0.7.4 draft records this maintained tooling cleanup; no library consumer action
or package-version edit is required. Canonical refresh/integrity, offline tools,
help routing, release fixtures, documentation links and diff checks pass. The
[frozen selection receipt](../evidence/snapshot-roots-074.tar.gz) and
[checksum](../evidence/snapshot-roots-074.tar.gz.sha256) retain the preview, both
manifests and focused logs. Unchanged Rust/native inputs reuse released 0.7.3
CI and package-floor evidence; no new full CI run is claimed for this metadata
cleanup.

The maintainer also authorized the two Canic tool-resolution assertion repairs,
explicit embedded-fixture refresh and focused held-HTTP qualification. These
scoped sibling edits preserve its existing integration work. Host Clippy and four
resolver tests pass on Linux; canonical fixture refresh and verification pass.
The selected runtime case passes preflight and starts prepared Testkit 0.34.5 /
PocketIC 16.1.0, then fails to build the required `canister_test` Wasm because Auth integration
leaves two denied dead-code warnings. Complete failed scratch and source/fixture
identities remain outside Cargo clean in Canic's
`.tmp/metrics-qualification-20261012/`; its handoff and existing 0.112.0 notes
record the repair. Canic #491 owns the blocker; no new macOS or held-HTTP acceptance
is claimed. Canic #450/#99/#447 and root #10 remain open.

## Published 0.7.3 and issue closeout

Both official non-yanked 0.7.3 archives verify against released/public
`e714085a972db88c348e4aabe57847f2124d2b97`, including every packaged Rust source.
[Release verification](../evidence/release-073.md) separates the actual committed
Host 0.14.9/Memory 0.35.17 lock from the earlier prepared Host 0.14.8 receipt.
The first exact-source CI observation passed package floors while the native
lanes were pending. [Complete native acceptance](../evidence/release-073.md#complete-native-acceptance)
now verifies Linux, Intel macOS and Apple Silicon receipts at the released source.

[Complete 0.7.2 native acceptance](../evidence/release-072.md#complete-native-acceptance)
now verifies both macOS receipts alongside the earlier Linux receipt. All three
native jobs and package floors pass. This completes #65's original entrypoint/
formatter adoption and #61's common-entrypoint follow-up using later equivalent
coverage; both issues are now closed. Cancelled 0.7.1 evidence retains its original outcome; newer independent
tooling/graph updates do not reopen those completed obligations.

#10 retains Canic's owning held-HTTP/interleaving and native qualification. Canic
#99/#447 remain open. The newer fixture-fix run `38233266774` at `baaf956` finishes
with both macOS tool-resolution assertions failing on `/var` versus `/private/var`
aliases. PocketIC refuses a stale embedded allocation peer before server/suite
startup, so the interleaving case never executes. Exact errors and the narrow
assertion/explicit fixture-refresh proposal are recorded in
[Canic #450](https://github.com/dragginzgame/canic/issues/450#issuecomment-6125036052).
The tested source, older public main and dirty sibling worktree remain distinct.
This inspection preceded the explicitly authorized scoped Canic repair above.

The subsequent observation passed Linux, Apple Silicon and package floors with
Intel still running; the final verified receipts now supersede that partial
observation. The original issue/evidence closeout changed documentation only and
needed no release draft; the later snapshot-selection cleanup is recorded above.

## Original 0.7.3 preparation and qualification

The current request adopts clean committed/public Shared 0.9.0
`aec7a149f581a42b9531fc747b46024fc0314fcf`. Three files update, with the same 101
payloads and no additions/retirements. Refresh and verification share syntax
admission; NUL input rejects before parsing and malformed input emits no records.
Payload integrity and committed-source ownership keep their separate checks.

The lock advanced after the 0.8.4 gate to Host 0.14.8 and Memory 0.35.17. It is
preserved for fresh qualification: official archives and upstream source verify,
with all 37 Host and 46 Memory Rust files unchanged from the earlier versions.
Fresh full CI passes in 262 seconds under the existing 0.7.3 approval, followed by
all three package-floor gates. Canonical inputs remain unchanged throughout.
Distribution and prepared fleet-reader integration fixtures pass; the initial
missing-PATH failure is retained. The owning record retains a separate 0.9.0
receipt binding the new graph. The old 0.8.4 receipt retains its exact earlier graph and checkpoints;
it does not qualify the later lock. Package metadata stays 0.7.2 and the compatible
draft remains 0.7.3. See the owning adoption record for separate source scopes.

The latest requested refresh adopts clean committed/public Shared 0.8.4
`dca2bdd018afa6be598f03bb3cce1bab79c66973`, excluding newer dirty sibling work.
Three payloads update; all 101 remain selected and verify, with no additions or
retirements. Workspace LOC gains complete JSON output using the same count path;
the human report remains supported. Fleet aggregation stays in Shared Tooling.
Actual JSON totals match the crate rows and the default table matches 0.8.3
byte-for-byte. The adopted fixture and full CI pass, the latter in 246 seconds
under the existing 0.7.3 approval, with unchanged gate inputs. The owning record
retains a separate 0.8.4 receipt. Product Rust, Cargo graph, pins and older evidence
retain their identities; unchanged compiler-floor results are reused. Previous
0.8.2/0.8.3 gates below retain their original snapshot scopes.

The requested continuation now selects clean committed/public Shared 0.8.3
`8cca7e67b03ce6e701b6e7dcec2e9753eb98337e` through canonical refresh from an
isolated detached copy. Ten payloads update, 91 remain unchanged and all 101
verify, with no additions/retirements. Formatting follows selected Rust pins;
redirected Cargo diagnostics refuse; minimal Make exports include their helpers;
individual snapshot copies are replaced atomically with retry/conflict checks.
Product Rust, Cargo graph, tool pins and earlier frozen archives retain their
pre-refresh hashes. Exact-source distribution fixtures and full CI pass, the
latter in 259 seconds under the existing 0.7.3 approval. Gate inputs remain
unchanged, tools pass offline without reinstall and unaffected package-floor
results are reused. The owning record retains a separate 0.8.3 receipt. The
previous 263-second CI below keeps its exact 0.8.2 source scope.

The requested [adoption](../evidence/adoption-073.md) selects clean committed
Shared Tooling 0.8.2 `aaf75a37717357dd62f4b0b15001eaa3ba1629cf` through canonical
distribution from an isolated detached copy. The original 100 payloads remain;
three task/catalog files update and the new Cargo-tool freshness task is added.
All 101 files verify. The online checker remains in Shared Tooling, separate from
offline tool admission; no schedule or executable pin changes here.

The already selected Host 0.14.7 artifacts/filesystem rows verify against official
non-yanked archives and released upstream source. All 37 consumed Rust files match
0.14.5 byte-for-byte. Released Memory 0.35.15, other lock rows, core arithmetic and
the stored V1 layout remain unchanged. Inspector checks, Clippy, named/actual CLI
tests and all three package-floor gates pass. Explicitly approved full CI passes
in 263 seconds on unchanged canonical inputs; the owning adoption record retains
its frozen receipt. Shared public main now matches the adopted 0.8.2 revision.
The new changelog
is compatible 0.7.3; package metadata stays 0.7.2. Prior dirty release documentation
is preserved; no staging, commit, release, publication or sibling edit occurs.

## Published 0.7.2 and initial follow-up

Both non-yanked official 0.7.2 packages verify against released/public
`711fbfa198fb16a3747441c0c1b0512a48047d77`, including every packaged Rust source.
[Release verification](../evidence/release-072.md) binds their checksums and the
four committed IC/Shared evidence archives. #64's frozen durable IC qualification
is delivered with unchanged archive identities and measured scope.

Exact-source Linux native and all package-floor CI jobs pass. Both macOS lanes
remain queued; #65 retains the delivered Shared 0.8.1 native obligation. #61's
cancelled 0.7.1 run can be superseded by later complete relevant receipts, without
claiming that cancelled run passed. Canic #99/#447 remain open and supply no new
#10 closeout evidence.

The next useful compatible maintenance is reducing redundant snapshot roots by
deriving internal helpers through the existing entrypoint closure, preserving all
current payloads and direct callers. Official Host 0.14.6 and IC Memory 0.35.15
are available for separate qualification; their release notes describe tooling
changes, not new library contracts. The released lock selects Host 0.14.5/Memory
0.35.15; the frozen preparation keeps its earlier graph. Shared's public committed
source remains adopted 0.8.1 at that observation; newer sibling
work is uncommitted and is not imported. This inspection changes no product
code, dependency selection, package metadata, index or refs.

## Original 0.7.2 preparation and qualification

Both non-yanked official 0.7.1 packages match released
`569a388bb0066bb51ede6095d88b40a65f36e82a`; [publication verification](../evidence/release-071.md)
retains their checksums and source identities. Its exact-source hosted Linux and
package-floor jobs pass, with both macOS lanes queued, so #61's new-entrypoint
native acceptance remains open.

The compatible 0.7.2 batch adds [frozen durable IC evidence](../evidence/stable-cost-072.md)
for #64: actual mixed-row upgrades, retained application ID, query discard, trap
rollback, typed refusals, explicit reset and continued recording. Two independent
runs and a fresh-extraction replay agree byte-for-byte; all four Wasms rebuild
exactly. Matched checkpoint-cadence costs use actual instructions, cycles and raw
Wasm bytes, separate from native reopening and arithmetic-only measurements.
The package guide now explains the measured scope and batching consequences.

The incoming lock selects Host artifacts/filesystem 0.14.4 and IC Memory 0.35.14.
Their non-yanked official archives, checksums, embedded source and library files
verify against released upstream revisions. The 37 consumed Host files match
0.14.3, and all 46 Memory source files match 0.35.13. Inspector checks, named
tests/actual CLI, warning-denied Clippy and both adapter native/Wasm/inspector
Rust 1.88 floors pass. The explicitly approved full current-graph CI passes in
313 seconds, followed by all three package-floor gates; canonical manifest,
lock, snapshot and tool-pin checkpoints remain unchanged. The final delivery
receipt retains those checks separately from IC replay. The prior 298-second
CI retains its original graph. No manifest requirement,
library Rust source, format or support-floor change is needed.

The requested [Shared Tooling adoption](../evidence/adoption-072-shared.md) uses
clean committed/public 0.8.1 `c97f9f9c7b7c706fffdcfc5925cf58759b58093f`, including
entrypoint-derived companions and automatic retirement after unchanged-source
ownership checks. All 100 existing payloads remain selected explicitly and verify,
with no additions/retirements. Newer dirty upstream work is excluded.
Canonical Rust setup/offline admission selects derive formatter 0.14.1, retaining
older generations. Literal direct/conditional macros remain intact, compile from
a separate crate on Rust 1.85 and sort stably. Metrics has no affected macro or
workaround marker to remove. The 0.8.1 refresh updates six payloads; pins and
prepared tools remain unchanged and pass offline admission. Strict field/parsing
and compiler/native/policy drift-retention fixtures pass on Linux Bash 5 and
genuine Bash 3.2.57. Final 0.8.1 CI passes in 274 seconds with all package-floor
gates and unchanged canonical inputs under the existing 0.7.2 approval; the
274-second 0.8.0 gate, intermediate 264-second entrypoint-source
gate and earlier 313-second receipt retain their prior snapshot scopes.
[#65](https://github.com/dragginzgame/ic-metrics/issues/65) owns new delivered-source
native acceptance, separate from #61's previous adoption.

Canic's public source and missing owning #10 evidence remain unchanged. Workspace
metadata stays 0.7.1; no staging, commit, tag, push, publication, hook activation or
sibling edit is performed. The explicit contributor-tool preparation above does
not change frozen IC measurement inputs or authorize a release.

## Original 0.7.1 Make adoption and upstream inspection

[Published 0.7.0 verification](../evidence/release-070.md) binds both non-yanked
official packages and exact source to `384046884365e3d73696e0813a43640d3b1f2cb4`.
The core remains dependency-free on Rust 1.85; the separate stable adapter uses
Rust 1.88. [#63](https://github.com/dragginzgame/ic-metrics/issues/63)'s arithmetic
cut is delivered. The release's compiler-floor and all three native jobs now
pass; downloaded receipt verification remains separate. Real IC upgrade/storage-cost
evidence
remains in [#64](https://github.com/dragginzgame/ic-metrics/issues/64).

The [compatible 0.7.1 batch](../evidence/adoption-071.md) adopts committed/public
Shared Tooling 0.6.5 through canonical distribution: all 100 selections verify
against `42f2091768b5f71c98a684d3dab563f408ca2dd9`.
Common setup/format/hooks/snapshot/release commands use one local entrypoint;
product adapters, release authority and compiler floors remain unchanged.
Focused formatting, hook, routing and release-admission checks pass, including
retained input checkpoints and refusal of later gates after Cargo input drift.
Full Linux CI passes in 298 seconds, with all three package-floor gates passing
on unchanged prepared Cargo inputs. The release-admission and common Make fixtures
also pass genuine Bash 3.2.57 on Linux; native adoption acceptance remains separate.
The lock preserves all released rows except incoming IC Memory 0.35.13, published during
review and separately verified against its official archive. Its library sources
match 0.35.12 byte-for-byte. Host 0.14.2 is already in the released 0.7.0 graph
and has no consumed source change. Package requirements and arithmetic stay unchanged.

Both [0.6.6 macOS receipts](../evidence/release-066.md#complete-native-acceptance)
are independently verified, completing #61's original Shared 0.6 criteria.
The common-entrypoint follow-up remains there for delivered native acceptance.
Canic's new successful dependency-audit run supplies no missing #10 runtime/native
evidence. Package metadata remains 0.7.0; no agent release, publication, staging,
commit, push or sibling edit is performed. Older preparation/qualification records
below retain their original source scope.

The subsequent read-only upstream check finds clean committed/public Shared
0.6.6 `a15eb9d406d287697df9bc8fa96db8cda6721a71`. It selects derive formatter
0.14.1 to preserve literal `$crate` paths; Metrics has no affected macro or
workaround marker. Adoption would require an explicit local tool-pin selection
and new-tool preparation with Rust 1.88 or newer, independently of library floors.
The snapshot and formatter pin remain 0.6.5 and 0.13.0 in this inspection.

The incoming lock now selects Host artifacts/filesystem 0.14.3. Both official
archives/checksums and embedded source verify against released
`543b137458feba0f6dfd3e458b680fb2be3d9e6d`; all 37 consumed library source files
match 0.14.2 byte-for-byte. Inspector check, warning-denied Clippy, named tests,
actual CLI and Rust 1.88 checks pass without changing the lock, manifest, pins or
snapshot. This focused graph qualification is separate from the earlier full CI
on Host 0.14.2. Shared 0.6.6 and Host 0.14.3 hosted CI are queued at observation;
no native acceptance is inferred. Verification and focused logs are retained
under `target/evidence/adoption-071/upstream-066` and
`target/evidence/adoption-071/host-0143-focused.log`.

## Original 0.7.0 wide-total preparation

The accepted optional [one-map durable adapter](../evidence/stable-070.md) adds
`ic-metrics-stable` outside the dependency-free arithmetic graph. The host owns
one admitted `app.metrics.v1` map; namespaced rows retain kind, units, reset epoch,
wide totals and all overflow flags. Core restoration and stored records reject
malformed/inconsistent fields, configuration differences and regressing snapshots.
Explicit reset/retirement never frees the allocation ID. The adapter needs Rust
1.88 on native/Wasm, while the core stays on 1.85. Native reopening, including
actual IC Memory bootstrap/rebootstrap, remains separate from
[#64](https://github.com/dragginzgame/ic-metrics/issues/64)'s IC upgrade/cost evidence.

Focused Clippy, restoration tests, both native/Wasm floors and release fixtures
pass. Publication selects both public packages in dependency order; a disposable
0.7.0 dry run builds both archives without uploads or real metadata changes.
The initial full CI exposed its newly added floor missing from a substituted
release fixture; that fixture now covers failure retention for all four gates.
The hook fixture also exports the optional package with its workspace manifest,
preserving success/failure evidence in its focused retention tests.
Current-batch `make ci` passes, including 44 core tests/seven doctests and nine
adapter tests/one doctest. All three package-floor gates pass, including native
and Wasm for core and adapter. The final two-package dry run verifies both archives.
[The frozen native bundle](../evidence/stable-store-070.tar.gz) retains exact source,
lock, dry-run payloads and successful/failed logs; fresh extraction verifies every
payload and reruns all 16 restoration/storage tests. These results are separate
from the earlier arithmetic-only comparison below. Existing consumers remain
opt-out and no sibling files change. Workspace metadata remains 0.6.6; the pending
release stays 0.7.0. No staging, commit, tag, push or upload is performed.

[#63](https://github.com/dragginzgame/ic-metrics/issues/63) owns the accepted
correctness cut: totals and integer means become `u128`, while individual
observations and counts remain `u64`. Exact count/value products fit the total;
actual overflow remains sticky with typed exact-projection failures. Consumer
logging remains once per flag transition in the owner's window.

[The review](../evidence/arithmetic-070.md) binds the six read-only caller
boundaries, durable IC inputs and measured footprint/cost. Focused tests,
native/Wasm Clippy and Rust 1.85 checks pass. The explicitly approved `make ci`
passes all documented gates, including 37 product tests and seven doctests.
Two final independent IC runs each verify 841 measured replies and 17 typed
rejections, including exact wide means/intervals beyond the old total limit.
Results agree byte-for-byte; the initial direct-division candidate and earlier
matched matrix remain separately retained. A fresh extraction verifies every payload, rebuilds all 16 byte-identical
Wasms and reproduces both raw CSVs exactly; its delivery receipt is retained.

All six consumer adoption issues are linked in the review; no sibling files or
versions are changed. Pending notes select 0.7.0 for the total/mean API cut.
Workspace/package metadata stays 0.6.6; no commit, tag, push or release is performed.

## Published 0.6.6 and current acceptance

[Published 0.6.6 verification](../evidence/release-066.md) binds local/public
source, tag and the official dependency-free archive to
`c651c095d5554e929a9cb96f5089226eda66ee90`. The README repair in
[#62](https://github.com/dragginzgame/ic-metrics/issues/62) is delivered and
verified. The current snapshot is Shared Tooling 0.6.3; the committed private
lock selects Host 0.14.1. Linux and both Rust floors pass, with its downloaded
Linux receipt's 75 source hashes and 14 payload hashes independently verified.
Intel is running and Apple Silicon queued; remaining native acceptance stays in
[#61](https://github.com/dragginzgame/ic-metrics/issues/61). The older 0.6.5 run is
cancelled and retains its historical source scope.

Host 0.14.1's upstream native matrix and MSRV now all pass. No newer committed
Host or Shared source is available; dirty upstream guidance is not adopted.
Canic's public source and unchecked runtime/native obligations are unchanged in
[#10](https://github.com/dragginzgame/ic-metrics/issues/10). No additional root
arithmetic repair is established by this inspection, and no pending release
entry is created for qualification-only documentation.

## Original 0.6.6 README cleanup

[#62](https://github.com/dragginzgame/ic-metrics/issues/62) is repaired locally:
the README keeps product examples, separate arithmetic/inspector Rust floors,
one complete setup/check/PATH recipe, local validation and publication commands.
Shared installer, hook and release semantics link to their existing owners;
the registry example selects the current 0.6 contract. Historical qualification
remains in the existing records. Link, consistency and diff checks pass, without
changing product code or adding a full gate. The compatible pending notes are
0.6.6; package/workspace metadata remains released 0.6.5. The issue stays open
until this documentation repair is delivered.

## Published 0.6.5 and incoming Host 0.14.1 review

[Published 0.6.5 verification](../evidence/release-065.md) binds local/public
source, tag and the official dependency-free archive to
`c4685c9f79d97a55f5dcd5d4ea4b796812fb2ad0`. The release delivers Shared Tooling
0.6.3 with committed Host 0.14.0. Hosted Rust-floor checks pass; Linux is running
and both macOS lanes are queued. [#61](https://github.com/dragginzgame/ic-metrics/issues/61)
still needs delivered-source native acceptance, not another arithmetic change.

The maintainer's incoming lock selects Host 0.14.1.
[Its separate review](../evidence/host-dependencies-0141.md) verifies official
archives and committed source, unchanged consumed APIs and focused inspector/
package-floor checks. This selection remains uncommitted and is not covered by
the released graph or preceding full CI. Host 0.14.1's receipt-preservation repair
belongs to its release adapter; Metrics needs no artifact/filesystem rewrite.

Canic's public source and existing runtime/native acceptance gaps are unchanged
from the preceding review; [#10](https://github.com/dragginzgame/ic-metrics/issues/10)
remains open. This check performs no sibling edit, workflow dispatch or release.
The qualification history below retains its original sources and observations.

## Original 0.6.5 Shared Tooling repair and Host selection

The incoming maintainer graph now selects Host 0.14.0 for the private inspector.
[Its separate review](../evidence/host-dependencies-0140.md) verifies official
archives, committed source and unchanged artifact/filesystem implementations.
The upstream process API cut has no Metrics caller. Inspector checks,
warnings-denied Clippy, selected tests and both package-floor checks pass; earlier full CI
results below retain their original Host 0.13.5 scope. Full `make ci` now also
passes against Host 0.14.0 in 230 seconds, with all 89 frozen technical inputs
unchanged. Host's subsequently published 0.14.1 changes only tooling/release
handling; consumed source is unchanged and the qualified lock remains 0.14.0.
The complete pending
batch remains compatible 0.6.5 with unchanged arithmetic and inspector contracts;
workspace/package metadata remains 0.6.4.

Shared Tooling's newer snapshot-consumption guidance is uncommitted upstream;
there is no newer clean committed revision to adopt. Canic's latest published
0.111.0 CI still fails changelog validation and embedded-artifact preflight before
the required runtime suites. Its owning fixes remain in
[#450](https://github.com/dragginzgame/canic/issues/450); Metrics
[#10](https://github.com/dragginzgame/ic-metrics/issues/10) retains consumer
acceptance. No sibling edit, build, release or workflow dispatch is performed.

The current snapshot is committed Shared Tooling 0.6.3
`4fd979d13c32adb3cb2f51f213ebfc4f98339b3d`. Normal direct targets archive stale
`prepare` intent after its metadata disposition is committed in a clean descendant
checkout, then select from current metadata and repeat full validation. This fixes
the reported 0.6.3-to-0.6.4 plan blocking committed 0.6.4 metadata; the next patch
is 0.6.5. The real plan remains untouched until the maintainer runs the release.
[The supplemental record](../evidence/adoption-065.md#supplemental-shared-tooling-063-adoption)
owns this qualification. Earlier results below retain their original source scope.
Full `make ci` passes in 267 seconds, both Rust floors pass, and the 85 frozen
technical inputs, real plan/version/graph/pins and 2,406 selected tool-file hashes
verify unchanged. The adoption remains local and uncommitted, ready for the
maintainer's ordinary commit and release flow.

### Original Shared Tooling 0.6.2 qualification

That snapshot is committed/public Shared Tooling 0.6.2
`7f1ca16b0dfa98021d2671017ecb7de767409b0e`, canonically refreshed with the
same 97 selections. It adds exact interrupted-release source-conflict diagnostics
and guarded recovery guidance, plus distinct Audit/Machete invocation examples.
Metrics has no Audit/Machete extension. Real saved plans remain untouched.
The incoming maintainer lock now selects Host 0.13.5. [Its review](../evidence/host-dependencies-0135.md)
verifies official archives/source and unchanged consumed read/inspection code;
the new private-sidecar API has no Metrics caller. Selected ShellCheck and
current/genuine Bash 3.2/Make 3.81 runner fixtures pass. Full `make ci` passes in
296 seconds with both Clippy gates and the inspector CLI test; both package
floors pass against Host 0.13.5. All 89 frozen technical inputs and incoming
graph/pins retain their hashes. [The adoption record](../evidence/adoption-065.md#supplemental-shared-tooling-062-adoption)
owns this qualification separately from the earlier Host 0.13.3 result below.
The complete batch remains compatible pending 0.6.5; workspace metadata remains
0.6.4. Upstream Shared/Host Linux jobs pass while their macOS lanes remain
pending; owning delivered Metrics acceptance remains in
[#61](https://github.com/dragginzgame/ic-metrics/issues/61).

### Original Shared Tooling 0.6.1 qualification

The maintainer reports 0.6.4 published. Work resumes from clean local 0.6.4
`9d374e098d43e1fa1f23230bc624b7b4db4bfa89`, preserving its dated notes,
workspace metadata and selected Host 0.13.3 graph. Earlier public observations
remain historical evidence; this continuation performs no release recovery.

Adopted committed/public Shared Tooling 0.6.1
`731909525038c58d6f80b498e80f8630b11c685d` canonically from a clean detached
checkout. All 97 selections remain, with four scripts updated. The reviewed
Cargo fixes stop conditional setup after preparation/admission/activation
failure, preserve original statuses and protect foreign locks. Padded build
counts use numeric comparison. Contributors rerun `make install-tools`, then
`make tools-check`; earlier selections and failed evidence remain retained.
The committed bytes match the separately reviewed source. Current Bash and
genuine Bash 3.2 Cargo fixtures, ShellCheck, real setup/offline admission and
two-checkout reuse without Cargo resolution or compilation pass. Full `make ci`
passes in 315 seconds with both Clippy gates; both Rust floors pass against the
preserved 0.6.4 metadata and Host 0.13.3 graph. All 86 frozen technical inputs
and both earlier tool-file catalogs retain their hashes. The initial setup
refusal of IC Host Tooling's active shared Cargo lock is retained; normal setup
succeeds once its owner finishes. [The evidence owner](../evidence/adoption-065.md)
distinguishes mock review, actual setup and exact-source native acceptance.

The candidate is compatible 0.6.5. Arithmetic/API/attribution/endpoint contracts,
pins and both package floors remain unchanged; no package/dependency selection,
real staging, commit, release or sibling edit is performed.
[#61](https://github.com/dragginzgame/ic-metrics/issues/61) retains delivered-source
native acceptance for this Shared 0.6 adoption. The older #49/#50/#51 cancelled
run gaps are superseded by the later recorded 0.6.3 matrix under the maintainer's
accepted closeout policy. [The coverage record](../evidence/release-063.md#superseding-older-cancelled-run-acceptance)
closes those issues while retaining their original cancelled-source identities.

Released 0.6.3 now has independently verified Linux, Apple Silicon and Intel
receipts plus both Rust floors. [Its Intel closeout](../evidence/release-063.md#supplemental-intel-acceptance-and-closeout)
completes [#60](https://github.com/dragginzgame/ic-metrics/issues/60), without
relabeling later Shared 0.6 or older cancelled-source evidence.

## Prepared 0.6.4 Shared Tooling 0.6.0 adoption

Adopted committed/public Shared Tooling 0.6.0
`75180980a0c4e4252d8a915aaecfaefd92bf9a4e` through the canonical exporter from a
clean detached checkout. All 96 existing selections remain selected; 16 update,
80 remain unchanged, and the explicitly added standard Cargo build helper makes
a verified 97-file snapshot. Common Cargo tools now share exact compiler/native/
source/packaged-lock/target/profile identities and use the shared standard tool
environment. Application build settings remain local; older installations and
failed build evidence are retained.

Metrics' custom native collector delegates both local Rust and referenced shared
build selection to the canonical owner, eliminating duplicate selection. It
retains safe local evidence and diagnostics when store admission fails, packs
the upload before reporting incomplete collection, and tests shared Cargo recovery
and redirected-store refusal. Real setup/offline admission, two-checkout Cargo
reuse without resolution or compilation, selected Clippy, both Rust floors,
Bash 3.2/Make 3.81 checks and full `make ci` pass. The full gate takes 251 seconds;
105 frozen inputs, 2,394 earlier tool files and the working lock remain unchanged
immediately after that gate, with 0.6.3 package metadata.
Two earlier shared IC-tool lock refusals and the initial default-compiler reuse
attempt are retained separately. [The adoption record](../evidence/adoption-064.md) owns setup and delivery
qualification; [#61](https://github.com/dragginzgame/ic-metrics/issues/61) retains
delivered-source native acceptance.

The candidate is compatible 0.6.4: arithmetic sources/APIs/behavior, tool
pins and both Rust floors remain unchanged. The maintainer commits the adoption
as `ddcd7665ac44f3f903b3c4d0faf2eb0963033a29` during qualification, then prepares
0.6.4 workspace/package metadata and dates its changelog. These subsequent
metadata changes remain separate from the passing 0.6.3-metadata local gate;
their release validation/delivery is not claimed here.
The pre-existing Host 0.13.2 working lock selection and earlier release-evidence
edits were preserved during adoption; the adoption selects no dependency update.
The subsequent Host 0.13.3 working selection is reviewed separately above.
The agent performs no sibling mutation, real staging, commit or release.

## Published 0.6.3 and current qualification

Published 0.6.3 `b51e30743ad23a74ef02fef0edcf2b3acca6d4e3`, public main and the
peeled annotated tag agree. [Release verification](../evidence/release-063.md)
binds the official non-yanked dependency-free archive, complete packaged source
and a downloaded Linux receipt with verified source/payload hashes, catalog,
host/pins and successful outcomes. Linux and both Rust floors pass; both Metrics
macOS lanes are queued. [#60](https://github.com/dragginzgame/ic-metrics/issues/60)
retains native acceptance for the delivered Shared 0.5.0 batch. Package/workspace
metadata is 0.6.3; arithmetic is unchanged from 0.6.2.

Released 0.6.2 now has [complete independently verified native acceptance](../evidence/release-062.md):
Linux, Apple Silicon, Intel and both package floors pass at its exact source,
with all three downloaded receipts verified. This completes the current root
arithmetic contract in [#57](https://github.com/dragginzgame/ic-metrics/issues/57)
and Shared 0.3.12 adoption in [#58](https://github.com/dragginzgame/ic-metrics/issues/58).
Cancelled 0.6.0/0.6.1 sources retain their historical gaps. The newer 0.6.3
tooling contract still needs its own macOS acceptance in #60.

The released private graph selects Host 0.13.1. At the initial release review,
a separate uncommitted Host 0.13.2 lock update was preserved without released-source
qualification. The newer prepared Host 0.13.3 graph is reviewed above.
At that earlier release verification, Shared was committed/public 0.5.0, with
successful Linux and Apple Silicon regression jobs and Intel queued. The pending
0.6.0 adoption above now supersedes that baseline; its own exact-source Linux
regression passes while both macOS lanes remain in progress. These observations
retain their separate source identities.

Remaining root issues concern source-bound native or consumer qualification.
Timers' [0.6 adoption](https://github.com/dragginzgame/ic-timers/issues/43) is
closed; [Backup #38](https://github.com/dragginzgame/ic-backup/issues/38) and
Canic's [accounting](https://github.com/dragginzgame/canic/issues/99) and
[owning adoption](https://github.com/dragginzgame/canic/issues/447) obligations
remain open. No consumer source/build or new arithmetic work is performed by
this release verification. Historical source gaps below retain their identities.

## 0.6.3 Shared Tooling 0.5.0 adoption preparation history

Adopted committed/public Shared Tooling 0.5.0
`a306180ce534227fcb98b882fba9a526d5d747e0` through the canonical exporter
from a clean detached checkout. Preview identifies 12 updates and two required
companions; the resulting 96-file snapshot verifies. Host/IC command paths now
select exact bundles in the canonical per-user store; Rust slots remain local.
Earlier installations and failed evidence are retained. Metrics' native CI
collector uses the shared evidence selector to retain referenced physical
payloads, with host/IC shared-reference and unrelated-bundle fixture coverage.

This extends the same compatible 0.6.3 batch: library sources, APIs, runtime
behavior, dependency/tool pins, supported consumer builds and both Rust floors
are unchanged. Package/workspace metadata stays 0.6.2. The
[current adoption record](../evidence/adoption-063-store.md) owns setup and
qualification evidence; [#60](https://github.com/dragginzgame/ic-metrics/issues/60)
retains delivered-source native acceptance. No sibling source, real index,
version, commit or release mutation is performed.

Real host/IC setup, complete offline admission and two-checkout reuse with zero
downloads pass; all 4,723 earlier physical tool files retain their checksums.
Affected fixtures and hooks pass on current Bash/Make and genuine Bash 3.2/Make
3.81. Full `make ci` passes in 241 seconds, both package floors pass, and all 104
frozen code/graph/pin/Make/workflow/snapshot inputs remain unchanged. Read-only
six-consumer review binds committed and working inputs separately. Exact-source
Shared Linux CI reports success; its macOS lanes and subsequent delivered Metrics
native acceptance remain separate. The initial 0.4.1 evidence below is historical.

## Initial 0.4.1 adoption preparation history for 0.6.3

Adopted committed/public Shared Tooling 0.4.1
`5ab05317f8da10c6388dc9096780131459d9db71` through its canonical exporter
from a clean detached checkout. All 94 selected files remain selected; the
read-only preview reports 16 updates and no missing companions. Metrics-owned
CI, native-evidence fixtures and shell instructions now select
`.tools/rust/common/bin`. Common tools share the selected-Cargo slot/receipt/byte
admission engine, and the full physical Rust tree is retained by the evidence
action. Prior installations and failed evidence are preserved.

The next changelog is 0.6.3: contributor setup changes leave published arithmetic,
APIs, behavior, consumer build requirements, dependency pins and Rust floors
unchanged. Package/workspace metadata remains 0.6.2. The
[adoption record](../evidence/adoption-063.md) records local qualification;
[#60](https://github.com/dragginzgame/ic-metrics/issues/60) retains exact-source
native acceptance. No sibling edit, commit, version change or release is performed.

Real Linux setup and offline admission pass; repeated setup dispatches no Cargo
with a refusing substitute, and all 2,329 prior Rust-tree files remain byte-identical.
Full `ci` (182 seconds), native/Wasm Clippy and both package-floor checks pass.
All 82 frozen code/graph/pin/Make/workflow/snapshot inputs remain unchanged.
Rust installation fixtures, CI evidence and the real formatting hook also pass
on genuine Bash 3.2.57/Make 3.81 on Linux. These checks do not qualify macOS.
The exact-source upstream Linux run passes real setup and portable tests but
fails its stale native-retention qualifier; the reproduced argument/path mismatch
and remaining shared-host documentation discrepancies are reported to Shared #118.

## 0.6.2 quantile costs and arithmetic evidence preparation history

The [quantile fast-path comparison](../evidence/quantile-cost-062.md) qualifies
checked-u64 product/division with an exact wide fallback against released 0.6.1.
Two full runs reproduce 296 measurements/eight typed rejections, and all eight
Wasms rebuild byte-for-byte from a fresh extraction. Per 1,000 queries, isolated
p50/p95 each save 200,000 instructions; the reporting cohort saves 400,000
instructions (23.4%) and 400,000 whole-update cycles (4.5%). The explicit cost
is 89 raw bytes in quantile-bearing probes and 79 extra instructions per query
on measured wide-fallback inputs. Recording and cumulative-count Wasms/deltas
are unchanged. APIs, states, range/error semantics, dependency graph and floors
remain unchanged; no consumer migration or source edits are required.

Maintained Clippy, all 18 histogram tests and Rust 1.85 native/Wasm checks pass.
Independent wide-oracle tests cover exact product caps, overflow/rounding
boundaries and invalid-fraction precedence. The explicitly authorized full `ci`
gate and both Rust floors pass with all 119 frozen code/graph/pin/Make/snapshot
and measurement-artifact inputs unchanged; maintained sources still match the
measured candidate byte-for-byte. The separate durable delivery receipt retains
the source patch, exact logs, input hashes and actual command outcomes.
The candidate/source patch, exact graph, logs, Wasms and raw
readings are retained in a separate durable frozen archive. Earlier released-source
measurement inputs remain unchanged. No version change or release is performed.

The maintainer-selected [frozen IC experiment](../evidence/arithmetic-cost-061.md)
measures byte-exact released 0.5.6 and 0.6.1 arithmetic with IC Testkit-owned
PocketIC 16.1.0 admission/startup. Two finalized runs agree on all raw CSV bytes;
the fresh-extraction replay rebuilds all 11 Wasms byte-for-byte and independently
validates 554 measured replies plus 11 typed admission rejections. The durable
archive retains sources, selected/seed locks, receipts, raw counters/balances,
projections, logs and Wasms. It is a frozen evidence artifact, not a maintained
workspace member, production reader, generic harness or runtime dependency.

Actual-overflow tracking adds recording instructions in this fixture; the new
histogram's complete probe is 167 raw bytes smaller, with different latest/overflow
contracts. Merging already prepared 16-observation batches uses 9.8 times fewer
bracketed instructions for aggregates and 4.3–6.2 times fewer for four-bound
histograms than recording the same 16,000 observations. Batch creation is excluded.
The cumulative-count/p50/p95 query cohort uses 1,708,250 instructions per 1,000
iterations, supporting consumer-owned reporting outside the recording path.
Zero-loop cycle variation is retained, not converted into universal API costs.
[The quantile-cost issue](https://github.com/dragginzgame/ic-metrics/issues/59)
owns the separately qualified narrow-rank change above.

The next changelog is 0.6.2 because the complete batch adds compatible query
optimization and measurement coverage; package metadata remains 0.6.1.
The released-source experiment itself leaves main source/graph/pin/Make/snapshot
inputs unchanged. Its selected fixture formatting, warning-denied Clippy, locked
offline builds and actual IC replay pass without a root Rust edit or broad gate.
No sibling mutation/build, commit, push, version change or release is performed.
Native arithmetic acceptance and consumer qualification retain their owning issues.

## Released 0.6.1 and native acceptance

Published 0.6.1 `39b357eb4e53051b5ad9afcfcd0a8c147c68a524`, public main and
the annotated tag agree. [Release verification](../evidence/release-061.md)
binds the official non-yanked dependency-free archive and a downloaded,
source/hash/catalog/host/outcome-verified Linux receipt. Linux and both package
floors pass; both macOS jobs are queued at inspection. #58 retains the new
snapshot's native acceptance. Arithmetic is unchanged from 0.6.0; that older run
was cancelled on unfinished macOS lanes and is not fully qualified. #57 retains
current arithmetic acceptance, with consumer adoption at its owning issues.

Released 0.5.6 now has [all three independently verified native receipts](../evidence/release-056.md#complete-native-acceptance),
completing #56. Earlier cancelled sources retain their actual gaps.
Shared Tooling 0.3.12 and Host 0.13.0 remain the latest committed/public inputs;
no new dependency or snapshot selection is needed. The ignored local evidence
tree was absent, so fresh hosted downloads recover released-source proof under
`target/evidence/review-062/`; deleted local preparation evidence is not restored.
That verification changed documentation and issue acceptance only; package versions
remain 0.6.1 and the finalized changelog is preserved. No pending release is selected
by that routine verification, and it ran no build, release, publication or sibling edit.

## 0.6.1 Shared Tooling adoption preparation history

Adopted committed/public Shared Tooling 0.3.12
`52e846369c39a1da371eac47ff97d94da925217e` through a clean detached canonical
exporter, preserving all 94 selected files. The compatible update repairs
temporary-directory handling in formatting/release checks, Rust setup checkout
selection and live/retained diagnostic consistency. Arithmetic, dependency and
executable pins, package versions and supported hosts remain unchanged.
[The adoption record](../evidence/adoption-061.md) owns source and qualification
evidence; [#58](https://github.com/dragginzgame/ic-metrics/issues/58) retains delivered-source
native acceptance. The pending changelog is 0.6.1; package/workspace versions remain 0.6.0.
Complete local `ci` (210 seconds), `msrv` and `wasm-inspect-msrv` pass with all
140 frozen code/graph/pin/snapshot inputs unchanged. Focused checks pass on
current Bash/Make and genuine Bash 3.2/Make 3.81, including symlinked relative
temporary paths. Real offline Rust preflight/checks pass from outside the checkout.
The actual released graph already selects private Host 0.13.0; this adoption
preserves it. Preparation evidence below retains its earlier Host 0.12.9 graph.
No commit, release, publication or sibling edit is performed by this adoption.

Released 0.6.0 `d156d647e88df137801989f2c7a010823c300d2f` agrees with public
main and the annotated tag. Its official non-yanked dependency-free archive
verifies checksum `fd550fca217e0989067bfcf14bdd41e1042ba95a326abe6fb04f900ef517da34`
and matches the arithmetic sources, original manifest, README, license and
embedded Git identity. At the release inspection, Linux and both package floors
pass in [exact-source CI](https://github.com/dragginzgame/ic-metrics/actions/runs/38122529690),
with both macOS jobs queued. #57 retains native receipt acceptance; this released
run does not qualify the changed Shared snapshot. Archive inputs remain under
`target/evidence/release-060/`. Consumer qualification stays with its owning issues.

## 0.6.0 arithmetic hard-cut preparation history

The maintainer selected explicit actual-overflow state, unordered aggregate and
histogram merge, and checked count/total intervals. [The hard-cut review](../evidence/arithmetic-060.md)
binds the current APIs and read-only six-consumer review. Exactly reached caps
remain exact; raw-field helpers stay conservative because provenance is absent.
Ordered summaries retain latest; histograms replace `summary()` with `aggregate()`
and own no latest. Mismatch rejection is atomic; identity, units, append-only
continuity, sample admission and persistence remain consumer-owned.

The whole pending batch moves from 0.5.7 to 0.6.0 for these public contract changes,
carrying the separately qualified Host 0.12.9 selection. Package/workspace versions
remain 0.5.6. No commit, release or publication is executed. [#57](https://github.com/dragginzgame/ic-metrics/issues/57)
retains root delivery/native acceptance; [Backup #38](https://github.com/dragginzgame/ic-backup/issues/38)
and [Timers #43](https://github.com/dragginzgame/ic-timers/issues/43) own coordinated
shared-type adoption, histogram/latest disposition and exact sample admission.
No sibling edits or owning builds are performed. Native/Wasm Clippy and focused
arithmetic tests pass. The completed final-source `ci` (250 seconds), `msrv` and
`wasm-inspect-msrv` pass with all 101 frozen inputs unchanged, separately from the
previous 99-input Host-selection run. The required formatting fixture now overlays
all current arithmetic modules; modern and Bash 3.2/Make 3.81 hook checks and the
existing failure-retention regression pass. The initial failed gate is retained.
Measured Wasm layouts add eight bytes per inspected summary/histogram instance;
new IC recording cost remains unqualified. Frozen old measurements remain historical.
The final read-only CI check observes all released 0.5.6 native jobs and both
package floors passing at its exact source. #56 still retains downloaded macOS
receipt verification; that run does not qualify this unreleased 0.6 source.

## Earlier compatible 0.5.7 private Host preparation

Published 0.5.6, tag and public main agree on
`392d1e2cbffb434dea591df8cb3165e8c625ab01`.
[Publication verification](../evidence/release-056.md) binds the dependency-free
archive and unchanged arithmetic. Both package floors and Linux pass, with a
[verified Linux receipt](../evidence/release-056.md#linux-acceptance); macOS remains
queued at this observation. #56 retains full released-source
native acceptance. The earlier 0.5.5 matrix now has
[all three verified native receipts](../evidence/release-055.md#complete-native-acceptance),
closing #54/#55. Earlier cancelled sources retain their actual status.

Shared Tooling 0.3.8 remains the latest committed/public revision and the 94-file
snapshot stays unchanged. Public Host advanced to 0.12.9; the local sibling
initially remained on 0.12.8 with dirty work, then caught up to the released
revision. The reviewed
[private graph update](../evidence/host-dependencies-0129.md) selects only the two
published Host versions/checksums, with unchanged consumed Rust code and package
floors. Existing inspector check/Clippy and named behavior/CLI tests pass. Complete
`ci` (181 seconds), `msrv` and `wasm-inspect-msrv` pass with all 99 frozen
code/graph/pin/workflow inputs unchanged; final logs and preservation records
belong under `target/evidence/review-057/`. The compatible pending changelog is
0.5.7; package/workspace versions remain 0.5.6. No arithmetic API, downstream
contract, new writer or platform reader changes. Canic #99/#447 remain open;
the owning held-HTTP/native obligation in #10 is not supplied by root publication.

## 0.5.6 metadata cleanup preparation history

Published 0.5.5, tag and public main agree on
`b995f787c8e08a6e2e8c18d99e223835f43f6e4e`.
[Publication and Linux receipt verification](../evidence/release-055.md) binds
the dependency-free package, passing Linux CI and both package floors. Apple
Silicon now [passes with a verified receipt](../evidence/release-055.md#apple-silicon-acceptance)
and Intel remains running; #54/#55 retain native acceptance.
The actual released lock
already selects [Host 0.12.7](../evidence/host-dependencies-0127.md); finalized
notes name the earlier prepared 0.12.6 graph. Subsequent upstream revisions
arrived during this review; the new local batch adopts reviewed Shared Tooling
0.3.8 `67285b28a98b7c4211ad32de726709d4e87edea4` through a clean detached
canonical exporter, preserving all 94 selected files. Its coordinated-package
archive guidance does not require a packaging override here: only the
dependency-free arithmetic crate is published. No fleet report is added.
The separate [Host 0.12.8 selection](../evidence/host-dependencies-0128.md)
changes only the two private package versions/checksums, with unchanged consumed
Rust code. Dirty sibling work is excluded.

The next compatible candidate is 0.5.6: release metadata operations now require
completed execution before cleanup can return success. On genuine Bash 3.2, missing
`RELEASE_DATE` after manifest/lock preparation previously restored originals but
returned zero. Selected-commit checks also returned zero and discarded exported
evidence after missing date/version expansion. The corrected existing metadata
and admission fixtures cover both boundaries, original restoration, retained
backups/selected inputs and ordinary failing-command status preservation.
[#56](https://github.com/dragginzgame/ic-metrics/issues/56)
owns the correction; [its evidence](../evidence/release-preparation-056.md) records
the reproduction and delivery qualification. Package/workspace versions stay
0.5.5; arithmetic APIs and downstream contracts are unchanged. The earlier
prepare-only full gates remain bound to Host 0.12.7 and Shared 0.3.7; they do not
qualify the completed source/graph.

The completed batch passes `ci` (183 seconds), `msrv` and `wasm-inspect-msrv`
with all 99 frozen code/graph/pin/workflow inputs unchanged. Selected ShellCheck,
metadata and admission fixtures pass on modern Bash and genuine Bash 3.2/Make
3.81. Snapshot and documentation-link verification pass; final logs and preservation
are separately retained under `target/evidence/review-055/`. #56 remains open
for eventual released-source native acceptance. No commit, release or publication
is performed by this continuation.

## 0.5.5 Shared Tooling 0.3.7 preparation history

Adopted reviewed `34e5ad7aac3599306c9572bb547f2239d09df1a3` through the clean
canonical exporter, preserving the 94-file selection. Mandatory Bash comparisons
now fail explicitly in the shared installer/fixtures and Metrics-owned release
adapter, fixtures and native host gate. The actual old adapter reaches a Cargo
child after a version mismatch; the old metadata fixture admits contradictory
successful parser output on Bash 3.2. The corrected existing regressions reject
both cases, retain evidence and preserve original metadata. Substituted host
observations also prove the actual workflow rejects wrong OS, architecture and
macOS version before writing PATH. [#55](https://github.com/dragginzgame/ic-metrics/issues/55)
owns delivery/native acceptance of the local correction.

The incoming workflow concurrency change is preserved and matches the new common
workflow/ref policy: newer routine runs cancel older revisions while retaining
the complete matrix. Cancelled sources remain unqualified. Incoming Host 0.12.6
is [verified independently](../evidence/host-dependencies-0126.md); narrow requested
updates and locked fetching leave the already selected graph unchanged. Product
Rust is unchanged from 0.12.5; arithmetic remains dependency-free. Package/workspace
versions remain 0.5.4 and the compatible pending changelog stays 0.5.5.

Metadata, expanded retention, native evidence, shared Rust-tool and canonical
hook checks pass on genuine Bash 3.2/Make 3.81; canonical hooks pass on the modern
profile too. Selected ShellCheck/actionlint and complete offline tool admission
pass. Complete `ci` (180 seconds), `msrv` and `wasm-inspect-msrv` pass with all
81 frozen code/graph/pin/workflow inputs unchanged. Current complete delivery
gates and preservation records belong under `target/evidence/adoption-055-current/`
and [the adoption record](../evidence/adoption-055.md); earlier 0.3.6 qualification
below does not qualify this changed snapshot/graph. [#54](https://github.com/dragginzgame/ic-metrics/issues/54)
retains the shared adoption's delivered-source native acceptance.

## Earlier 0.5.5 preparation with Shared Tooling 0.3.6

Adopted reviewed `0604bfd730ec7ec288cd2cfdad217a0d42bf256b` through the canonical
exporter from a clean detached checkout, preserving all 94 selected files.
The pre-commit hook propagates failed Git tree observations; the formatting
adoption checker requires completion. The existing retention regression now
checks that actual checker cleanup for nounset, early success and completion.
Lockfile-selected Cargo executables are available through the shared installer;
Metrics adds no server or product executable extension.

Explicit Binaryen 133 setup, repeated reuse and complete offline tool checking
pass on Linux, with verified old 132 and new 133 bundle receipts retained.
The unchanged owner optimization/execution smoke passes in the isolated clean
checkout using prepared tools and Node 24.21.0; no producer frontend gate is
added to Metrics. Canonical hook fixtures pass on both current and genuine
Bash 3.2/Make 3.81 profiles; the selected Rust-tool and expanded retention
fixtures pass on that legacy profile too. [The adoption record](../evidence/adoption-055.md)
owns source identities, scope and validation evidence. Package/workspace
versions remain 0.5.4; the compatible pending changelog is 0.5.5.
[#54](https://github.com/dragginzgame/ic-metrics/issues/54) owns native acceptance.
The incoming private Host 0.12.5 selection is preserved and
[verified separately](../evidence/host-dependencies-0125.md); its changed durable
writer is outside the inspector's unchanged read path. The first complete gate
passes but detects the incoming lock change at final preservation. The repeat
qualifies the updated graph: complete `ci` (238 seconds), `msrv` and
`wasm-inspect-msrv` pass with all 81 frozen code/graph/pin/workflow inputs
unchanged. Both runs and their preservation checks remain separately retained
under `target/evidence/shared-054/`.

## Finalized 0.5.4 validation tooling

Release `1622e98a73f7bf7a42bae48a4266840e0f6726e0` matches public main and local
tag `v0.5.4`. The preparation record below retains its original 0.5.3 metadata;
finalization advances package/workspace versions to 0.5.4. Source-bound hosted
acceptance remains with [#52](https://github.com/dragginzgame/ic-metrics/issues/52)
and [#53](https://github.com/dragginzgame/ic-metrics/issues/53).
[Exact-source CI](https://github.com/dragginzgame/ic-metrics/actions/runs/38060740790)
initially passes Linux and MSRV with macOS queued. A subsequent review verifies
[Linux and Apple Silicon receipts](../evidence/release-054-native.md); Intel is
initially still running. Later [complete native acceptance](../evidence/release-054-native.md#complete-native-acceptance)
verifies all three receipts and closes #52/#53. These results belong to finalized
0.5.4, not later batches.

## 0.5.4 preparation record

Native CI now allows 60 minutes for cold tool setup, the complete suite and
evidence collection. GitHub explicitly reports that 0.5.0's Intel job exceeded
the previous 30-minute limit; its retained log reaches the fixture-retention
script after release admission completes. The compatible fix changes only the
native job budget; every lane, command, source receipt and failure collector is
preserved. Package/workspace versions remain 0.5.3. Hosted qualification stays
with [#52](https://github.com/dragginzgame/ic-metrics/issues/52).

The admission fixture also clears inherited validation log/failure destinations
and GitHub summaries. Its actual pre-fix execution fails and expands a seeded
parent summary from one line to 61 lines; after correction it passes without
changing any parent evidence. The existing retention regression exercises this
boundary on current Bash/Make and genuine Bash 3.2/Make 3.81, retaining its own
inputs and results. [#53](https://github.com/dragginzgame/ic-metrics/issues/53)
owns delivery/native acceptance; arithmetic and production logger behavior are
unchanged. The incoming private Host 0.12.4 selection is
[verified separately](../evidence/host-dependencies-0124.md).

The expanded batch passes complete `ci` (182 seconds), `msrv` and
`wasm-inspect-msrv`, preserving all 79 frozen code/graph/pin/workflow inputs.
Selected ShellCheck, workflow lint and final documentation/diff checks pass.
Reproduction, parent-isolation and genuine Bash 3.2/Make 3.81 regression logs,
Host archive/source verification and current gates are retained under
`target/evidence/review-054-more/`. Shared 0.3.5's producer-only fixture correction
is reviewed; this local correction needs no snapshot or optimizer-pin change.
The preceding budget-only qualification remains separate below.

Workflow lint and structural comparison pass: only the native timeout changes.
Complete `ci` (184 seconds), `msrv` and `wasm-inspect-msrv` pass with all 79 frozen
code/graph/pin/workflow inputs unchanged. The first passing suite encountered an
incoming Host 0.12.4 lock update; that separate change is preserved and the repeat
qualifies the current inputs. Logs and both preservation checks are retained in
`target/evidence/native-budget-054/`. No commit, release or workflow dispatch is
performed; hosted qualification remains outstanding.

## Released 0.5.3 completed validation dispatch

Published 0.5.3 is `8cb8f9f59db58e6a1cdcb94be0135ef736b29ae4`, matching public
main, the release tag and official non-yanked dependency-free registry archive.
Publication and Linux receipt verification are recorded in
[#51](https://github.com/dragginzgame/ic-metrics/issues/51); its remaining native
acceptance stays separate from the pending budget repair.

The subsequent issue review finds the run complete: Linux and both floors pass,
while both macOS jobs are cancelled. GitHub's check annotations report maintainer
cancellation for each. This replaces the earlier queued observation, not the
missing native acceptance; raw jobs/annotations remain under
`target/evidence/issues-055/`.

## 0.5.3 preparation record

Adopted committed Shared Tooling 0.3.3
`d63f0cfaba8ab2961d6012064adbf051c1898bc1` from a clean detached checkout,
preserving the 94-file selection. The runner admits bounded canonical decimal
nesting metadata before dispatch and requires completed wrapper/body execution
before returning success. Incomplete exits preserve available evidence; normal
failed targets retain their status and release ordering/authority remain intact.
The old Bash 3.2 actual-entrypoint zero-exit defect is reproduced locally.

The existing Metrics release-admission fixture now covers invalid/valid depth
at the actual logger boundary. Its complete adapter checks and the canonical
producer fixture pass on current Bash/Make and genuine Bash 3.2/Make 3.81.
Selected ShellCheck, workflow lint and snapshot verification pass. Complete
`ci` (212 seconds), `msrv` and `wasm-inspect-msrv` pass, preserving all 81 frozen
code/graph/pin/workflow inputs. [The adoption record](../evidence/adoption-053.md)
retains rejected provisional fixture selection and current source-bound evidence.
Package/workspace versions remain 0.5.2; sole pending 0.5.3 is compatible.
Arithmetic, reports, executable pins and the private graph remain unchanged.
[#51](https://github.com/dragginzgame/ic-metrics/issues/51) owns delivery/native
acceptance. No sibling edit, commit, push or release is performed.

## Released 0.5.2 setup and fixture repairs

Published 0.5.2 is `2400e918e5a1c89a769768621c0cfe1006067f35`, matching public
main, the local release tag and official non-yanked dependency-free registry
archive. [Publication verification](../evidence/release-052.md) binds packaged
source, manifest, lock, README/license and embedded Git identity. Its exact-source
CI passes Linux and both package floors. Its downloaded Linux receipt verifies
source/payload/catalog/run/host/pins and successful outcomes; both macOS jobs
remain queued. Native acceptance remains incomplete in
[#49](https://github.com/dragginzgame/ic-metrics/issues/49) and
[#50](https://github.com/dragginzgame/ic-metrics/issues/50). The preparation record
below retains its original package versions and graph identity; published
release metadata advances package versions to 0.5.2. Later local qualification
does not replace this source's hosted native acceptance.

The subsequent issue review finds Apple Silicon successful and Intel cancelled,
with Linux and both floors still successful. GitHub's Intel annotation reports
maintainer cancellation. Its missing acceptance and the required native receipts
remain open; jobs/annotation evidence is retained under
`target/evidence/issues-055/`.

## 0.5.2 preparation record

The compatible batch adopts committed Shared Tooling 0.3.2
`c16444bf006f17c5bb4dda5ad070a0f345da9623` through a clean canonical refresh.
The 94-file selection preserves all 93 earlier files and adds the advisory README
review task. Setup admits platform/pins and Rust/Cargo before installation;
authenticated host diagnostics identify the exact tool and repair command.
Shared formatting/setup/check/LOC commands preserve Cargo descriptors and reject
unsafe Make modes. Metrics' native workflow fixture distinguishes both read-only
preflight phases from installation and retains early-refusal logs.

The same Bash 3.2 false-success defect is reproduced in Metrics' own release
cleanup. All six owned fixtures now require explicit completion before accepting
success, preserving prior failure statuses and evidence policy. The existing
regression checks each actual cleanup body with nounset, early-zero and success
cases. Focused modern Bash/Make and genuine Bash 3.2/Make 3.81 checks and selected
ShellCheck pass; actual parallel complete toolset reuse, offline checking,
formatting and LOC reporting pass without jobserver warnings. Complete `ci`
(197 seconds), `msrv` and `wasm-inspect-msrv` pass, preserving all 81 frozen
code/graph/pin/workflow inputs. [The adoption record](../evidence/adoption-052.md) owns the
source/graph identities and retained failure records.

The incoming private Host 0.12.2 lock is preserved and
[qualified separately](../evidence/host-dependencies-0122.md): official registry,
archives and source verify; consumed Rust is unchanged and focused inspector/floor
checks pass. Arithmetic, reports, executable pins and all six consumer policies
remain unchanged. Package/workspace versions stay 0.5.1; sole pending 0.5.2 is
compatible and selects no release. Delivery/native acceptance remains in
[#49](https://github.com/dragginzgame/ic-metrics/issues/49) and
[#50](https://github.com/dragginzgame/ic-metrics/issues/50). Dirty newer Shared
sibling work is excluded; no sibling edit, commit, push or release is performed.

## Released 0.5.1 Cargo jobserver repair

Published 0.5.1 is `a2f8e6e5e3d57f2d9eaff61791230ac1efbbafb8`, matching the
annotated tag, package/workspace versions and official non-yanked dependency-free
registry archive. [Publication and Linux receipt verification](../evidence/release-051.md)
bind the released source, payload/catalog/run/host/pins and successful outcomes.
At the initial inspection Linux and both package floors pass, with macOS Intel
and Apple Silicon queued.
A subsequent [complete native acceptance review](../evidence/release-051.md#complete-native-acceptance)
verifies all three source-bound receipts and completes
[#48](https://github.com/dragginzgame/ic-metrics/issues/48). The release delivers the
[owned descriptor repair](../evidence/adoption-051-make.md) and separately
[qualified private Host 0.12.1 graph](../evidence/host-dependencies-0121.md).
Earlier preparation records keep their original package versions and graph
identities. Shared #99's canonical correction is adopted in the pending batch
above. #47 still waits for 0.5.0's Intel receipt; #10 waits for Canic's owning
qualification. Neither is closed by a newer local or Linux-only result.

## Released 0.5.0 common toolset

Published 0.5.0 is `01549632c0c3fa6e1ff315ce4de803ddfae904ad`, matching public
main, annotated tag, package/workspace versions and the official non-yanked
registry archive. [Publication verification](../evidence/release-050.md) binds
these identities and unchanged dependency-free arithmetic. The release delivers
Shared Tooling 0.3.0 `88a73139a0f083344c41a6f6f4b5c3a8aca7dc1d` through the clean
93-file canonical refresh. Dirty sibling dashboard/installer edits are excluded.

Remove retired host installer flags `--with-ripgrep` and `--with-cloc`; run
`make install-tools`, then `make tools-check`. Setup/check run all four host,
five IC and three Cargo tools in order, including under parallel Make. Native
CI uses that same aggregate with distinct setup/check logs and a common outcome.
Product extensions use the canonical ordered lists; Metrics has no extra target.
Admitted Rust-only release preparation remains intact. Arithmetic, reports,
platform reads, consumer state/identity and executable pins are unchanged.

[The adoption record](../evidence/adoption-050.md) retains actual complete setup/
reuse and offline admission, full Linux validation, both package-floor checks,
GNU Make 3.81/Bash 3.2 and source preservation. The incoming private Host 0.12
selection is [qualified separately](../evidence/host-dependencies-0120.md), with
unchanged consumed Rust source. The original 176-second full gate remains bound
to Host 0.11; the current Host 0.12 graph passes its own 169-second gate and both
floors. Those preparation records retain package versions 0.4.0; the maintainer's
subsequent release advances them to 0.5.0.

[Exact-source release CI](https://github.com/dragginzgame/ic-metrics/actions/runs/38046372803)
passes Linux and both package floors. The downloaded Linux receipt verifies
ZIP/inner/payload/source/catalog, run/host/pins and seven successful outcomes,
including actual aggregate/collector/release/admission/CLI execution. A later
[Apple Silicon receipt review](../evidence/release-050.md#apple-silicon-acceptance)
verifies that passing host too; Intel later exceeds the 30-minute budget.
[#52](https://github.com/dragginzgame/ic-metrics/issues/52) owns the budget repair.
Delivery is complete;
[#47](https://github.com/dragginzgame/ic-metrics/issues/47) retains only this
source's Intel acceptance, separate from [Shared #98](https://github.com/dragginzgame/shared-tooling/issues/98)
and completed 0.4.0 acceptance. Records: `target/evidence/review-050/` and
`target/evidence/issues-051/`.
No sibling edit, setup, build, graph update, commit, push or release is performed
in that publication review. Subsequent compatible work is collected under the
pending 0.5.3 heading above; finalized 0.5.0 remains unchanged.

## Released 0.4.0 tooling cut

Published 0.4.0 is `97ec991776bb16efbab59faeb43bc72ce9ebcefa`, matching public
main, annotated tag and the official non-yanked dependency-free registry archive.
[Publication verification](../evidence/release-040.md) binds these identities and
unchanged arithmetic. Adopting Shared Tooling 0.2.13
`5864f468d39f8f9d1bd26fca1afe0e20f25f1b5e` removes previously supported
newline-containing operational checkout paths. The maintainer selected this
minor adoption; the provisional compatible 0.3.8 Host entry moves into this same
batch. Supplied/resolved LF/CR snapshot directory paths refuse before a neighbor
is selected. Affected operational directories need explicit renaming; existing
evidence is retained. Arithmetic APIs, consumer state and report output are unchanged.

The clean canonical refresh preserves all 93 selected files. Standard release
preflight prepares pinned Rust tools after source/candidate and locked-cache
admission, then checks offline before validation; standalone preflight never
installs. Preparation refuses changed tool pins. Local validation guidance now
requires the documented complete suite before delivery, with narrower inspection/
documentation checks and separate release authority. Qualification is recorded in
[the adoption evidence](../evidence/adoption-040.md).
The complete Linux suite passes (`ci`, arithmetic MSRV and inspector MSRV), as
do both local Make/Bash profiles, snapshot-path checks and preservation. Source-bound consumer native acceptance is now complete:
[exact-source CI](https://github.com/dragginzgame/ic-metrics/actions/runs/38042698441)
passes Linux, Intel macOS, Apple Silicon and both package floors. All three
independently downloaded receipts verify ZIP/inner/payload/source/catalog,
run/host/pins and actual fixture execution in
[the release record](../evidence/release-040.md#complete-native-acceptance).
This completes [#45](https://github.com/dragginzgame/ic-metrics/issues/45) and
[#46](https://github.com/dragginzgame/ic-metrics/issues/46), retaining the earlier
partial observations separately. Upstream 0.2.13 passes its own full native matrix.
This review dispatches no workflow or release.

The batch also preserves the incoming private inspector Host 0.11.0 selection.
[Its review](../evidence/host-dependencies-0110.md) binds non-yanked official index
rows, cached archives, released source and passing locked inspector Clippy,
argument/report/actual CLI tests and Rust 1.88 compilation. Consumed artifact/read
source is unchanged; the Host process hard cut has no caller here. No arithmetic
API, report or consumer contract changes, reset or reinstall are required by
that private dependency update.
Package/workspace versions are now 0.4.0; preparation preserved the incoming
Cargo selection before the maintainer's release.

## Upstream review

Public Shared Tooling main is now committed 0.3.0 `88a7313`; its
[exact-source CI](https://github.com/dragginzgame/shared-tooling/actions/runs/38044218125)
passes Linux, lint/security and Apple Silicon; Intel is running at inspection.
The actual Metrics `make -j4 format-tools-check` probe succeeds but emits two
closed-jobserver-descriptor warnings from Cargo, confirming
[Shared #99](https://github.com/dragginzgame/shared-tooling/issues/99)'s canonical
Make boundary here. Its selected snapshot remains intact. The complete-setup
preflight and exact host diagnostics in
[Shared #101](https://github.com/dragginzgame/shared-tooling/issues/101) are locally
implemented upstream but uncommitted; no consumer adoption is performed.
The released adoption above replaces the earlier
documentation-only 0.2.14 refresh; that source-bound review remains under
`target/evidence/shared-0214/`. The fleet CI inspector/dashboard implementation
stays upstream. Host source advances to released 0.12.1
`e5ecfa06c14d144cfeb85ea89d65906b1bf81636`, with the incoming private selection
reviewed separately above. Shared's latest committed source remains 0.3.0;
Shared's newer installer/documentation work remains dirty and is not adopted. Canic public main remains
`c4c046f947b2b28f4342cbf6efe9221ba1ed5f70`, with
[#447](https://github.com/dragginzgame/canic/issues/447) and
[#99](https://github.com/dragginzgame/canic/issues/99) open. Root
[#10](https://github.com/dragginzgame/ic-metrics/issues/10) retains that consumer
qualification. No sibling edit, setup or test is run.

## Released 0.3.7

Release source is `7c9402eb8e0bc38fffa0db62be77ab314a88a0e2`; publication is
maintainer-reported. [Exact-source CI](https://github.com/dragginzgame/ic-metrics/actions/runs/38037875150)
now passes Linux, Intel macOS, Apple Silicon macOS and both package floors.
[All three downloaded receipts](../evidence/release-037.md) verify ZIP, inner,
payload/source/catalog, run/host/pin identities and actual fixture execution,
completing [#44](https://github.com/dragginzgame/ic-metrics/issues/44).
No workflow rerun was dispatched. This acceptance does not qualify 0.4.0.

### Preparation evidence

The prepared 0.3.7 batch adopted committed Shared Tooling 0.2.11
`83efac446348dea024798a331d77933b24b429dc` through its clean canonical exporter.
The 93-file selection adds the formatting reporter. Success output is concise;
failed commands retain full stdout/stderr and their failing status. Hook and
isolated release fixtures include the companion; native source receipts include
it, and the native collector archives reporter logs outside its scratch tree.
[The adoption record](../evidence/adoption-037.md) binds focused Bash 5/3.2 checks,
actual formatting/hooks, substituted release/collector effects and preservation.

This is compatible developer presentation and evidence retention, with unchanged
formatter selection/order, exit semantics, product APIs and report output.
No consumer reset or reinstall was required. Preparation retained versions 0.3.6; production Rust,
Cargo selection and pins are unchanged. The canonical repair for
[Shared #30](https://github.com/dragginzgame/shared-tooling/issues/30) now rejects
unsafe modes even when `MAKEFLAGS` hides them; Make must generate `MFLAGS`.
[Supplemental qualification](../evidence/adoption-037-make.md) covers the actual
consumer's release, formatting and publication routes on GNU Make 4.3/Bash 5 and
GNU Make 3.81/Bash 3.2, preserving safe replacement flags and parallel dispatch.
Delivery and changed-source native acceptance are now complete in #44.
No full local CI, resolver, commit or release ran during that preparation.

[The scoped downstream closeout](../evidence/consumer-closeout-037.md) binds
IcyDB 0.269.1's ten passing metrics-state tests and Linux/Intel/Apple Silicon
helper qualification to exact committed source and lock. It completes the original
IcyDB #298/#309 scope without claiming passing SQL tier-b or a release gate.
IcyDB #311 retains adoption of the newer Make guard; root
[#10](https://github.com/dragginzgame/ic-metrics/issues/10) retains Canic's
held-HTTP/native obligation. No sibling execution or file mutation occurs.

## Released 0.3.6

Published 0.3.6 matches source/tag `93c350a1179c83a3cfc8f7f713c50bc1c6be6a8f`.
[Its verification](../evidence/release-036.md) binds the dependency-free registry
archive, unchanged arithmetic, complete native/MSRV and all three downloaded
source-bound receipts. The earlier Linux/Apple Silicon success with Intel running
remains an initial observation, separate from the subsequent completion.

The prepared batch adopted Shared Tooling 0.2.9
`f8a70ba348e9975a6eb5b337860b00bc8a0b36d1` through the clean exporter. Its unchanged
92-file selection records immutable source-version metadata and validates
malformed/duplicate annotations. [The preparation record](../evidence/adoption-036.md)
retains Linux Bash 5/3.2 distribution, release/admission and focused checks;
fleet reports remain upstream. Released private Host 0.10.1 has
[its own review](../evidence/host-dependencies-0101.md), binding official archives,
unchanged consumed read/artifact source, Clippy, named/CLI tests and Rust 1.88
compilation. The durable parent-sync repair has no Metrics caller.

The read-only downstream recheck retains public IcyDB 0.269.0
`63ac8cbf9337306187e8bf74309ed9c576aca2af`, selecting registry Metrics 0.3.2.
[Its completed CI](https://github.com/dragginzgame/icydb/actions/runs/37940288483)
now passes both native macOS jobs, static, core, workspace, tier-a, MSRV and
Wasm-size. Downloaded native logs confirm actual library/CLI builds and portable
automation. Tier-b still fails: its downloaded log observes PocketIC's clean
exit after 60.532 seconds during compilation, before test execution. This does
not establish an arithmetic failure or a passing overall gate; IcyDB #298 and
root #10 retain their remaining owning acceptance. Canic public main remains
0.110.54 `c4c046f947b2b28f4342cbf6efe9221ba1ed5f70`, with held-HTTP/native
qualification still in #99/#447. Inputs/logs are retained under
`target/evidence/continuation-036/`; no sibling execution or mutation runs.

The subsequent public-main recheck advances IcyDB to 0.269.1
`76dc93ead6b66c8db9cb5c402355867dbdf188e3`, selecting registry Metrics 0.3.5
and Testkit 0.28.0. [Exact CI](https://github.com/dragginzgame/icydb/actions/runs/37974259856)
passes both native macOS jobs, static, core, workspace, tier-a, MSRV and Wasm-size,
while tier-b and the aggregate gate fail. The matching SQL Tier C workflow also
fails; it is not substituted for acceptance. The downloaded tier-b log observes
PocketIC exiting cleanly after 60.665 seconds while compilation is still active,
before test execution; this is not a measurement assertion failure. Inputs are retained under
`target/evidence/continuation-036-recheck/`; the earlier 0.269.0 observations above
remain bound to their original source/graph.

## Released 0.3.5

Published 0.3.5 matches source/tag `6c09738c8183bd539e74859fe5433709a928c655`.
[Its verification](../evidence/release-035.md) binds the dependency-free registry
archive, unchanged arithmetic, passing Linux/MSRV and downloaded Linux receipts,
including the expanded actual CLI test. The later
[complete native acceptance](../evidence/release-035.md#complete-native-acceptance)
verifies both macOS archives, exact-source logs and all three passing native
jobs plus MSRV. Earlier queued observations retain their original scope.
It adopts Shared 0.2.8 and Host 0.10.0; the original
[adoption](../evidence/adoption-035.md),
[Host](../evidence/host-dependencies-0100.md) and
[CLI](../evidence/inspector-cli-035.md) records retain their own inputs and limits.

Earlier 0.3.3 now has complete native/MSRV and downloaded three-host receipts in
[its acceptance record](../evidence/release-033.md#complete-native-acceptance),
completing the original installer and literal-hook obligations in #42/#43.
Cancelled 0.3.1 jobs remain non-execution observations. Later source/graphs and
the Make execution companion retain separate qualification.

## Released 0.3.4 Make and qualification fixes

Published 0.3.4 matches source/tag `5a5f1dab1f7ee3e1e5624c9d889148c39abf45f2`.
[Its verification](../evidence/release-034.md) binds the dependency-free registry
archive, unchanged arithmetic, passing Linux/MSRV and downloaded Linux receipts,
including the execution companion and real CLI/hook coverage. Both macOS jobs
remain queued; #44 retains its Make companion/failure-boundary acceptance criteria.

The release adopts Shared 0.2.7 and fixes unsafe Make execution, inherited smoke
roots and newline-root formatting qualification. Its
[preparation record](../evidence/adoption-034.md) retains the original Host 0.9.4
preservation scope. The released graph instead selects Host 0.9.5; its now-complete
[separate review](../evidence/host-dependencies-095.md) binds unchanged upstream
library source, package/source hashes, inspector Clippy, named/CLI tests and
Rust 1.88 compilation. No arithmetic or consumer contract changes.

The earlier 0.3.0 five-tool hard cut now has complete native/MSRV and downloaded
macOS receipt acceptance in [its supplemental record](../evidence/release-030.md#native-acceptance-complete),
closing #41. #42/#43 are completed by the later 0.3.3 acceptance above; #44 remains open.

## Released 0.3.3 tooling maintenance

Published 0.3.3 matches source/tag `b3ddfdf0406b54ef9a98ce48cbf5a9afe5fe406b`.
[Its verification](../evidence/release-033.md) binds the registry archive,
unchanged arithmetic, passing Linux/MSRV and downloaded Linux receipts, including
both shared Make includes, real formatting hooks and actual CLI coverage. All
three native hosts now pass with independently verified source-bound receipts in
[the completion record](../evidence/release-033.md#complete-native-acceptance).
The preparation evidence below retains its original scope.

The 0.3.3 batch adopted Shared Tooling 0.2.6
`ce13a5314916891fd239d9b199b4a91b04775054` with 91 selected files. Standard
release and formatting recipes moved to their shared owners, preserving local
release policy and adapters. Its [preparation record](../evidence/adoption-033.md)
retains focused hook/release checks and the earlier newline-root qualifier failure.
That helper limitation is corrected in released 0.3.4 above.

The released private graph selects Host 0.9.4. Its
[separate review](../evidence/host-dependencies-094.md) binds unchanged upstream
library source, package hashes, inspector Clippy, named/CLI tests and Rust 1.88.
No arithmetic API, attribution or endpoint contract changes. The original
installer/hook acceptance is complete above; later Make companion and failure
boundaries remain in [#44](https://github.com/dragginzgame/ic-metrics/issues/44).

## Released 0.3.2 maintenance

Published 0.3.2 matches source/tag `f903c664c395c47485dbedc0f1919c97b9ce72d0`.
[Its verification](../evidence/release-032.md) binds the dependency-free registry
archive, unchanged arithmetic, passing Linux/MSRV jobs and downloaded Linux
receipts, including actual CLI admission coverage. Both macOS jobs remain queued.

The compatible 0.3.2 batch's unchanged 89-file selection adopts
reviewed Shared Tooling `ac4549c5ebde497f7db0da5d05d32835112e51de`, clarifying
optional installer-fixture companions and CI queue/duplicate-run diagnosis.
The optional all-installer suite remains unselected; this snapshot refresh leaves
production helper bytes, installer Make/CI callers and tool pins unchanged.
[The adoption record](../evidence/adoption-032.md)
binds the canonical refresh and focused snapshot/pin/offline checks.

The batch also includes the independently prepared Host 0.9.2 lock selection.
[Its review](../evidence/host-dependencies-092.md) verifies package/source hashes,
unchanged library source, inspector Clippy and named tests, actual Rust 1.88 and
byte-identical frozen reports. The core remains dependency-free. No arithmetic
API or data contract changes; package/workspace versions remained 0.3.1 during
preparation. No commit, release, publication or cleanup ran during preparation.

The inspector's focused gate now executes an actual CLI admission/publication
test alongside its existing argument/report tests. Accepted bytes produce the
matching digest and report; oversized, malformed, missing and directory inputs
fail with empty stdout and leave inputs intact. Linux formatting, warning-denied
all-target Clippy, the named tests and actual Rust 1.88 check/execution pass.
[The CLI record](../evidence/inspector-cli-032.md) retains commands, initial lint
failure and source/lock identities. Configured native CI inherits the test through
the existing gate; this local result does not establish macOS acceptance.
Production arithmetic/inspector source and CLI contracts are unchanged.

## Released 0.3.1 installer fixes

Released 0.3.1's unchanged 89-file selection adopts
reviewed Shared Tooling `ee48bb37c98c771e77b92fd891f0757d8c1c8b99`: IC setup/check
consumes a final pin row without a newline, and CI tools publish to the exact
destination without redirecting through a late directory or symlink. The
existing yq caller keeps its version/checksum; Perl admission precedes setup.
[The focused record](../evidence/adoption-031.md) binds passing Bash 5/3.2 fixtures,
snapshot/pin checks and actual offline IC admission. Arithmetic source, Cargo
selection and IC pins were unchanged during that preparation. Published 0.3.1
now verifies with Linux/native and both package floors passing;
[the release record](../evidence/release-031.md) retains the exact source and limits.
The later downloaded Linux artifact verifies its GitHub ZIP digest, inner archive,
14 payload hashes, 65 release-source hashes and nine successful setup/native
outcomes. Both macOS jobs remain queued.
[#42](https://github.com/dragginzgame/ic-metrics/issues/42) owns
exact-source native acceptance of the changed installer callers.

## Released 0.3.0 tooling hard cut

Released 0.3.0's 89-file snapshot adopts committed Shared
Tooling `8140e3dd1b44409d682c721889ab702f438c6a17`, transferring PocketIC ownership
to IC Testkit and requiring exactly five common IC tools. Existing six-tool
bundles fail the new offline check; explicit `make install-ic-tools` activates
the reviewed replacement. The real Linux setup/check and reuse pass, with all
old receipt-covered bytes, pins and receipts unchanged. Bash 5/3.2 installer,
common Make and evidence-collector fixtures pass.

Metrics has no active server path, equality check, setup or runtime harness.
The retired PocketIC checkers/fixture were never selected here; no Testkit
dependency or new installer is needed. Arithmetic APIs and persisted consumer
data are unchanged. No functions, methods or types are removed; the canonical
installer loses only its PocketIC-specific branches and matrix rows.
[The preparation record](../evidence/adoption-030.md) preserves proof scope and
historical replay constraints. [#41](https://github.com/dragginzgame/ic-metrics/issues/41)
tracks delivered-source native acceptance. Published source and Linux/MSRV
receipts now verify; both consumer macOS lanes remain queued. Package/workspace
versions are 0.3.0.
The initial tooling checks preserved the independent Host 0.8.10 lock edit.
Subsequent concurrent edits now select Host 0.9 in both requirements and lock;
the focused inspector checks below use that selection without changing it.
The original tooling evidence retains its initial dependency identity. No
commit or release runs here.

## Release admission fixture repair

The maintainer's CI failure at source
`e1363524f5be6b4c47b9a49e21230d969aef5e1f` came from the real offline-cache
fixture copying pending 0.3.0 notes while requesting a 0.2.21 patch candidate.
The release guard correctly rejected the mismatch before Cargo dispatch. The
fixture now owns its notes while retaining the exact committed manifests,
workspace sources and lock graph. Both real offline-policy cases verify Cargo's
failure status and unchanged manifest, lock, notes and index. Production
candidate admission remains unchanged; the fix ships in 0.3.0.

`make release-tools-check`, the admission fixture under genuine Bash 3.2.57,
ShellCheck and maintained documentation links pass on Linux. Logs and checked
source hashes remain under `target/evidence/release-admission-030/`; the original
CI log and `/tmp/metrics-release-admission.qEG6SX` failure are retained. These are
focused fixtures with the declared Git/Cargo/Make substitutions, not a rerun of
full CI or release execution. No package version or dependency changes.

## Private inspector ownership cleanup

The argument and report modules now share the executable-owned `Error`, removing
their dependency cycle. `report::Error`, its `fmt::Display::fmt` implementation
and its `std::error::Error::source` implementation move from
`crates/ic-metrics-wasm-inspect/src/report/mod.rs` to the binary root in
`crates/ic-metrics-wasm-inspect/src/main.rs`. No function, method or type is deleted;
no arithmetic API, CLI diagnostic, failure status or report format changes.

After `make fmt`, selected warning-denied host Clippy, the two argument tests,
three report tests and actual Rust 1.88 all-target checks pass on Linux with the
existing locked Host 0.9 graph. Actual binary help and missing-argument checks
preserve their output/status, and fresh reports for all three checksum-verified
frozen replay Wasms match the original TSVs byte-for-byte. Logs and checked
source/binary hashes remain under `target/evidence/inspector-cleanup-030/`.
This is focused worktree qualification, not a full CI gate or native release
acceptance. The arithmetic and release recovery code were reviewed without
finding another justified deletion.

## Released 0.2.20 checker fix

Released 0.2.20's unchanged 89-file selection adopts
committed Shared Tooling `926a20606591214ab29faa236b0b584e4857439e` through its
canonical distribution helper. Its dependency checker rejects exception catalogs
containing multiple JSON documents, so admission and suppression use one validated
array. Valid catalogs retain their contract. No dependency or public arithmetic
API changes. [The focused record](../evidence/adoption-0220.md) binds passing
Bash 5/3.2 fixtures, snapshot/pin checks and ShellCheck. Package/workspace versions
are 0.2.20. No newer committed Shared Tooling or Host revision is available at
inspection. This verification adds no implementation batch or pending changelog.

## Released 0.2.19 tooling fixes

Released 0.2.19 standard release entrypoints prepare the
selected locked workspace cache before offline validation, preserving explicit
Cargo offline settings, source/candidate admission and exact-version recovery.
Standalone preflight remains offline. The internal preparation selection is
consumed before helper/Cargo dispatch and removed from validation children.

Its released 89-file snapshot adopts reviewed Shared Tooling
`dc4fdf0f78928d75b69bbf43b37c690c53a04d1e` (0.1.37). It supplies explicit selected
Cargo binary/example setup with single-document receipts and original failure
statuses, plus checkout-local tool lookup for isolated staged formatting. No
additional tool package or profile is selected by this repository.
[The focused record](../evidence/adoption-0219.md) separates the initial 0.1.35
cache/refusal checks from the later 0.1.37 installer/hook qualification, including
actual formatting without a checkout-local caller PATH export.
[#40](https://github.com/dragginzgame/ic-metrics/issues/40) is delivered and retains
completed changed-caller native acceptance. All three native hosts and MSRV now
pass on the exact released source, with downloaded source/payload hashes, run/host
identity and changed release fixtures verified in the release record. The final
Intel receipt completes #40; no local gate or older source replaces that result.
The pre-existing Host 0.8.9 lock selection is preserved and now has its own
[focused qualification](../evidence/host-dependencies-089.md): package/source
identity, warning-denied inspector checks, actual Rust 1.88 and unchanged frozen
Wasm reports pass on Linux. Host library source is unchanged from 0.8.8. Neither
these checks nor upstream CI replace exact committed consumer native acceptance.

## Released 0.2.18 tooling cleanup

Released 0.2.18 retires optional fleet copies from this
consumer, while the arithmetic, setup/check and local workspace LOC contracts
remain intact. The 89-file snapshot adopts reviewed Shared Tooling
`3d33cd250fcae7dbe5cabe44b2abd6b2c91a1822` from a clean committed clone. Its IC
installer reuses equivalent pin catalogs without downloads or receipt rewriting.
The owned CI groups preserve every pushed source's running/queued qualification
and cancel only superseded PR runs.

Focused local tool fixtures pass under Bash 5 and genuine Bash 3.2, along with
snapshot/pin checks, local LOC, ShellCheck, actionlint and documentation links.
[The selection record](../evidence/adoption-0218.md) retains the removed-symbol
inventory and scoped evidence. [#38](https://github.com/dragginzgame/ic-metrics/issues/38)
awaits exact committed native qualification of these changed consumer callers.
Shared Tooling's selected upstream CI now passes all three native hosts and
lint/security; upstream CI does not replace consumer qualification.

Workspace/package versions are 0.2.18. Its committed private Host 0.8.8 graph
passes an [independent focused review](../evidence/host-dependencies-088.md):
warning-denied Linux host checks, named tests, actual Rust 1.88 and byte-identical
reports for the three frozen Wasms. New Host streaming hashing does not replace
the bytes required for Wasm inspection; existing read/report behavior is retained.
No new code batch or pending changelog is needed for this verification.

## Released source

Latest finalized and published source is 0.3.2
`f903c664c395c47485dbedc0f1919c97b9ce72d0`, matching tag `v0.3.2` and
workspace/package versions. The release record above verifies Linux/MSRV and
Linux native receipts; both macOS jobs remain queued. No further implementation
batch or pending changelog is created by release verification.

Earlier finalized and published source is 0.3.1
`2383dc0d684800b1610e3eb727449b0a87d562bb`, matching tag `v0.3.1` and
workspace/package versions. [Its verification](../evidence/release-031.md) binds
the dependency-free archive, unchanged arithmetic source and passing Linux/native
and both package floors. Both macOS jobs remain queued, so #42 stays open.
The independently qualified Host 0.9.2 lock selection ships in 0.3.2.

Earlier finalized and published source is 0.3.0
`070c768de881a6e966b93651e242e16e4f9f1111`, matching tag `v0.3.0` and
workspace/package versions. [Its verification](../evidence/release-030.md) binds
the dependency-free registry archive, unchanged arithmetic source and passing
Linux/native and both package floors. The Linux artifact verifies payload,
selected source, run/host and all nine outcomes. Both macOS lanes remain queued,
so #41 stays open. The independent released private graph selects Host 0.9.1.
The earlier fleet cleanup now has complete three-host receipts at released
0.2.18, closing [#38](https://github.com/dragginzgame/ic-metrics/issues/38); see
[its supplemental verification](../evidence/release-0218.md#subsequent-native-completion).
#40 now has complete released-source native/MSRV acceptance at 0.2.19.

Earlier finalized and published source is 0.2.20
`97064b0806699b60b475879ea7530135f1b540c8`, matching tag `v0.2.20` and
workspace/package versions. [The release verification](../evidence/release-0220.md)
binds the official archive and unchanged arithmetic source. Both package floors
pass on [exact CI](https://github.com/dragginzgame/ic-metrics/actions/runs/37913368131);
Linux native passes with verified source/payload/outcome receipts; both macOS
native jobs remain queued at inspection. Earlier 0.2.19 Linux
receipts retain their [original identity](../evidence/release-0219.md).
Complete source-matching native receipts are still required for #40. No broad
local gate, dependency selection, package version change or release runs here.

The preceding published source is 0.2.17
`52be29e4bc2433b3d2912a0c09538be993dfb1b2`, matching tag `v0.2.17` and
workspace/package versions. [The release verification](../evidence/release-0217.md)
binds the official archive and source. Linux native and both package floors pass
on [exact CI](https://github.com/dragginzgame/ic-metrics/actions/runs/37900937307);
Apple Silicon now passes and Intel is running at reinspection. Complete native receipt
review remains separate from publication.

The released reporting APIs add checked finite-bound cumulative counts,
nearest-rank quantile ranges and exact scaled ratios without changing recording
state or attribution. [Their preparation](../evidence/reporting-0217.md) preserves
the focused Linux/MSRV evidence, and the
[sibling audit](../reports/audits/2026/10/09/measurement-needs/01/report.md) retains
the read-only caller review. Consumers still own instrumentation and formats.
[Testkit #40](https://github.com/dragginzgame/ic-testkit/issues/40#issuecomment-6076486649)
records its maintainer's choice of explicitly approximate f64 means, preserving
exact totals and sample counts as authoritative. Its local docs/integration
checks do not adopt Metrics or change formats; maintainer delivery is pending.

Previously fully verified source is 0.2.16
`d8276daa3ae8603a5b4e196d0bb5369de54c1216`, matching tag `v0.2.16`.
That release's workspace, packages and local lock versions are 0.2.16. The official index
reports a non-yanked, dependency-free package with Rust 1.85.0 and checksum
`44b447757f583aa5e5145e34bbd6d8b75004614d90ef33544252c9e496178155`.
The newly downloaded archive verifies that digest, embedded identity and maintained
package bytes. Its packaged lock excludes the private host graph.
[Exact CI](https://github.com/dragginzgame/ic-metrics/actions/runs/37822463635)
passes Linux, Intel and Apple Silicon native and both package MSRV checks.
Downloaded evidence from all three native hosts verifies source, payload, archive
and all nine successful outcomes, with IC Host 0.8.4 and PocketIC 16.1.0.
[The release record](../evidence/release-0216.md) completes
[#37](https://github.com/dragginzgame/ic-metrics/issues/37).
Its Shared Tooling and Host selected upstream matrices also pass all native
hosts. These receipts retain their original scope and do not qualify 0.2.17 or
the current tooling cleanup. The separate
[Host 0.8.5 review](../evidence/host-dependencies-085.md) preserves that graph's
focused checks and byte-identical frozen-Wasm reports before its 0.2.17 delivery.

Previously verified 0.2.15 source is
`287251eb51412852a58cabd9de5b3c28e207e705`.
[Its release record](../evidence/release-0215.md) completes
[#34](https://github.com/dragginzgame/ic-metrics/issues/34) and
[#36](https://github.com/dragginzgame/ic-metrics/issues/36).

Previously fully verified 0.2.14 source is
`dee5ecdef3d811dcda930ddcaae48abf08acc951`.
[Its release record](../evidence/release-0214.md) binds the complete native matrix
and downloaded receipts, completing
[#33](https://github.com/dragginzgame/ic-metrics/issues/33). Those results do not
qualify the newer host graph or pending Shared Tooling adoption.

Previously fully verified published 0.2.13 source is `4091366bcd97ddf4f31d5993c954f6f4a269bc63`.
Its non-yanked registry archive has SHA-256
`cf9bf6109539e8b956857f444a1d365b0205250405980c10bfdd905831f66fe3`,
with no dependencies or features. The checksum, embedded Git identity, maintained
Rust source, packaged guide, original manifest, README, license and lock verify.
The [release record](../evidence/release-0213.md) binds passing Linux, Apple Silicon,
Intel and MSRV. All three downloaded native archives verify source, payload and
outcome receipts, completing consumer collector/distribution acceptance in
[#30](https://github.com/dragginzgame/ic-metrics/issues/30) and
[#32](https://github.com/dragginzgame/ic-metrics/issues/32).
[#31](https://github.com/dragginzgame/ic-metrics/issues/31) is now complete:
corrected upstream `db039347` passes its entire native matrix, with all 19
tracking cases and both evidence verifiers executed on each host. This consumer's
original matrix remains bound to 0.2.13. The
[0.2.12 record](../evidence/release-0212.md) retains its Linux/MSRV pass and
cancelled macOS lanes without rebinding those results to the newer source.
The [0.2.11 record](../evidence/release-0211.md) retains its complete three-host
matrix and verified receipts, finishing [#28](https://github.com/dragginzgame/ic-metrics/issues/28).
Earlier complete matrices retain their own scope in
[the 0.2.10 record](../evidence/release-0210.md) and historical records.

Histograms are available from 0.2.4; checked means are available from 0.2.6.
`checked_mean(samples, total)` and `MeasurementSummary::mean()` return `None`
for empty `(0, 0)`, `Some(0)` for measured zero and floor division for valid
nonempty aggregates. Inconsistent empty pairs and either counter at `u64::MAX`
return typed errors, including an exactly reached cap. Recording, storage and
ownership contracts are unchanged. The
[application guide](../../crates/ic-metrics/src/application.md) is packaged and
compiled; [arithmetic evidence](../evidence/arithmetic-026.md) retains its original
source, host/Wasm, MSRV and documentation scope.

The [histogram experiment](../evidence/histogram-cost-026.md) measures an isolated
Canic recording source-copy on Linux PocketIC 16.0.0, with 138 validated calls.
At 1,000 repeated-key records, two histogram bounds add 42,000–75,000
instructions, 42,035–75,035 observed whole-update cycles and 208 raw Wasm bytes
over count/total; slots use 72 versus 16 bytes. This does not qualify a full
consumer, other bound counts/cardinalities, timer admission, mainnet or macOS.
The original ignored replay inputs are unavailable and the maintainer has no
backup. The historical report and identities remain unchanged. A separate
[durable arithmetic replay](../evidence/histogram-replay-029.md) supplies new,
checksum-bound source/lock/result/Wasm inputs; it does not reproduce the old
Canic experiment or extend its qualification.

Released 0.2.9 includes the canonical path/date repairs and source-first native
CI evidence collection. Their preparation and controlled failure checks remain
in [the adoption record](../evidence/adoption-029.md), with committed native
qualification in [the release record](../evidence/release-029.md).
The public frozen histogram bundle matches its checksum and all payload hashes;
[#26](https://github.com/dragginzgame/ic-metrics/issues/26) is complete. Its
138 measured/six admission replies, rebuilt identical Wasms and repeat replay
remain bound to the separate direct-arithmetic experiment. Missing historical
Canic inputs are not recovered or relabelled.

## Released 0.2.10 tooling

The released contribution/release-tooling batch adopts committed Shared Tooling
0.1.22 at `2687f26317952c43c685f7f799ed09288dc10a67` through the canonical
helper from a clean detached checkout. The 70-file snapshot explicitly adds
the contribution rules and PR release helper and refreshes linked guidance. Local AGENTS.md and
README now allow an explicitly requested PR to include scoped commits and a
topic-branch push. Ordinary continuation remains local work; merges, direct
integration-branch pushes and releases retain separate explicit authority.
Required protections/checks are preserved. The
[adoption review](../evidence/adoption-0210.md) binds interpretation and focused
checks. The [release-tooling review](../evidence/adoption-0210-shared022.md)
binds the subsequent runner refresh and direct-only delivery guard. Unsupported
PR delivery fails before release dispatch or metadata effects. Ordinary PR
contributions remain supported. Arithmetic, pins, package versions and locks are
unchanged by adoption. Its source-matching native matrix and downloaded receipts
now qualify the owning fixtures at 0.2.10; live interrupted GitHub release effects
remain distinct from command substitutes.

## Released 0.2.11 tooling

This compatible batch adopts committed Shared Tooling 0.1.23
`0ba0ad00ed94848e54ecc82629b6b7873b7284c0` through the canonical helper from a
clean detached checkout. The 70-file selection stays explicit and direct-only
delivery remains supported. After final consumer hooks, the runner rechecks the
index, committed payload and exact annotated tag. Completed direct recovery
confirms local/remote tag identity and branch ancestry before reporting success;
conflicts or unavailable observations stop without repeating effects.
[The adoption record](../evidence/adoption-0211.md) binds passing focused
Linux Bash 5/3.2 fixtures and static checks. Upstream 0.1.23 has passed all native
hosts; the release record above binds this consumer's complete source-matching
native matrix. Arithmetic, consumer ownership and dependency selection
are unchanged by the release-tooling adoption.

## Released 0.2.12 tooling

The compatible released 0.2.12 batch adopts committed Shared Tooling 0.1.25
`672ab4b8af50c75ed21a359ca5968682de83be94` through the canonical exporter
from a clean detached checkout. The verified snapshot explicitly adds the
archiver and its fixture for 72 selected files. The runner prepares a Git ref
transaction and checks its type under the update lock before refreshing a
matching tracking ref. Symbolic replacements, including unchanged resolved OIDs,
and inspection failures preserve the observation without replaying delivery.
Direct-only release selection remains unchanged. Tooling LOC now includes `bin/`
and distinguishes unborn repositories from corrupt Git state; snapshot expansion
checks declared companions before replacing files.

The native collector reuses the helper for failed tool candidates. Its outer tar
archive deliberately retains Git intent/index evidence from release fixtures;
the shared helper excludes that metadata. Source receipts include the two new
files. Focused fixtures cover literal names, modes, links, candidate Git exclusion,
outer recovery-state retention, partial writes and occupied archive refusal.
[#31](https://github.com/dragginzgame/ic-metrics/issues/31) and
[#30](https://github.com/dragginzgame/ic-metrics/issues/30) retain committed
consumer native/download acceptance. Preparation evidence is in
[the adoption record](../evidence/adoption-0212.md).

The earlier same-OID race remains bound to uncorrected `eeb72e7` and retained
under `target/evidence/shared025-review/`; successful dirty-patch previews stay
under `target/evidence/shared025-tracking-preview/`. The earlier archive-only
native pass does not qualify the corrected runner. Matching upstream
[run 37767868576](https://github.com/dragginzgame/shared-tooling/actions/runs/37767868576)
was queued at initial preparation. This local batch does not establish native
consumer qualification or live interrupted release execution. Arithmetic,
package/workspace/lock version 0.2.12 and dependency pins remain unchanged by
post-publication inspection.
Focused release-tooling, native archive/setup and LOC fixtures pass under Linux
Bash 5.2 and 3.2.57. ShellCheck, actionlint, documentation, pins, snapshot and
formatting checks pass; finalized changelog history is preserved byte-for-byte.
The original corrected-upstream run was later cancelled as a newer snapshot
landed; its Linux pass does not supply missing macOS evidence. The subsequent
0.1.26 source preserves identical runner bytes and now passes Linux, Apple Silicon
and lint, with Intel queued at inspection. Consumer qualification remains bound
to the exact 0.2.12 source in the release record.

## Released 0.2.13 tooling

The released 0.2.13 72-file snapshot selects committed Shared Tooling 0.1.26
`75a8a60f49cec11d3f6aecab5c977029c42cc549`, refreshed canonically from a clean
detached checkout. Its exporter can advance a verified unchanged uncommitted
snapshot using the previous manifest and exact committed source. It refuses
consumer edits, unavailable prior provenance, staged conflicts and changed
file/manifest identities. There is no force flag or implicit fetch; multi-file
publication still requires selected-path editing/validation to stop.
[The preparation record](../evidence/adoption-0213.md) binds source review and
focused checks. The runner, archiver and baseline are unchanged. The maintainer
finalized the compatible 0.2.13 release; Cargo/package/lock are now 0.2.13.
Upstream native CI and exact consumer qualification remain separate from this
local refresh; the sibling's dirty release-fixture follow-up is not adopted.
[#32](https://github.com/dragginzgame/ic-metrics/issues/32) owns this new
distribution qualification separately from the released runner/collector batch.
Focused distribution fixtures pass under Bash 5.2 and 3.2.57, and repeat refresh
verifies all 72 files. Static, documentation, pins and formatting checks pass.
The upstream Intel job subsequently passed snapshot distribution and the full
portable suite, then hit its 15-minute step deadline. Later native gates were
skipped. [Shared Tooling #71](https://github.com/dragginzgame/shared-tooling/issues/71)
owns that workflow-budget repair; no dirty upstream source is adopted.

## Released 0.2.14 tooling

The released 75-file snapshot selects committed Shared Tooling 0.1.27
`b866d41041a1986eeec95bde9af4c6ba0853d2e3`, refreshed from a clean reviewed
checkout through the canonical exporter. The three explicit additions are the
tool-evidence selector, installer evidence fixture and composite action that
fixture reads. The action is used by installer tests; the native workflow keeps
its own collector and Git recovery-state policy. Its source receipts now include
these new fixture inputs. Upstream's missing companion declarations remain in
[Shared Tooling #73](https://github.com/dragginzgame/shared-tooling/issues/73).

The local release adapter and fixture entry points now anchor physical paths
without consuming CDPATH output or trimming trailing newlines. A read-only
version request reproduced exit 127 before the correction; metadata fixtures
exercise both relative and absolute entry points in a newline-ending checkout.
The reviewed LOC reporter recognizes dotted snapshot names. The maintainer
finalized 0.2.14; package/lock versions are 0.2.14. Arithmetic,
dependency/tool pins and consumer attribution/storage contracts are unchanged.
[The adoption record](../evidence/adoption-0214.md) binds focused evidence;
[#33](https://github.com/dragginzgame/ic-metrics/issues/33) owns committed native
acceptance. Upstream's exact 0.1.27 Linux workflow fails its compact-evidence
verifier's stale log comparison; the prepared sibling correction in
[#66](https://github.com/dragginzgame/shared-tooling/issues/66) is not adopted.

## Released 0.2.15 tooling preparation history

The following preparation observations retain their original source identities.
The maintainer subsequently released 0.2.15 with Shared Tooling 0.1.28 and locked
IC Host 0.8.2. Current publication and qualification are recorded above; earlier
statements about pending versions, the public remote and dirty upstream work
describe preparation at that time.

The earlier 75-file preparation selected reviewed committed Shared Tooling
`db039347d2372b877c1c46dcdd2b5c3aa9412009`, still version 0.1.27, through the
canonical exporter from a clean detached checkout. Relative consumer and IC pin
operands now resolve physically without CDPATH output or trimmed directory bytes.
The installer fixtures declare their evidence companions; the existing explicit
selection is complete, so no selected path is added or removed. The baseline,
release runner, pin selections and consumer native collector remain unchanged.

The compatible pending changelog is 0.2.15; package/lock versions stay 0.2.14.
[The adoption record](../evidence/adoption-0215.md) binds focused checks;
installer and native-evidence fixtures pass on Linux Bash 5.2 and 3.2.57, as do
offline tool, snapshot/pin, formatting, shell/workflow and documentation checks.
Incomplete fixture exports refuse before creating consumer files; repeat refresh
verifies all 75 digests and modes.
[#34](https://github.com/dragginzgame/ic-metrics/issues/34) owns this batch's
future committed native acceptance separately from #33. The corrected upstream
[workflow](https://github.com/dragginzgame/shared-tooling/actions/runs/37787910279)
now passes Linux, Intel and Apple Silicon, including full/compact evidence
verification. This newer outcome completes #31's remaining upstream requirement.
Its workflow is not imported into the consumer.

The same compatible draft lowers the library MSRV from Rust 1.88 to 1.85.
Workspace inheritance, the Make default and CI minimum compiler agree; edition
2024 and the Rust 1.99 development toolchain remain unchanged. Actual Linux
Rust 1.85 native/Wasm checks, six selected unit tests, three public doctests and
warning-denied Wasm documentation pass. Development host/Wasm Clippy passes.
[The qualification record](../evidence/msrv-0215.md) binds compiler identity,
commands and unchanged arithmetic/lock bytes for
[#35](https://github.com/dragginzgame/ic-metrics/issues/35). This is local minimum
compiler qualification; committed hosted qualification of the complete pending
batch remains separate. Published 0.2.14 still declares Rust 1.88.

The same compatible draft adds the private `ic-metrics-wasm-inspect` host binary,
using registry IC Host 0.8.1 packages with explicit input budgets and digest-bound
TSV facts. Arithmetic remains dependency-free and `no_std`, with default Cargo
commands selecting that package. The host floor is Rust 1.88; the release adapter
advances both inherited local lock versions while retaining registry selections.
[The inspection record](../evidence/wasm-inspection-0215.md) binds local focused
checks and new structural facts about the unchanged historical replay Wasms.
[#36](https://github.com/dragginzgame/ic-metrics/issues/36) retains future committed
native acceptance. No downstream arithmetic contract changes require caller edits.

The maintainer's later release validation exposed an incomplete admission fixture:
its initial version probe copied only the root manifest after HEAD acquired a
second workspace member. The same root-only export could break late selected-commit
checks. Both paths now export the selected commit's crate tree with its metadata
before Cargo validates the workspace; they do not resolve a newer HEAD graph.
[The regression record](../evidence/release-admission-0215.md) binds the reproduced
failure and passing focused release-tool checks, including Bash 3.2 producer-failure
and retention coverage. The original release failure logs remain intact. Full
release validation, package versions and unrelated dirty lock changes are preserved.

The issue-repair continuation now adopts committed Shared Tooling 0.1.28
`1872ed2c20f6c70689bb2249050b1d673c60bfa0` through the canonical exporter from a
clean detached source. Its 90-file selection fixes the active-link byte defect in
[Shared Tooling #75](https://github.com/dragginzgame/shared-tooling/issues/75),
splits release simulation/tracking fixtures while keeping both in the consumer
gate, documents separate package MSRVs and includes the maintenance catalog and
inactive coordinator. The preceding db039 preparation and its original evidence
remain historical; [the new adoption record](../evidence/adoption-0215-028.md)
binds this source and focused checks separately. #34 retains future exact committed
consumer acceptance; #36 still owns the inspector's native qualification. The
public remote remains released 0.2.14, so local commits have no matching CI yet.
Newer uncommitted upstream policy/dashboard/release-source work is excluded.
No sibling files, schedules, commits or release effects are changed by preparation.

## Released 0.2.16 tooling preparation history

The following observations describe preparation before the maintainer's release.
Current publication and complete native acceptance are recorded above; the
preparation records preserve the original local commands and pending observations.

The canonical 91-file snapshot now selects reviewed committed Shared Tooling
`4e274a2219c0b0cc3af68ec65658b373253518fb`: 0.1.29 rules and the subsequent
committed Cargo-assessment documentation. The consumer release adapter
uses its canonical source checker with the same three metadata allowances,
reporting all blockers before preparation. Native source receipts include the new
source checker.
Snapshot-owned PocketIC pins advance to 16.1.0. Cargo manifests and arithmetic
source remain unchanged; existing IC executable installations are not requalified
or silently replaced.

The maintainer's current lock also selects published IC Host 0.8.4 for the private
inspector, advancing only its two direct host packages from released 0.8.2.
[The dependency review](../evidence/host-dependencies-0216.md) binds checksum/source
verification, Linux checks, Rust 1.88 host and Rust 1.85 core host/Wasm qualification,
and actual reports matching the original frozen Wasm TSVs byte-for-byte. The
new lock bytes are preserved. No new lock/process API is needed by this inspector.
The upstream 0.8.4 Linux/MSRV jobs pass; both native macOS lanes remain queued at
review. #37's future exact consumer matrix must qualify this newer graph together
with the tooling batch; released 0.2.15 receipts retain IC Host 0.8.2.

The pending changelog is 0.2.16 because this complete batch adds compatible
maintained tooling without changing the arithmetic or consumer contracts.
[The adoption record](../evidence/adoption-0216.md) binds focused Linux Bash 5.2
and genuine Bash 3.2 checks, source/index preservation, snapshots/pins and lint.
[#37](https://github.com/dragginzgame/ic-metrics/issues/37) retains future exact
committed native acceptance. The new upstream assessment workflow/script are
not selected; uncommitted upstream version preparation is excluded.
No package version change, release, commit, sibling edit or schedule
is part of this continuation.

## Downstream boundaries

The 2026-10-08 read-only inspection binds these local sources and selected locks.
Newer dirty work and remote publication require independent inspection; all
selected Metrics locks below refer to the registry package.

| Caller | Inspected local HEAD | Committed Metrics lock and inspected working-tree selection |
| --- | --- | --- |
| IcyDB | `4d137f6078146574ad76ae28fbef1250608ffc61` | Public 0.267.2 commits Metrics 0.2.12. Inclusive spans and CLI checked means; current native acceptance remains incomplete. |
| Canic | `4c51a87c6a32397196bb3f65d064641194df10a5` | Public 0.110.53 commits Metrics 0.2.9; subsequent dirty work remains separate. Exclusive endpoint accounting and invocation-owned async checkpoints. |
| IC Timers | `7d3ef40c50e49b79a8e9e10fb7cb68cee244eb7b` | Committed Metrics lock 0.2.10. Scheduler/work summaries and local sample admission. The local commit advanced during inspection; earlier reads selected 0.2.9. |
| IC Backup | `8a1152d0a510f34f8daed59f06632306f7cf134e` | Committed 0.2.9; dirty selection 0.2.10. Nanosecond summaries and four-bound prepared-byte histogram. |
| IC Blob Storage | `704b8ebf6bea85a715e465e32e34758b601852ec` | Committed/clean Metrics lock 0.2.9. Restoration test probe, not production library instrumentation. |
| Toko Miner | `aeed004b03b9b5d848de3750d77a42c5160c5fdf` | Committed/working Metrics lock 0.2.9; other lock edits remain separate. Production action-count cohorts use `record_sample`. |

The earlier 2026-10-08 recheck found IcyDB public 0.267.1 source
`cb8cefca1d68c20025398eae6dfab18a2eb45883`, selecting Metrics 0.2.8. Its
[CI](https://github.com/dragginzgame/icydb/actions/runs/37653174383) passes
Rust/MSRV/static but both native macOS jobs fail the retained release-lock lookup.
The later public 0.267.2 source `4d137f6078146574ad76ae28fbef1250608ffc61`
now commits Metrics 0.2.12 and the explicit TMPDIR-rooted snapshot template.
Its [exact CI](https://github.com/dragginzgame/icydb/actions/runs/37779266779)
passes static/MSRV/Wasm-size; its completed native macOS jobs now fail tool setup.
All four Rust lanes stop during tool setup: the offline PocketIC policy check
needs the locked workspace cache, but the explicit fetch runs afterward.
The actual Apple Silicon setup log likewise rejects uncached `candid` before
Metrics checks, through `install-dev`'s offline PocketIC alignment policy.
The owning setup-order correction is reported in
[IcyDB #302](https://github.com/dragginzgame/icydb/issues/302); matching native
helper acceptance remains in [#309](https://github.com/dragginzgame/icydb/issues/309).
The latest owning #302 comment records a local retirement of the extra product
PocketIC equality gate in favor of IC Testkit admission. Its focused checks pass,
but the owner explicitly retains the same failed public CI and a separate Testkit
startup restriction; that dirty correction does not complete #298's native proof.
The successful
scheduled SQL evidence workflow is a separate gate, not Metrics native closure.
Canic's newer source is now public as 0.110.53
`4c51a87c6a32397196bb3f65d064641194df10a5`. Its
[exact CI](https://github.com/dragginzgame/canic/actions/runs/37752054026) passes
all eight Core perf host cases and facade/report projections. Both macOS gates
stop at worker fixtures calling `rg` before pinned host-tool installation.
PocketIC refuses a stale embedded allocation peer before test startup, so the
actual held-HTTP metrics interleaving case does not execute. The ordinary lane
also rejects a finalized changelog without a pending draft. Owning corrections
remain in [Canic #450](https://github.com/dragginzgame/canic/issues/450);
passing host cases do not close the missing native/IC acceptance.
The later Canic Dependabot PR [CI 37784481281](https://github.com/dragginzgame/canic/actions/runs/37784481281)
selects source `b90cd3fc501aff682e32bbc685c4a91c932ff821` and registry Metrics
0.2.12. Its preflight rejects duplicate `ic-certification` in the deployed
`delegation_root_stub` and `canister_user_shard` closures; the retained lock has
3.2.0 and 4.0.0. All later native/MSRV/ordinary/PocketIC lanes are skipped.
[Canic #448](https://github.com/dragginzgame/canic/issues/448) owns that gate;
this PR graph is not public main, and the older passing perf cases are not
qualification of this proposed graph.
Backup 0.6.0 and Blob
0.18.0 public main match the inspected commits; their later graph's native/runtime
outcomes were not requalified in this inventory. Toko has no matching hosted
run at inspection. Timers public main was `0b12c8a6dbe5f359f5499df67313ffa5c02af446`
at the remote read, before the newer local 0.14.14 commit was observed. Local
commits and active release validation are not completed native qualification.

Timers' arithmetic-only adoption is already qualified at 0.14.6 on all three
native hosts and MSRV. Its later 0.14.12 main CI passes Linux/MSRV/Apple Silicon
but lacks Intel execution because GitHub could not acquire a runner; tag truth
passes separately. Backup's selected metrics integration is qualified at 0.5.2.
These completed source-bound adoptions do not automatically qualify later graphs
or reopen merely because another release has unrelated outstanding work.

Blob 0.17.1's workflow also executes the actual restoration-metrics PocketIC
case, despite its tooling-oriented name. All three native logs confirm the
named case passes. The earlier tooling-only description was incorrect;
[the consumer review](../evidence/consumer-closeout-0210.md) binds the correction
to actual commands, source and downloaded logs. Its scope remains a test probe,
not production instrumentation. No sibling source, graph or validation is changed.

IcyDB's CLI output compatibility belongs to
[IcyDB #313](https://github.com/dragginzgame/icydb/issues/313); Canic's async
attribution remains in [Canic #99](https://github.com/dragginzgame/canic/issues/99).
Histogram workload, bounds and storage decisions belong to
[IcyDB #312](https://github.com/dragginzgame/icydb/issues/312),
[Canic #475](https://github.com/dragginzgame/canic/issues/475) and
[IC Backup #15](https://github.com/dragginzgame/ic-backup/issues/15).
[IC Timers #22](https://github.com/dragginzgame/ic-timers/issues/22) records the
summary-only decision without a demonstrated distribution workload. Toko's
cohorts count actions, not instruction-value ranges; Blob probe and Toko
application qualification belong to completed source-bound
[Blob #19](https://github.com/dragginzgame/ic-blob-storage/issues/19) and open
[Toko #6](https://github.com/dragginzgame/toko-miner/issues/6).

Remaining original extraction qualification is consolidated in
[#10](https://github.com/dragginzgame/ic-metrics/issues/10): IcyDB's adopting-source
focused/native acceptance and Canic's adopting-source actual interleaving/native
acceptance. [#4](https://github.com/dragginzgame/ic-metrics/issues/4) closes as a
duplicate tracker; its outstanding obligations remain in #10. Timers, Backup
and Blob retain their completed adoption scopes. Toko application follow-up
is separate from the original reader-cut closure criteria. Histogram
investigators now have the published mean API and checksum-bound public replay
feedback in their existing issues; no new instrumentation is requested.

The 2026-10-09 public-main recheck advances IcyDB to 0.267.3
`145250b8ca7ce36cda240d4ff8fa47f254527877`, selecting Metrics 0.2.15.
[Exact CI](https://github.com/dragginzgame/icydb/actions/runs/37820158590) now passes
core, workspace, tier-a, MSRV, Wasm-size and Apple Silicon host jobs. Static fails
SC2015 in the shared checker under apt-installed ShellCheck 0.9.0-1; the same
selected helper passes reviewed 0.11.0 here. Intel native is cancelled, and tier-b
observes a clean PocketIC exit after 60.609 seconds during pre-client compilation.
These findings are reported to existing IcyDB #309 and
[Testkit #37](https://github.com/dragginzgame/ic-testkit/issues/37), retaining
IcyDB's full acceptance in #298. That public lock selects Testkit 0.25.2; newer
local graph preparation is not substituted.

Canic's actual public main is release 0.110.54
`c4c046f947b2b28f4342cbf6efe9221ba1ed5f70`, selecting registry Metrics 0.2.12.
[Its push CI](https://github.com/dragginzgame/canic/actions/runs/37784109345)
passes security, preflight, checks, MSRV and release build. Downloaded ordinary
test logs confirm all eight Core perf host cases pass, but the lane fails because
the changelog guard demands a pending release on finalized source. Both macOS
jobs fail the test-worker failure/cancellation cleanup step; the serial PocketIC
step also fails. Individual downloads for those three jobs return empty logs at
review, so their precise causes and actual held-HTTP execution are not established
by this observation. Existing Canic #450, #447 and #99 retain the owning repair
and acceptance obligations. The previous description of the Dependabot PR as
latest main was incorrect; its duplicate-package refusal is separate evidence.

The subsequent public-main recheck advances IcyDB to 0.267.4
`15174ec06c5a97c61317c9e205db4c0e86636dd8`, selecting Metrics 0.2.18.
[Exact CI](https://github.com/dragginzgame/icydb/actions/runs/37910356751) passes
static, core, workspace, tier-a, MSRV and Wasm-size jobs. The static ShellCheck
repair is delivered. Both macOS lanes remain queued and tier-b fails; this review
does not establish that failure's precise cause. IcyDB #298/#309 retain their
remaining native/focused obligations, and Canic's public source is unchanged.

The subsequent public-main review advances IcyDB to released 0.268.0
`059564d9af22558ffb80ee384bd698357f65154b`, selecting registry Metrics 0.2.20.
[Exact CI](https://github.com/dragginzgame/icydb/actions/runs/37923831876) passes
static, core, workspace, tier-a, MSRV and Wasm-size jobs. Intel remains queued,
Apple Silicon is running and tier-b fails. Both run-level and completed-job log
requests are unavailable while the run remains unfinished, so the tier-b cause
is unverified. IcyDB #298/#309 and root #10 retain their owning qualification;
Canic's public source and missing held-HTTP/native obligations are unchanged.
Read-only inputs and observations are retained under
`target/evidence/adoption-033/continuation/icydb-02680/`. No sibling execution or
dependency update is performed.

PocketIC-specific provisioning ownership is coordinated in
[Shared #76](https://github.com/dragginzgame/shared-tooling/issues/76) and
[Testkit #38](https://github.com/dragginzgame/ic-testkit/issues/38). Published
Testkit 0.25.4 setup/check and managed launch pass all three native hosts in
[owner CI](https://github.com/dragginzgame/ic-testkit/actions/runs/37901828971).
Metrics' released 0.3.0 adoption selects the committed five-tool Shared revision
above. It has no active server/runtime harness and adds no simulator dependency
or private setup policy. Frozen replay inputs retain their historical server
identity; current Testkit defaults are not substituted into that experiment.

No sibling files were edited. Historical evidence stays under `docs/evidence/`;
[the host record](../hosts.md) separates focused Linux checks from native CI.
No full local CI/product-test gate, dependency upgrade, package version change,
commit, push, tag or release command ran.
