//! Frozen IC fixture protocol; no product endpoints or codec contract.
use candid::CandidType;
use serde::Deserialize;

#[derive(CandidType, Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct Snapshot {
    pub aggregate: Vec<u128>,
    pub summary: Vec<u128>,
    pub histogram: Vec<u128>,
    pub capped: Vec<u128>,
    pub bucket_cap: Vec<u128>,
    pub overflow_cap: Vec<u128>,
    pub zero: Vec<u128>,
    pub empty: Vec<u128>,
    pub missing: bool,
    pub memory_id: u8,
    pub build: u8,
}

#[derive(CandidType, Deserialize, Clone, Debug, PartialEq, Eq)]
pub enum ProbeError {
    Input,
    Missing,
    Identity,
    Bounds,
    Regression,
    Storage,
}

#[derive(CandidType, Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct Measured {
    pub before: u64,
    pub after: u64,
    pub samples: u64,
    pub total: u128,
}
