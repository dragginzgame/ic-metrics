//! One-off V1 decoder comparison; setup and mutation precede instruction reads.
use std::hint::black_box;
use ic_memory::ic_stable_structures::{BTreeMap, DefaultMemoryImpl};
use ic_metrics::{MeasurementAggregate as Aggregate, MeasurementCounter as Counter, MeasurementHistogram as Histogram, MeasurementSummary as Summary};
use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsStore, StoreError};

#[ic_cdk::update]
fn compare(_n: u16, case: u8, iterations: u32) -> (u64, u128) {
    assert!(case < 32 && iterations <= 1024);
    let names = ["counter", "aggregate", "summary", "histogram"];
    let keys = names.map(|name| MetricKey::new("app", name).unwrap());
    let identity = MetricIdentity::new("x", 3).unwrap();
    let counter = Counter::from_parts(1 << 80, false).unwrap();
    let mut aggregate = Aggregate::EMPTY;
    let mut summary = Summary::EMPTY;
    let mut histogram = Histogram::new([0, 4, 8, 16]).unwrap();
    for sample in [0, 9, 7] {
        aggregate.record(sample);
        summary.record(sample);
        histogram.record(sample);
    }
    let mut map = BTreeMap::<Vec<u8>, Vec<u8>, _>::init(DefaultMemoryImpl::default());
    for name in names { map.remove(&[b"app\0".as_slice(), name.as_bytes()].concat()); }
    let mut store = MetricsStore::new(map);
    store.save(&keys[0], &identity, &counter).unwrap();
    store.save(&keys[1], &identity, &aggregate).unwrap();
    store.save(&keys[2], &identity, &summary).unwrap();
    store.save(&keys[3], &identity, &histogram).unwrap();
    let kind = usize::from(case % 4);
    let raw_key = [b"app\0".as_slice(), names[kind].as_bytes()].concat();
    let mut map = store.into_map();
    let mut bytes = map.get(&raw_key).unwrap();
    match case / 4 {
        0 => {},
        1 => bytes.truncate(10), // Partial epoch.
        2 => bytes.truncate(20), // Partial first payload integer.
        3 => bytes.truncate(bytes.len() - 2),
        4 => bytes.truncate(49.min(bytes.len() - 1)), // Partial histogram length.
        5 => bytes.push(0),
        6 => bytes[6] = 0xff,
        7 => bytes[6] = b'y',
        _ => unreachable!(),
    }
    map.insert(raw_key, bytes);
    let store = MetricsStore::new(map);
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let result = match black_box(kind) {
            0 => store.load(black_box(&keys[0]), black_box(&identity), black_box(&counter)).map(|value| value.map(|m| m.total())),
            1 => store.load(black_box(&keys[1]), black_box(&identity), black_box(&aggregate)).map(|value| value.map(|m| m.total())),
            2 => store.load(black_box(&keys[2]), black_box(&identity), black_box(&summary)).map(|value| value.map(|m| m.aggregate().total())),
            3 => store.load(black_box(&keys[3]), black_box(&identity), black_box(&histogram)).map(|value| value.map(|m| m.aggregate().total())),
            _ => unreachable!(),
        };
        let value = match result {
            Ok(Some(total)) => total + 4,
            Ok(None) => 7,
            Err(StoreError::MalformedRecord) => 1,
            Err(StoreError::IdentityMismatch) => 2,
            error => panic!("unexpected decoder result: {error:?}"),
        };
        sink = sink.wrapping_add(black_box(value));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}
