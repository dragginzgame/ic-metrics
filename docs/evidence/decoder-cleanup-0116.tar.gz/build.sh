#!/usr/bin/env bash
set -euo pipefail
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${METRICS_TARGET_DIR:?Select the owning Metrics target directory}"
for variant in baseline candidate; do
    stable="$root/$variant-stable"
    rm -rf "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src"
    cp -R "$root/baseline-core/src" "$root/fixture/crates/ic-metrics/src"
    cp -R "$stable/src" "$root/fixture/crates/ic-metrics-stable/src"
    find "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src" -type f -exec touch {} +
    cargo build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$METRICS_TARGET_DIR" --locked --offline -p stable-probe --features unit --release --target wasm32-unknown-unknown
    cp "$METRICS_TARGET_DIR/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/$variant-decode.wasm"
done
cargo build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$METRICS_TARGET_DIR" --locked --offline -p stable-driver
