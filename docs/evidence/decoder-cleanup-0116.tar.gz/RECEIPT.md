# Frozen decoder comparison

Baseline source: 0efa8d8d7aadb2bcebbd929364a50d3c317924ca (v0.11.5).
baseline-core and baseline-stable copy its library sources. candidate-stable
changes only fixed-width cursor admission; the core is identical in both builds.
Root Cargo.toml/Cargo.lock are the unchanged product inputs. The separate
fixture retains the inherited 0.11.4 experiment labels and locked graph; those
labels are not a Metrics release selection or a claim of product-graph identity.

Workload: 32 cases, comprising four kinds by eight conditions. case % 4 selects
counter/aggregate/summary/four-bound histogram. case / 4 selects valid, partial
epoch, partial first payload integer, truncated tail, partial histogram length,
trailing byte, invalid UTF-8 unit or different valid identity. Native tests own
additional corruption/numeric-state and no-write proofs.

Each workload has 0/128 iterations and three repeats. The CSV retains real IC
instructions, whole-update cycle charges and observable projection sinks.
Matched instruction deltas repeat exactly across all three runs. Setup and reply
encoding are outside the instruction bracket; setup is inside cycle charges.

Replay rebuilt both raw Wasms byte-for-byte and ran 384 fresh updates. Every
projection and matched bracket instruction delta agrees with the original run.
Original results and replay-results are independently retained, with build logs.
No native timing or estimated cycles are used.

The prepared Linux x86_64 PocketIC 16.1.0 server has SHA-256
b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db.
Use replay.sh with the recorded compiler and server, an explicitly prepared
locked cache and the owning Metrics target directory. Fresh scratch survives
success/failure. No private sibling source, issue bodies or search excerpts are
included; copied library and one-off fixture files are frozen evidence, not a
new maintained harness or dependency.
