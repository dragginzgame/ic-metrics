#!/usr/bin/env bash
set -euo pipefail
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${METRICS_TARGET_DIR:?Select an absolute build directory under the owning Metrics target}"
: "${POCKET_IC_BIN:?Select the prepared PocketIC 16.1.0 Linux x86_64 executable}"
[[ "$METRICS_TARGET_DIR" == /* ]] || exit 1
[[ "$(rustc -V)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]] || exit 1
actual="$(shasum -a 256 "$POCKET_IC_BIN")"
[[ "${actual%% *}" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]] || exit 1
mkdir -p "$METRICS_TARGET_DIR"
scratch="$(mktemp -d "$METRICS_TARGET_DIR/admission-replay.XXXXXX")"
# Never build into or overwrite the frozen receipt. Retain failed replay inputs.
cp -R "$root/." "$scratch/"
bash "$scratch/build.sh"
for variant in baseline candidate; do
    for kernel in hist restore unit; do
        cmp "$root/$variant-$kernel.wasm" "$scratch/$variant-$kernel.wasm"
    done
done
"$METRICS_TARGET_DIR/debug/stable-driver" "$scratch" "$scratch/replay-results"
printf 'Byte-identical Wasm replay and matching projections completed: %s\n' "$scratch"
