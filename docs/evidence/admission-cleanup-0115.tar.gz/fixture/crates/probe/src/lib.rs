//! Frozen admission experiment. Setup and reply encoding are outside instruction brackets.
use std::hint::black_box;
use ic_metrics::MeasurementAggregate as Aggregate;
#[cfg(any(feature = "hist", feature = "restore"))]
use ic_metrics::MeasurementHistogram as Histogram;

#[cfg(feature = "hist")]
fn histogram(case: u8, iterations: u32) -> (u64, u128) {
    let mut h = Histogram::new([0, 10000, 100000, 1000000]).unwrap();
    if case < 7 { for sample in [0, 10000, 100000, 1000000, 1000001] { h.record(sample); } }
    if case == 8 || case == 9 {
        let aggregate = Aggregate::from_parts(u64::MAX, 0, Some(0), true, false).unwrap();
        h = Histogram::from_parts([0, 10000, 100000, 1000000], [u64::MAX, 0, 0, 0], 0, [true, false, false, false], false, aggregate).unwrap();
    }
    let (n, d) = match case {
        0 => (1, 2), 1 => (95, 100), 2 => (1, u64::MAX),
        3 => (u64::MAX, u64::MAX), 4 => (u64::MAX - 1, u64::MAX),
        5 => (u64::MAX / 5, u64::MAX), 6 => (u64::MAX / 5 + 1, u64::MAX),
        7 | 8 => (1, 2), _ => (0, 0),
    };
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let value = match black_box(&h).quantile_bucket(black_box(n), black_box(d)) {
            Ok(Some(range)) => u128::from(range.lower_exclusive().unwrap_or(0)) + u128::from(range.upper_inclusive().unwrap_or(0)) + 4,
            Ok(None) => 1,
            Err(ic_metrics::HistogramQueryError::InvalidQuantile) => 2,
            Err(ic_metrics::HistogramQueryError::CountOverflow) => 3,
            _ => panic!("unexpected histogram query error"),
        };
        sink = sink.wrapping_add(black_box(value));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}

#[cfg(feature = "restore")]
fn restoration<const N: usize>(case: u8, iterations: u32) -> (u64, u128) {
    let bounds = std::array::from_fn::<_, N, _>(|i| i as u64);
    let mut counts = [0; N];
    let mut flags = [false; N];
    let overflow;
    let aggregate;
    if case == 1 {
        if N == 0 { overflow = 1; } else { counts[0] = 1; overflow = 0; }
        aggregate = Aggregate::from_parts(1, 0, Some(0), false, false).unwrap();
    } else {
        overflow = 0;
        aggregate = Aggregate::EMPTY;
        if case == 3 && N != 0 { flags[N - 1] = true; }
    }
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let value = match Histogram::from_parts(black_box(bounds), black_box(counts), black_box(overflow), black_box(flags), black_box(case >= 2), black_box(aggregate)) {
            Ok(value) => u128::from(value.aggregate().samples()) + 1,
            Err(ic_metrics::MeasurementStateError::InvalidOverflowFlag) => 3,
            _ => panic!("unexpected restoration error"),
        };
        sink = sink.wrapping_add(black_box(value));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}

#[cfg(feature = "unit")]
fn units(case: u8, iterations: u32) -> (u64, u128) {
    use ic_memory::ic_stable_structures::{BTreeMap, DefaultMemoryImpl};
    use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsStore, StoreError};
    let unit = "x".repeat(if case == 1 || case == 8 { 64 } else if case == 4 || case == 5 { 2 } else { 1 });
    let identity = MetricIdentity::new(&unit, 3).unwrap();
    let key = MetricKey::new("app", "work").unwrap();
    let raw_key = b"app\0work".to_vec();
    let mut map = BTreeMap::<Vec<u8>, Vec<u8>, _>::init(DefaultMemoryImpl::default());
    map.remove(&raw_key);
    let mut store = MetricsStore::new(map);
    store.save(&key, &identity, &Aggregate::EMPTY).unwrap();
    let mut map = store.into_map();
    let mut bytes = map.get(&raw_key).unwrap();
    match case {
        2 => bytes[6] = b'y',
        3 | 5 => bytes[6] = 0xff,
        4 => bytes[6..8].copy_from_slice(&[0xc2, 0xa2]),
        6 => bytes[6] = b' ',
        7 => bytes[5] = 0,
        8 => { bytes.insert(6, b'x'); bytes[5] = 65; },
        _ => {},
    }
    map.insert(raw_key, bytes);
    let store = MetricsStore::new(map);
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        let value = match black_box(&store).load(black_box(&key), black_box(&identity), black_box(&Aggregate::EMPTY)) {
            Ok(Some(value)) => value.total() + 3,
            Err(StoreError::MalformedRecord) => 1,
            Err(StoreError::IdentityMismatch) => 2,
            _ => panic!("unexpected stored-unit result"),
        };
        sink = sink.wrapping_add(black_box(value));
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}

#[ic_cdk::update]
fn compare(_n: u16, case: u8, iterations: u32) -> (u64, u128) {
    assert!(iterations <= 1024);
    #[cfg(feature = "hist")]
    let sink = histogram(case, iterations);
    #[cfg(feature = "restore")]
    let sink = match _n { 0 => restoration::<0>(case, iterations), 4 => restoration::<4>(case, iterations), 256 => restoration::<256>(case, iterations), _ => panic!("bad bounds") };
    #[cfg(feature = "unit")]
    let sink = units(case, iterations);
    sink
}
