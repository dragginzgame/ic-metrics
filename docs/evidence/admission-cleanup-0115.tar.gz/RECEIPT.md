# Frozen Metrics admission experiment

Baseline: 9665613f05f6477fe97ad60562e54185ed875aac (v0.11.4).
Product manifest/lock are the root Cargo.toml/Cargo.lock copies.
Fixture manifest/lock have their independent experimental identities.

The build selects baseline-core/baseline-stable, then independently substitutes
rank-core (retained), flag-core (rejected), or candidate-stable (retained).
Both retained substitutions match the root working-tree runtime sources.
rank-core-attempt1 and candidate-hist-attempt1.wasm identify the first rank order.
results-attempt1 contains that attempt; results-attempt2 contains the final rank
order. Neither attempt drops the rejected flag variant or malformed-unit rows.

Replay rebuilt six final Wasms byte-for-byte and reran 384 updates. All result
sinks and candidate-minus-baseline bracket instruction deltas matched attempt 2.
replay-results retains the independent observations, replay.log the build receipt.
Cycle charges cover whole updates, including setup; do not treat them as isolated
arithmetic costs. Unit absolute costs can vary with stable allocation history.

Use replay.sh with the prepared compiler/server and owning Metrics target.
It preserves this payload and creates a fresh scratch copy. Builds are offline
and locked; dependency cache preparation is a separate explicit step.

Only Metrics source and this experiment's authored fixture/results are selected.
The archive contains no private sibling source, issue bodies or search excerpts.
Tests/docs within source copies preserve their original context; they do not
establish downstream qualification. Runtime outputs and copied sources are
frozen evidence, not maintained production or CI tooling.
