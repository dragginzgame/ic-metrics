#!/usr/bin/env bash
set -euo pipefail
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${METRICS_TARGET_DIR:?Select the owning Metrics target directory}"
for variant in baseline candidate; do
    for kernel in hist restore unit; do
        core="$root/baseline-core"
        stable="$root/baseline-stable"
        if [[ "$variant" == candidate ]]; then
            case "$kernel" in
                hist) core="$root/rank-core" ;;
                restore) core="$root/flag-core" ;;
                unit) stable="$root/candidate-stable" ;;
            esac
        fi
        # These mutable compiler inputs are owned scratch copies. Frozen owners
        # remain intact; refresh timestamps to invalidate Cargo source caches.
        rm -rf "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src"
        cp -R "$core/src" "$root/fixture/crates/ic-metrics/src"
        cp -R "$stable/src" "$root/fixture/crates/ic-metrics-stable/src"
        find "$root/fixture/crates/ic-metrics/src" "$root/fixture/crates/ic-metrics-stable/src" -type f -exec touch {} +
        cargo build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$METRICS_TARGET_DIR" --offline --locked -p stable-probe --features "$kernel" --release --target wasm32-unknown-unknown
        cp "$METRICS_TARGET_DIR/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/$variant-$kernel.wasm"
    done
done
cargo build --manifest-path "$root/fixture/Cargo.toml" --target-dir "$METRICS_TARGET_DIR" --offline --locked -p stable-driver
