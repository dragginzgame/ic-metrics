#!/usr/bin/env bash
set -euo pipefail
[[ $# == 1 && "$1" == /* ]] || { echo 'usage: replay.sh ABSOLUTE_METRICS_TARGET_DIR' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${POCKET_IC_BIN:?Prepare PocketIC 16.1.0 explicitly}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
(cd "$root" && shasum -a 256 -c SHA256SUMS) > /dev/null
mkdir -p "$1"
scratch="$(mktemp -d "$1/bounds-rank-replay.XXXXXX")"
cp -R "$root/fixture" "$scratch/fixture"
for variant in baseline candidate; do
    rm -r "$scratch/fixture/crates/ic-metrics/src"
    cp -R "$root/$variant/src" "$scratch/fixture/crates/ic-metrics/src"
    find "$scratch/fixture/crates/ic-metrics/src" -type f -exec touch {} +
    for kernel in hist samples; do
        cargo build --manifest-path "$scratch/fixture/Cargo.toml" --target-dir "$1" --locked --offline --release -p stable-probe --target wasm32-unknown-unknown --features "$kernel"
        cmp "$1/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/fixture/$variant-$kernel.wasm"
    done
done
cargo build --manifest-path "$scratch/fixture/Cargo.toml" --target-dir "$1" --locked --offline -p stable-driver
"$1/debug/stable-driver" "$scratch/fixture" "$scratch/results"
cmp "$root/results/costs.csv" "$scratch/results/costs.csv"
printf 'Four Wasms and all raw IC observations reproduced; scratch retained: %s\n' "$scratch"
