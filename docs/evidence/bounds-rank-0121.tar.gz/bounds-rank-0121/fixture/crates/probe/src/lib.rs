//! Frozen matched public-API comparison; no product endpoint or timing claim.
use std::hint::black_box;
#[ic_cdk::update]
fn compare(case: u8, iterations: u32) -> (u64, u128) {
    assert!(case < 7 && iterations <= 1024);
    #[cfg(any(feature = "hist", feature = "samples"))]
    let (n, d) = match case {
        0 => (1, 2), 1 => (95, 100), 2 => (1, u64::MAX),
        3 => (u64::MAX, u64::MAX), 4 => (u64::MAX - 1, u64::MAX),
        5 => (u64::MAX / 5, u64::MAX), _ => (u64::MAX / 5 + 1, u64::MAX),
    };
    #[cfg(any(feature = "floor", feature = "nearest"))]
    let (n, d, s) = match case {
        0 => (7, 6, 1000), 1 => (10, 3, 10),
        2 => (u128::MAX, 10, 10),
        3 => ((u128::MAX / 7) * 6 + 3, 6, 7),
        4 => (u128::MAX, u64::MAX, u64::MAX),
        5 => (u128::MAX, 1, 2), _ => (1, 0, 0),
    };
    #[cfg(feature = "hist")]
    let h = {
        let mut h = ic_metrics::MeasurementHistogram::new([0, 10000, 100000, 1000000]).unwrap();
        for sample in [0, 10000, 100000, 1000000, 1000001] { h.record(sample); }
        h
    };
    let mut sink = 0_u128;
    let start = ic_cdk::api::instruction_counter();
    for _ in 0..iterations {
        #[cfg(feature = "hist")]
        {
            let range = black_box(&h).quantile_bucket(black_box(n), black_box(d)).unwrap().unwrap();
            sink = sink.wrapping_add(u128::from(range.lower_exclusive().unwrap_or(0)))
                .wrapping_add(u128::from(range.upper_inclusive().unwrap_or(0)))
                .wrapping_add(u128::from(range.lower_exclusive().is_some()))
                .wrapping_add(u128::from(range.upper_inclusive().is_some()));
        }
        #[cfg(feature = "samples")]
        {
            let mut values = black_box([1000001.0, 0.0, 100000.0, 10000.0, 1000000.0]);
            let r = ic_metrics::summarize_samples(black_box(&mut values), black_box(n), black_box(d)).unwrap().unwrap();
            let bits = r.minimum.to_bits() ^ r.maximum.to_bits() ^ r.mean.to_bits() ^ r.median.to_bits() ^ r.quantile.to_bits();
            sink = sink.wrapping_add(u128::from(bits)).wrapping_add(r.count as u128);
        }
        #[cfg(any(feature = "floor", feature = "nearest"))]
        {
            #[cfg(feature = "floor")]
            let result = ic_metrics::checked_scaled_ratio(black_box(n), black_box(d), black_box(s));
            #[cfg(feature = "nearest")]
            let result = ic_metrics::checked_scaled_ratio_nearest(black_box(n), black_box(d), black_box(s));
            let value = match black_box(result) {
                Ok(value) => value,
                Err(ic_metrics::MeasurementRatioError::ZeroDenominator) => 1,
                Err(ic_metrics::MeasurementRatioError::Overflow) => 2,
            };
            sink = sink.wrapping_add(value);
        }
        black_box(sink);
    }
    (ic_cdk::api::instruction_counter() - start, sink)
}
