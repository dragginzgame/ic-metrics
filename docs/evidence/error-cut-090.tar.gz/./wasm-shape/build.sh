#!/usr/bin/env bash
set -euo pipefail
[[ $# == 3 ]] || { echo 'usage: build.sh BASELINE-SRC CANDIDATE-SRC NEW-OUTPUT' >&2; exit 2; }
probe="${BASH_SOURCE[0]%/*}/probe.rs"
[[ ! -e "$3" ]] || { echo 'output already exists' >&2; exit 1; }
mkdir -p "$3"
output="$3"
rustc +1.99.0 -vV > "$output/compiler.txt"
flags=(--edition=2024 --target wasm32-unknown-unknown -C opt-level=z -C lto=fat -C codegen-units=1 -C panic=abort -C strip=symbols -D warnings -A unused-imports -A unused-variables)
for source in baseline candidate; do
    if [[ "$source" == baseline ]]; then src="$1/lib.rs"; else src="$2/lib.rs"; fi
    mkdir "$output/$source"
    rustc +1.99.0 "${flags[@]}" --crate-type rlib --crate-name ic_metrics "$src" -o "$output/$source/libic_metrics.rlib"
    for mode in mean scaled interval generic_ratio record histogram_restore; do
        rustc +1.99.0 "${flags[@]}" --check-cfg 'cfg(mean,scaled,interval,generic_ratio,record,histogram_restore)' --cfg "$mode" --crate-type cdylib --crate-name metrics_probe \
            --extern "ic_metrics=$output/$source/libic_metrics.rlib" "$probe" -o "$output/$source/$mode.wasm"
    done
done
