#![no_std]
#![no_main]
use core::hint::black_box;
use ic_metrics::{MeasurementAggregate, MeasurementHistogram, checked_scaled_ratio};
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { core::arch::wasm32::unreachable() }
#[unsafe(no_mangle)]
pub extern "C" fn run(first: u64, second: u64, scale: u64, empty: u32) -> u128 {
    #[cfg(generic_ratio)]
    { return checked_scaled_ratio(black_box(first) as u128 * black_box(second) as u128, black_box(scale), black_box(empty) as u64).unwrap_or(u128::MAX); }
    #[cfg(histogram_restore)]
    {
        let maximum = black_box(second);
        let samples = black_box(first).max(1);
        let aggregate = MeasurementAggregate::from_parts(samples, samples as u128 * maximum as u128, Some(maximum), false, false).unwrap();
        let histogram = MeasurementHistogram::from_parts([maximum], [samples], 0, [false], false, aggregate).unwrap();
        return black_box(histogram).aggregate().total();
    }
    #[cfg(not(any(generic_ratio, histogram_restore)))]
    {
        let mut values = MeasurementAggregate::EMPTY;
        if black_box(empty) == 0 { values.record(black_box(first)); values.record(black_box(second)); }
        let values = black_box(values);
        #[cfg(mean)]
        { return values.mean().unwrap().unwrap_or(u128::MAX); }
        #[cfg(scaled)]
        { return values.scaled_mean(black_box(scale)).unwrap().unwrap_or(u128::MAX); }
        #[cfg(interval)]
        { return values.interval_since(MeasurementAggregate::EMPTY).unwrap().mean().unwrap_or(u128::MAX); }
        #[cfg(record)]
        { return values.total(); }
    }
}
