//! Fixed-cardinality gameplay observations composed into the existing public sampler.
//! Instruction spans exclude Candid decoding/encoding; they are not cycle charges.

use std::cell::RefCell;

use canic::dto::public_status::{PublicMetric, PublicMetricKind};
use ic_metrics::record_sample;

use crate::action::{ExecuteActionsError, ExecuteActionsReceipt, ExecuteActionsRequest};

const BINS: [&str; 5] = [
    "position",
    "one",
    "two_to_eight",
    "nine_to_sixteen",
    "seventeen_to_one_hundred_twenty_eight",
];

#[derive(Clone, Default)]
struct Bin {
    attempts: u64,
    instructions_total: u128,
}

#[derive(Default)]
struct Measurements {
    started_at: Option<u64>,
    bins: [Bin; 5],
    intent_bytes_total: u64,
    commits: u64,
    actions_committed: u64,
    replays: u64,
    rejections: u64,
    projection_failures: u64,
}

thread_local! {
    static MEASUREMENTS: RefCell<Measurements> = RefCell::new(Measurements::default());
}

/// Observe one typed endpoint outcome without retaining payloads or caller identities.
pub(crate) fn measure(
    request: &ExecuteActionsRequest,
    execute: impl FnOnce() -> Result<ExecuteActionsReceipt, ExecuteActionsError>,
) -> Result<ExecuteActionsReceipt, ExecuteActionsError> {
    let before = super::instruction_counter();
    let result = execute();
    let instructions = super::instruction_counter().saturating_sub(before);
    let actions = request.actions.len() as u64;
    MEASUREMENTS.with_borrow_mut(|metrics| {
        metrics.record(actions, instructions, &result, crate::clock::now());
    });
    result
}

impl Measurements {
    fn record(
        &mut self,
        actions: u64,
        instructions: u64,
        result: &Result<ExecuteActionsReceipt, ExecuteActionsError>,
        now: u64,
    ) {
        self.started_at.get_or_insert(now);
        let index = match actions {
            0 => Some(0),
            1 => Some(1),
            2..=8 => Some(2),
            9..=16 => Some(3),
            17..=128 => Some(4),
            _ => None,
        };
        // Oversized input has only a rejected outcome, never a valid size group.
        if let Some(index) = index {
            let bin = &mut self.bins[index];
            record_sample(&mut bin.attempts, &mut bin.instructions_total, instructions);
        }
        match result {
            Ok(receipt) if receipt.replayed => self.replays = self.replays.saturating_add(1),
            Ok(receipt) => {
                self.commits = self.commits.saturating_add(1);
                self.actions_committed = self
                    .actions_committed
                    .saturating_add(u64::from(receipt.actions_applied));
            }
            Err(ExecuteActionsError::CommittedProjectionUnavailable) => {
                self.projection_failures = self.projection_failures.saturating_add(1);
            }
            Err(_) => self.rejections = self.rejections.saturating_add(1),
        }
    }

    fn project(&self, now: u64) -> Vec<PublicMetric> {
        let mut rows = Vec::with_capacity(17);
        let mut add = |name: String, value: u128, unit: &str| {
            rows.push(PublicMetric {
                name: format!("gameplay.{name}"),
                value,
                unit: unit.into(),
                canister_id: None,
                observed_at_ns: now,
                // Heap totals restart after an upgrade; never imply interval continuity.
                kind: PublicMetricKind::Gauge,
            });
        };
        add(
            "window_started_at_ns".into(),
            u128::from(self.started_at.unwrap_or(now)),
            "nanoseconds",
        );
        add(
            "intent_bytes_total".into(),
            u128::from(self.intent_bytes_total),
            "bytes",
        );
        add(
            "actions_committed".into(),
            u128::from(self.actions_committed),
            "actions",
        );
        for (name, value) in [
            ("commits", self.commits),
            ("replays", self.replays),
            ("rejections", self.rejections),
            ("projection_failures", self.projection_failures),
        ] {
            add(name.into(), u128::from(value), "executions");
        }
        for (name, bin) in BINS.iter().zip(&self.bins) {
            for (suffix, value, unit) in [
                ("attempts", u128::from(bin.attempts), "executions"),
                ("instructions_total", bin.instructions_total, "instructions"),
            ] {
                add(format!("batch.{name}.{suffix}"), value, unit);
            }
        }
        rows
    }
}

/// Reuse the replay fingerprint's existing canonical encoding; never copy ingress again.
pub(crate) fn record_intent_bytes(bytes: usize) {
    MEASUREMENTS.with_borrow_mut(|metrics| {
        metrics.intent_bytes_total = metrics.intent_bytes_total.saturating_add(bytes as u64);
    });
}

#[cfg(not(test))]
pub(super) fn sample() -> Vec<PublicMetric> {
    MEASUREMENTS.with_borrow(|metrics| metrics.project(crate::clock::now()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn projects_exact_totals_for_maximum_instruction_samples() {
        let mut metrics = Measurements::default();
        for instructions in [u64::MAX, u64::MAX, 0] {
            metrics.record(
                1,
                instructions,
                &Err(ExecuteActionsError::RevisionConflict),
                10,
            );
        }
        let rows = metrics.project(20);
        let encoded = candid::encode_one(&rows).unwrap();
        let decoded: Vec<PublicMetric> = candid::decode_one(&encoded).unwrap();
        let get = |name: &str| decoded.iter().find(|row| row.name == name).unwrap();
        let total = get("gameplay.batch.one.instructions_total");
        assert_eq!(total.value, 2 * u128::from(u64::MAX));
        assert_eq!(total.unit, "instructions");
        assert_eq!(get("gameplay.batch.one.attempts").value, 3);
        assert_eq!(get("gameplay.rejections").value, 3);
        assert_eq!(get("gameplay.actions_committed").value, 0);
        assert_eq!(get("gameplay.window_started_at_ns").value, 10);
        assert!(decoded.iter().all(|row| row.observed_at_ns == 20));
    }

    #[test]
    fn exact_retries_do_not_count_as_new_actions() {
        let mut metrics = Measurements::default();
        let mut receipt = ExecuteActionsReceipt {
            journey: None,
            minions: None,
            field: None,
            action_revision: 1,
            hangar: None,
            robot: None,
            replayed: false,
            actions_applied: 16,
        };
        metrics.record(16, 2_000, &Ok(receipt.clone()), 10);
        receipt.replayed = true;
        metrics.record(16, 300, &Ok(receipt), 20);
        let bin = &metrics.bins[3];
        assert_eq!(bin.attempts, 2);
        assert_eq!(metrics.commits, 1);
        assert_eq!(metrics.replays, 1);
        assert_eq!(metrics.actions_committed, 16);
        assert_eq!(bin.instructions_total, 2_300);
    }

    #[test]
    fn records_rejections_and_projection_failures_without_claiming_committed_actions() {
        let mut metrics = Measurements::default();
        metrics.record(8, 300, &Err(ExecuteActionsError::RevisionConflict), 10);
        metrics.record(
            8,
            500,
            &Err(ExecuteActionsError::CommittedProjectionUnavailable),
            20,
        );
        let rows = metrics.project(30);
        let get = |name: &str| rows.iter().find(|row| row.name == name).unwrap().value;
        assert_eq!(get("gameplay.batch.two_to_eight.attempts"), 2);
        assert_eq!(get("gameplay.actions_committed"), 0);
        assert_eq!(get("gameplay.rejections"), 1);
        assert_eq!(get("gameplay.projection_failures"), 1);
        assert_eq!(get("gameplay.batch.two_to_eight.instructions_total"), 800);
        assert_eq!(rows.len(), 17);
        assert!(
            rows.iter()
                .all(|row| row.canister_id.is_none() && row.kind == PublicMetricKind::Gauge)
        );
    }
}
