//! Module: ops::runtime::metrics::canister_ops
//!
//! Responsibility: record and snapshot low-cardinality runtime metrics for the canister_ops family.
//! Does not own: workflow decisions, persisted records, or endpoint DTOs.
//! Boundary: ops-layer metrics consumed by workflow metrics projection.

use canic_contracts::ids::CanisterRole;
use std::{cell::RefCell, collections::BTreeMap};

pub use crate::{
    domain::metrics::CanisterOpsMetricOperation, domain::metrics::CanisterOpsMetricOutcome,
    domain::metrics::CanisterOpsMetricReason,
};

const UNSCOPED_ROLE_LABEL: &str = "unscoped";
const UNKNOWN_ROLE_LABEL: &str = "unknown";

thread_local! {
    static CANISTER_OPS_METRICS: RefCell<BTreeMap<CanisterOpsMetricKey, u64>> =
        const { RefCell::new(BTreeMap::new()) };
}

///
/// CanisterOpsMetricKey
///
/// Composite key for one low-cardinality canister operation counter.
///

#[derive(Clone, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct CanisterOpsMetricKey {
    pub operation: CanisterOpsMetricOperation,
    pub role: String,
    pub outcome: CanisterOpsMetricOutcome,
    pub reason: CanisterOpsMetricReason,
}

///
/// CanisterOpsMetrics
///
/// Operations-layer recorder for canister operation counters.
///

pub struct CanisterOpsMetrics;

impl CanisterOpsMetrics {
    /// Read a deterministic bounded prefix for optional public sampling.
    pub(crate) fn bounded_snapshot(
        limit: usize,
    ) -> Result<Vec<(CanisterOpsMetricKey, u64)>, crate::InternalError> {
        CANISTER_OPS_METRICS.with_borrow(|counts| {
            if counts.keys().take(limit).any(|key| {
                key.role.len() > crate::model::public_metrics::MAX_PUBLIC_METRIC_TEXT_BYTES
            }) {
                return Err(crate::InternalError::invalid_input());
            }
            Ok(counts
                .iter()
                .take(limit)
                .map(|(key, count)| (key.clone(), *count))
                .collect())
        })
    }

    /// Record one canister operation event for a concrete role label.
    pub fn record(
        operation: CanisterOpsMetricOperation,
        role: &CanisterRole,
        outcome: CanisterOpsMetricOutcome,
        reason: CanisterOpsMetricReason,
    ) {
        Self::record_role_label(operation, role.as_str(), outcome, reason);
    }

    /// Record one canister operation event when no role is available.
    pub fn record_unscoped(
        operation: CanisterOpsMetricOperation,
        outcome: CanisterOpsMetricOutcome,
        reason: CanisterOpsMetricReason,
    ) {
        Self::record_role_label(operation, UNSCOPED_ROLE_LABEL, outcome, reason);
    }

    /// Record one canister operation event when role lookup failed.
    pub fn record_unknown_role(
        operation: CanisterOpsMetricOperation,
        outcome: CanisterOpsMetricOutcome,
        reason: CanisterOpsMetricReason,
    ) {
        Self::record_role_label(operation, UNKNOWN_ROLE_LABEL, outcome, reason);
    }

    // Increment one canister operation counter with a bounded role label.
    fn record_role_label(
        operation: CanisterOpsMetricOperation,
        role: &str,
        outcome: CanisterOpsMetricOutcome,
        reason: CanisterOpsMetricReason,
    ) {
        CANISTER_OPS_METRICS.with_borrow_mut(|counts| {
            let key = CanisterOpsMetricKey {
                operation,
                role: role.to_string(),
                outcome,
                reason,
            };
            let entry = counts.entry(key).or_insert(0);
            *entry = entry.saturating_add(1);
        });
    }

    /// Snapshot the current canister operation metric table as stable rows.
    #[must_use]
    pub fn snapshot() -> Vec<(CanisterOpsMetricKey, u64)> {
        CANISTER_OPS_METRICS
            .with_borrow(std::clone::Clone::clone)
            .into_iter()
            .collect()
    }

    /// Test-only helper: clear all canister operation metrics.
    #[cfg(test)]
    pub fn reset() {
        CANISTER_OPS_METRICS.with_borrow_mut(BTreeMap::clear);
    }
}

// -----------------------------------------------------------------------------
// Tests
// -----------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    // Convert snapshots into a map for concise count assertions.
    fn snapshot_map() -> BTreeMap<CanisterOpsMetricKey, u64> {
        CanisterOpsMetrics::snapshot().into_iter().collect()
    }

    // Verify canister operation counters accumulate by operation, role, outcome, and reason.
    #[test]
    fn canister_ops_metrics_accumulate_by_operation_role_outcome_and_reason() {
        CanisterOpsMetrics::reset();
        let role = CanisterRole::new("app");

        CanisterOpsMetrics::record(
            CanisterOpsMetricOperation::Create,
            &role,
            CanisterOpsMetricOutcome::Started,
            CanisterOpsMetricReason::Ok,
        );
        CanisterOpsMetrics::record(
            CanisterOpsMetricOperation::Create,
            &role,
            CanisterOpsMetricOutcome::Failed,
            CanisterOpsMetricReason::Topology,
        );
        CanisterOpsMetrics::record(
            CanisterOpsMetricOperation::Create,
            &role,
            CanisterOpsMetricOutcome::Failed,
            CanisterOpsMetricReason::Topology,
        );
        CanisterOpsMetrics::record_unscoped(
            CanisterOpsMetricOperation::Delete,
            CanisterOpsMetricOutcome::Completed,
            CanisterOpsMetricReason::Ok,
        );
        CanisterOpsMetrics::record_unscoped(
            CanisterOpsMetricOperation::Install,
            CanisterOpsMetricOutcome::Failed,
            CanisterOpsMetricReason::ManagementCall,
        );

        let map = snapshot_map();

        assert_eq!(
            map.get(&CanisterOpsMetricKey {
                operation: CanisterOpsMetricOperation::Create,
                role: "app".to_string(),
                outcome: CanisterOpsMetricOutcome::Started,
                reason: CanisterOpsMetricReason::Ok,
            }),
            Some(&1)
        );
        assert_eq!(
            map.get(&CanisterOpsMetricKey {
                operation: CanisterOpsMetricOperation::Create,
                role: "app".to_string(),
                outcome: CanisterOpsMetricOutcome::Failed,
                reason: CanisterOpsMetricReason::Topology,
            }),
            Some(&2)
        );
        assert_eq!(
            map.get(&CanisterOpsMetricKey {
                operation: CanisterOpsMetricOperation::Delete,
                role: "unscoped".to_string(),
                outcome: CanisterOpsMetricOutcome::Completed,
                reason: CanisterOpsMetricReason::Ok,
            }),
            Some(&1)
        );
        assert_eq!(
            map.get(&CanisterOpsMetricKey {
                operation: CanisterOpsMetricOperation::Install,
                role: "unscoped".to_string(),
                outcome: CanisterOpsMetricOutcome::Failed,
                reason: CanisterOpsMetricReason::ManagementCall,
            }),
            Some(&1)
        );
    }
}
