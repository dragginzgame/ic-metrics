# Current handoff

IC Metrics owns allocation-free, dependency-free `no_std` arithmetic. Consumers
own sampling, attribution, units, identities, registries, lifecycle and endpoints.
[The extraction contract](../extraction.md) owns integration boundaries;
[host qualification](../hosts.md) owns setup, focused checks and delivery gates.

## Pending 0.9.0

The mean/interval error cut removes unreachable total-overflow and scaled-mean
projection cases under the admitted exact-count invariant. Update matches or
construction of the removed public variants when selecting 0.9. Actual overflow
flags, scalar-counter/generic-ratio errors, zero/empty semantics and stable V1
bytes remain unchanged. No data reset or compatibility alias is introduced.
The mean error now belongs beside the aggregate projection it describes.

Independent restored-count/total boundary and const checks pass. The matched
standalone raw Wasm probes shrink by 10 bytes for means, 81 for scaled means and
10 for intervals; recording, generic ratio and restoration controls remain
byte-identical. A further narrowing experiment saved only two bytes and was
not adopted. These are scoped raw byte results, not IC instructions/cycles or
whole-application savings. Full CI passes in 299 seconds and all three package
floors pass; eight checkpoints match all 140 frozen/current inputs.
[The cut and size record](../evidence/error-cut-090.md) retains the source,
invariant, checks and comparisons. Earlier receipts keep their original scope.

All six consumer sources were reviewed read-only. None matches or constructs the
removed error variants. IcyDB's numeric projection is checked separately from
transport/platform acceptance. Toko still imports the older `record_sample`;
its existing adoption issue owns that prior-cut mismatch. Consumer dependency
selection and runtime/native acceptance remain at their owner. Package metadata
stays 0.8.4; no dependency, pin, real Git index/ref or release effect is changed.
Owning adoption feedback is recorded in [IcyDB #356](https://github.com/dragginzgame/icydb/issues/356),
[Timers #51](https://github.com/dragginzgame/ic-timers/issues/51),
[Blob #65](https://github.com/dragginzgame/ic-blob-storage/issues/65),
[Canic #523](https://github.com/dragginzgame/canic/issues/523#issuecomment-6142973661),
[Backup #41](https://github.com/dragginzgame/ic-backup/issues/41#issuecomment-6142974446) and
[Toko #48](https://github.com/dragginzgame/toko-miner/issues/48#issuecomment-6142975089).

## Delivered 0.8.4

Local finalized release source is `0baae3a49b0bb2c42b32dfe8005b33d07e7e11d7`.
The release contains private mean ownership cleanup and Memory 0.36.1 selection.
[Its frozen preparation](../evidence/cleanup-084.tar.gz) retains the 377-second
CI/floor qualification and byte-identical mean probes on its original inputs.
Earlier [decoder](../evidence/decoder-083.md) and
[Memory adoption](../evidence/memory-083.md) receipts retain their earlier graphs.
None qualifies pending 0.9 or establishes later hosted release acceptance.

Hosts coordinate their Memory 0.36 adoption through
[Canic #527](https://github.com/dragginzgame/canic/issues/527),
[IcyDB #355](https://github.com/dragginzgame/icydb/issues/355) and
[Blob Storage #64](https://github.com/dragginzgame/ic-blob-storage/issues/64).
Local adapter qualification does not establish those applications' acceptance.

Earlier [0.8.2 publication verification](../evidence/release-082.md) retains its
exact archives, source and initial CI observations. Publication does not complete
native acceptance.
[Released 0.8.1 acceptance](../evidence/release-081.md)
retains its own complete Linux, Intel, Apple Silicon and Rust-floor receipts.

`MeasurementCounter` is available for scalar wide totals, merging, restoration
and exact totals/deltas. It keeps no observation statistics or stored kind.
The stable adapter still admits aggregate, summary and histogram only; no kind
is repurposed or data reset. [The counter record](../evidence/counter-082.md)
and [cleanup record](../evidence/cleanup-082.md) retain their pre-release sources,
including the 261-second final CI/floor proof and separate raw Wasm comparison.
Historical measurements do not establish later application costs.

The selected lock retains Host 0.16.0, Memory 0.36.1 and Syn 3.0.9. Arithmetic
stays on Rust 1.85; stable and private inspector stay on 1.88. Shared Tooling
0.9.10 `7e55adecf6f0b196c050f104b37f8c69b6bf434e` retains all 104 payloads and
91 roots. [Its adoption receipt](../evidence/adoption-082-shared-0910.md) keeps the
earlier graph/slice scope. Metrics retains complete native validation and
direct-only release delivery; older tool generations and evidence remain retained.

## Consumer and API follow-up

The [six-consumer review](../evidence/consumer-review-082.md) binds its read-only
caller observations. Current adoption/reporting work stays with the
[owning issues](../extraction.md#downstream-contract-checks), including Toko's
[database quality bridge](https://github.com/dragginzgame/toko-miner/issues/49).
[Metrics #10](https://github.com/dragginzgame/ic-metrics/issues/10) retains Canic's
original held-HTTP/native qualification. [Canic #450](https://github.com/dragginzgame/canic/issues/450#issuecomment-6126296388)
and [#491](https://github.com/dragginzgame/canic/issues/491#issuecomment-6126296804)
retain the scoped repair and Auth blocker; no new passing runtime/macOS proof
is claimed. Logs remain in Canic's `.tmp/metrics-qualification-20261012/`.
[#69](https://github.com/dragginzgame/ic-metrics/issues/69) owns this selected
error cut. This batch edits Metrics only and performs no release effects.
