#![no_std]
#![no_main]
use core::hint::black_box;
use ic_metrics::MeasurementHistogram;
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { core::arch::wasm32::unreachable() }
#[unsafe(no_mangle)]
pub extern "C" fn run(value: u64, numerator: u64, denominator: u64) -> u64 {
    let mut histogram = match MeasurementHistogram::new([0, 10_000, 100_000, 1_000_000]) {
        Ok(histogram) => histogram,
        Err(_) => return 0,
    };
    for sample in [0, 10_000, 100_000, 1_000_000, value] { histogram.record(black_box(sample)); }
    #[cfg(query)]
    {
        let histogram = black_box(histogram);
        match histogram.quantile_bucket(black_box(numerator), black_box(denominator)) {
            Ok(Some(range)) => range.upper_inclusive().unwrap_or(u64::MAX),
            Ok(None) => 0,
            Err(_) => 1,
        }
    }
    #[cfg(not(query))]
    { let _ = (numerator, denominator); black_box(histogram.aggregate().samples()) }
}
