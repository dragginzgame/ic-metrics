#!/usr/bin/env bash
set -euo pipefail
root="$(cd "${BASH_SOURCE[0]%/*}/../../../.." && pwd -P)"
shape="$root/target/evidence/cleanup-082/wasm-shape"
cd "$root"
rustc +1.99.0 -vV > "$shape/compiler.txt"
flags=(--edition=2024 --target wasm32-unknown-unknown -C opt-level=z -C lto=fat -C codegen-units=1 -C panic=abort -C strip=symbols -D warnings)
for source in baseline candidate; do
    if [[ "$source" == baseline ]]; then src="$root/target/evidence/cleanup-082/before/crates/ic-metrics/src/lib.rs"
    else src="$root/crates/ic-metrics/src/lib.rs"; fi
    rustc +1.99.0 "${flags[@]}" --crate-type rlib --crate-name ic_metrics "$src" -o "$shape/$source/libic_metrics.rlib"
    for mode in record query; do
        cfg=(); [[ "$mode" != query ]] || cfg=(--cfg query)
        rustc +1.99.0 "${flags[@]}" --check-cfg 'cfg(query)' "${cfg[@]}" --crate-type cdylib --crate-name cleanup_probe \
            --extern "ic_metrics=$shape/$source/libic_metrics.rlib" "$shape/probe.rs" -o "$shape/$source/$mode.wasm"
    done
done
