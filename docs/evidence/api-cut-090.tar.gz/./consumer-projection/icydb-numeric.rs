use ic_metrics::MeasurementAggregate;
pub struct InstructionMetrics {
    samples: u64,
    instructions_total: u128,
    instructions_max: u64,
    samples_saturated: bool,
    total_saturated: bool,
    instructions_mean: Option<u128>,
}
impl InstructionMetrics {
    /// Number of completed observation spans, including failed attempts.
    #[must_use]
    pub const fn samples(&self) -> u64 {
        self.samples
    }

    /// Wide saturating sum of observed local instructions, encoded as Candid `nat`.
    #[must_use]
    pub const fn instructions_total(&self) -> u128 {
        self.instructions_total
    }

    /// Largest local instruction interval in this window.
    #[must_use]
    pub const fn instructions_max(&self) -> u64 {
        self.instructions_max
    }

    /// Whether the sample count actually overflowed, rather than reaching its cap.
    #[must_use]
    pub const fn samples_saturated(&self) -> bool {
        self.samples_saturated
    }

    /// Whether the instruction total actually overflowed.
    #[must_use]
    pub const fn total_saturated(&self) -> bool {
        self.total_saturated
    }

    /// Exact floor-rounded mean, unavailable for empty or overflowed observations.
    #[must_use]
    pub const fn instructions_mean(&self) -> Option<u128> {
        self.instructions_mean
    }
}
impl From<MeasurementAggregate> for InstructionMetrics {
    fn from(measurement: MeasurementAggregate) -> Self {
        Self {
            samples: measurement.samples(),
            instructions_total: measurement.total(),
            instructions_max: measurement.maximum().unwrap_or(0),
            samples_saturated: measurement.samples_overflowed(),
            total_saturated: measurement.total_overflowed(),
            instructions_mean: measurement.mean().ok().flatten(),
        }
    }
}
#[test]
fn numeric_report_projection_preserves_empty_zero_wide_and_overflow_quality() {
    for (aggregate, expected) in [
        (MeasurementAggregate::EMPTY, None),
        (MeasurementAggregate::from_parts(1, 0, Some(0), false, false).unwrap(), Some(0)),
        (MeasurementAggregate::from_parts(2, 2 * u128::from(u64::MAX), Some(u64::MAX), false, false).unwrap(), Some(u128::from(u64::MAX))),
        (MeasurementAggregate::from_parts(u64::MAX, u128::MAX, Some(u64::MAX), true, true).unwrap(), None),
    ] {
        let report = InstructionMetrics::from(aggregate);
        assert_eq!(report.samples, aggregate.samples());
        assert_eq!(report.instructions_total, aggregate.total());
        assert_eq!(report.instructions_max, aggregate.maximum().unwrap_or(0));
        assert_eq!(report.samples_saturated, aggregate.samples_overflowed());
        assert_eq!(report.total_saturated, aggregate.total_overflowed());
        assert_eq!(report.instructions_mean, expected);
    }
}
