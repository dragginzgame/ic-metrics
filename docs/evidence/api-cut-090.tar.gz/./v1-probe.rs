use ic_memory::ic_stable_structures::{BTreeMap, VectorMemory};
use ic_metrics::{MeasurementAggregate, MeasurementSummary, MeasurementHistogram};
use ic_metrics_stable::{DurableMetric, MetricIdentity, MetricKey, MetricsStore, StoreError};
fn checkpoint<T: DurableMetric>(store: &mut MetricsStore<VectorMemory>, name: &str, value: &T) -> Result<(),StoreError> {
    let key = MetricKey::new("app", name)?;
    let id = MetricIdentity::new("instructions",7)?;
    store.save(&key,&id,value)?;
    assert!(store.load(&key,&id,value)?.is_some());
    Ok(())
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut store = MetricsStore::new(BTreeMap::init(VectorMemory::default()));
    let mut aggregate = MeasurementAggregate::EMPTY;
    let mut summary = MeasurementSummary::EMPTY;
    let mut histogram = MeasurementHistogram::new([0,10])?;
    for v in [0,1,11,u64::MAX] { aggregate.record(v); summary.record(v); histogram.record(v); }
    checkpoint(&mut store,"aggregate",&aggregate)?;
    checkpoint(&mut store,"summary",&summary)?;
    checkpoint(&mut store,"histogram",&histogram)?;
    let count = MeasurementAggregate::from_parts(u64::MAX,0,Some(0),true,false)?;
    checkpoint(&mut store,"count-overflow",&count)?;
    let total = MeasurementAggregate::from_parts(u64::MAX,u128::MAX,Some(u64::MAX),true,true)?;
    checkpoint(&mut store,"total-overflow",&total)?;
    let bucket = MeasurementHistogram::from_parts([0],[u64::MAX],0,[true],false,count)?;
    checkpoint(&mut store,"bucket-overflow",&bucket)?;
    let overflow = MeasurementHistogram::<0>::from_parts([],[],u64::MAX,[],true,total)?;
    checkpoint(&mut store,"overflow-bucket",&overflow)?;
    for entry in store.into_map().iter() { println!("{:02x?}:{:02x?}",entry.key(),entry.value()); }
    Ok(())
}
