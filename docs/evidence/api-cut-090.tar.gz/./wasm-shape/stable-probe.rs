use std::hint::black_box;
use ic_memory::ic_stable_structures::{BTreeMap, VectorMemory};
use ic_metrics::{MeasurementAggregate, MeasurementSummary, MeasurementHistogram};
use ic_metrics_stable::{DurableMetric, MetricIdentity, MetricKey, MetricsStore};
fn roundtrip<T: DurableMetric>(value: &T) -> Option<T> {
    let mut store = MetricsStore::new(BTreeMap::init(VectorMemory::default()));
    let key = MetricKey::new("probe", "work").ok()?;
    let identity = MetricIdentity::new("instructions", 0).ok()?;
    store.save(&key, &identity, value).ok()?;
    store.load(&key, &identity, value).ok()?
}
#[unsafe(no_mangle)]
pub extern "C" fn run(sample: u64) -> u128 {
    #[cfg(aggregate)] let mut value = MeasurementAggregate::EMPTY;
    #[cfg(summary)] let mut value = MeasurementSummary::EMPTY;
    #[cfg(histogram)] let mut value = match MeasurementHistogram::new([0,10]) { Ok(value) => value, Err(_) => return 0 };
    value.record(black_box(sample));
    match roundtrip(&black_box(value)) { Some(value) => {
            #[cfg(histogram)] { return value.aggregate().total(); }
            #[cfg(not(histogram))] { return value.total(); }
        }, None => 0 }
}
