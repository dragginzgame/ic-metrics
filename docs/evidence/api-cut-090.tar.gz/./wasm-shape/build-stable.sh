#!/usr/bin/env bash
set -euo pipefail
root=target/evidence/api-cut-090
flags=(--edition=2024 --target wasm32-unknown-unknown -C opt-level=z -C lto=fat -C codegen-units=1 -C panic=abort -C strip=symbols -D warnings -A unused-imports)
memory=("$(cat "$root/wasm-memory-selected.txt")")
for side in baseline candidate; do
    out="$root/wasm-shape/stable/$side"
    mkdir -p "$out"
    if [[ "$side" == baseline ]]; then source="$root/before/crates"; else source=crates; fi
    rustc +1.99.0 "${flags[@]}" --crate-type rlib --crate-name ic_metrics "$source/ic-metrics/src/lib.rs" -o "$out/libic_metrics.rlib"
    rustc +1.99.0 "${flags[@]}" --crate-type rlib --crate-name ic_metrics_stable "$source/ic-metrics-stable/src/lib.rs" --extern "ic_metrics=$out/libic_metrics.rlib" --extern "ic_memory=${memory[0]}" -L dependency=target/wasm32-unknown-unknown/debug/deps -L dependency=target/debug/deps -o "$out/libic_metrics_stable.rlib"
    for mode in aggregate summary histogram; do
        rustc +1.99.0 "${flags[@]}" --check-cfg 'cfg(aggregate,summary,histogram)' --cfg "$mode" --crate-type cdylib --crate-name stable_probe \
            --extern "ic_metrics=$out/libic_metrics.rlib" --extern "ic_metrics_stable=$out/libic_metrics_stable.rlib" --extern "ic_memory=${memory[0]}" -L "dependency=$out" -L dependency=target/wasm32-unknown-unknown/debug/deps -L dependency=target/debug/deps \
            "$root/wasm-shape/stable-probe.rs" -o "$out/$mode.wasm"
    done
done
