The approved pending Metrics 0.9.0 batch now also closes the raw stable dispatch boundary ([Metrics #71](https://github.com/dragginzgame/ic-metrics/issues/71)) and uses explicit actual-overflow API names:

- Aggregate `samples_saturated()` / `total_saturated()` become `samples_overflowed()` / `total_overflowed()`; scalar counter uses `total_overflowed()`.
- Histogram flags become `bucket_overflowed()` and `overflow_count_overflowed()`. Its `overflow()` count above the last bound stays unchanged.
- Remaining cases become `MeasurementMeanError::SampleCountOverflow`, `MeasurementIntervalError::SampleCountOverflow`, `MeasurementCounterError::TotalOverflow`, `HistogramQueryError::CountOverflow` and `MeasurementStateError::InvalidOverflowFlag`.
- Generic `DurableMetric` store use remains supported. Raw kind/codec/continuity dispatch requires a capability unavailable to safe external callers. No codec API or alias is added.

This updates the earlier pending-batch statements that flag/error *names* remain unchanged. Numeric clipping, actual-overflow quality, exact caps, empty/zero semantics and stable V1 bytes remain unchanged; no Metrics-owned data reset is required. Consumer-owned DTO/wire names do not have to mirror core getter names.

Metrics source is a local dirty preparation over released `0baae3a49b0bb2c42b32dfe8005b33d07e7e11d7`, not a published 0.9 artifact. Its 144-input source roster SHA-256 is `a90167a30a5261e6e03591cc20ff467eee88261945e3316fa6c2540bc1d66ca7`; the final receipt is docs/evidence/api-cut-090.md and its archive. Host 0.17.0/Memory 0.36.1 are selected; arithmetic remains dependency-free/no_std on Rust 1.85 and stable/inspector remain on 1.88. Nine matched raw Wasm probes are byte-identical; seven representative V1 records match before/after. These are scoped library/codec results, not consumer runtime/macOS or IC instruction/cycle acceptance.

Reviewed crates/icydb-core/src/metrics/state.rs and CLI projection. Change only calls on MeasurementAggregate to the new getters; existing consumer-owned samples_saturated/total_saturated DTO fields and getters can keep their wire contract. A copied numeric projection with those core calls updated passes a native boundary test and warning-denied Rust 1.85 Wasm compilation; Candid/platform acceptance remains at IcyDB.

Full Metrics CI passes in 254 seconds; arithmetic native/Wasm Rust 1.85, stable native/Wasm Rust 1.88 and inspector native Rust 1.88 gates pass. Eight gate checkpoints match all 144 frozen inputs. Linux validation does not establish downstream or hosted macOS acceptance.

No sibling source was edited; this issue remains with its existing consumer acceptance obligations.
