#!/usr/bin/env bash
# Frozen IC experiment. Use prepared sources/server; never install or download.
set -euo pipefail
if (($# != 2)); then
    printf 'usage: %s BUILD_DIRECTORY FRESH_RESULT_DIRECTORY\n' "$0" >&2
    exit 2
fi
fixture=$(cd -P -- "$(dirname -- "$0")" && pwd)
build=$1
output=$2
: "${POCKET_IC_BIN:?Select the already prepared PocketIC 16.1.0 executable}"
if [[ -n ${IC_TESTKIT_POCKET_IC_URL+x} ]]; then
    printf 'This experiment requires its exact local server, not a URL.\n' >&2
    exit 2
fi
if [[ $(rustc --version) != 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]; then
    printf 'This experiment selects Rust 1.99.0.\n' >&2
    exit 2
fi
digest=$(sha256sum -- "$POCKET_IC_BIN")
if [[ ${digest%% *} != b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db ]]; then
    printf 'Server differs from the recorded PocketIC executable.\n' >&2
    exit 2
fi
(cd -- "$fixture" && sha256sum -c inputs.sha256)
for revision in initial upgrade; do
    features=durable
    [[ $revision != upgrade ]] || features=durable,upgrade
    cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-probe --target wasm32-unknown-unknown --features "$features" -- -D warnings
    cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-probe --release --target wasm32-unknown-unknown --features "$features"
    cmp -- "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$fixture/artifacts/$revision.wasm"
done
cargo clippy --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-driver -- -D warnings
cargo build --offline --locked --manifest-path "$fixture/Cargo.toml" --target-dir "$build" -p stable-driver
"$build/debug/stable-driver" "$fixture" "$output"
