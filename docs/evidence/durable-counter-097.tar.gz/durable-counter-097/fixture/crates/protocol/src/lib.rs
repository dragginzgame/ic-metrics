//! Frozen experiment protocol, outside the product graph.
use candid::CandidType;
use serde::Deserialize;

#[derive(CandidType, Deserialize, Clone, Debug, Eq, PartialEq)]
pub enum ProbeError {
    Missing,
    Identity,
    Regression,
    Kind,
    Input,
    Storage,
}

#[derive(CandidType, Deserialize, Clone, Debug, Eq, PartialEq)]
pub struct Snapshot {
    pub counters: Vec<(u128, bool)>,
    pub existing: Vec<u128>,
    pub missing: bool,
    pub memory_id: u8,
    pub build: u8,
}

#[derive(CandidType, Deserialize, Clone, Debug, Eq, PartialEq)]
pub struct Measured {
    pub before: u64,
    pub after: u64,
    pub total: u128,
}
