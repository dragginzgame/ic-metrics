//! Frozen IC experiment. Host-owned lifecycle and diagnostic totals, no product API.
use ic_memory::{
    GenericAllocationPolicy, MemoryAllocationPool, MemoryAuthority, MemoryRequest, MemoryRuntime,
    RuntimeMemory, SchemaMetadata, SealedDeclarationSnapshot,
    ic_stable_structures::{BTreeMap, DefaultMemoryImpl},
};
use ic_metrics::{
    MeasurementAggregate as A, MeasurementCounter as C, MeasurementHistogram as H,
    MeasurementSummary as S,
};
use ic_metrics_stable::{DurableMetric, MetricIdentity, MetricKey, MetricsStore, StoreError};
use stable_protocol::{Measured, ProbeError as E, Snapshot};
use std::cell::RefCell;

struct Host {
    store: MetricsStore<RuntimeMemory<DefaultMemoryImpl>>,
    id: u8,
}
thread_local! { static HOST: RefCell<Option<Host>> = const { RefCell::new(None) }; }
const COUNTERS: [&str; 4] = ["live", "zero", "exact-cap", "overflow"];
fn error(e: StoreError) -> E {
    match e {
        StoreError::IdentityMismatch => E::Identity,
        StoreError::StateRegression => E::Regression,
        StoreError::KindMismatch => E::Kind,
        _ => E::Storage,
    }
}
fn key(name: &str) -> Result<MetricKey, E> {
    MetricKey::new("probe", name).map_err(error)
}
fn identity(epoch: u64) -> Result<MetricIdentity, E> {
    MetricIdentity::new("items", epoch).map_err(error)
}
fn host<T>(f: impl FnOnce(&mut Host) -> Result<T, E>) -> Result<T, E> {
    HOST.with_borrow_mut(|h| f(h.as_mut().ok_or(E::Missing)?))
}
fn load<T: DurableMetric>(h: &Host, name: &str, epoch: u64, empty: &T) -> Result<T, E> {
    h.store
        .load(&key(name)?, &identity(epoch)?, empty)
        .map_err(error)?
        .ok_or(E::Missing)
}
fn save<T: DurableMetric>(h: &mut Host, name: &str, epoch: u64, value: &T) -> Result<(), E> {
    h.store
        .save(&key(name)?, &identity(epoch)?, value)
        .map_err(error)
}
fn open() {
    // Constant fixture declarations; a failed bootstrap deliberately traps.
    let pool = MemoryAllocationPool::new(
        vec![MemoryAuthority::new("app", "app.").expect("fixture authority")],
        vec![],
    )
    .expect("fixture pool");
    let declarations = SealedDeclarationSnapshot::new(vec![
        MemoryRequest::new("app", "app.metrics.v1", SchemaMetadata::default())
            .expect("fixture request"),
    ])
    .expect("fixture declaration");
    let mut runtime = MemoryRuntime::new(DefaultMemoryImpl::default()).expect("fixture runtime");
    runtime
        .bootstrap(&declarations, &pool, &GenericAllocationPolicy)
        .expect("fixture bootstrap");
    let id = runtime
        .memory_id("app.metrics.v1")
        .expect("fixture binding");
    let store = MetricsStore::new(BTreeMap::init(
        runtime.open_memory("app.metrics.v1").expect("fixture map"),
    ));
    HOST.with_borrow_mut(|h| *h = Some(Host { store, id }));
}
#[ic_cdk::init]
fn init() {
    open();
}
#[ic_cdk::post_upgrade]
fn post_upgrade() {
    open();
}
#[ic_cdk::update]
fn seed(epoch: u64) -> Result<(), E> {
    host(|h| {
        for (name, value) in COUNTERS.into_iter().zip([
            C::from_parts(u128::from(u64::MAX) + 5, false).map_err(|_| E::Input)?,
            C::ZERO,
            C::from_parts(u128::MAX, false).map_err(|_| E::Input)?,
            C::from_parts(u128::MAX, true).map_err(|_| E::Input)?,
        ]) {
            save(h, name, epoch, &value)?;
        }
        let mut a = A::EMPTY;
        let mut s = S::EMPTY;
        let mut histogram = H::new([0, 10]).map_err(|_| E::Input)?;
        for sample in [0, 7] {
            a.record(sample);
            s.record(sample);
            histogram.record(sample);
        }
        save(h, "aggregate", epoch, &a)?;
        save(h, "summary", epoch, &s)?;
        save(h, "histogram", epoch, &histogram)
    })
}
#[ic_cdk::query]
fn snapshot(epoch: u64) -> Result<Snapshot, E> {
    host(|h| {
        let mut counters = Vec::new();
        for name in COUNTERS {
            let c = load(h, name, epoch, &C::ZERO)?;
            counters.push((c.total(), c.total_overflowed()));
        }
        let a = load(h, "aggregate", epoch, &A::EMPTY)?;
        let s = load(h, "summary", epoch, &S::EMPTY)?;
        let histogram = load(
            h,
            "histogram",
            epoch,
            &H::new([0, 10]).map_err(|_| E::Input)?,
        )?;
        Ok(Snapshot {
            counters,
            existing: vec![
                u128::from(a.samples()),
                a.total(),
                u128::from(a.maximum().ok_or(E::Input)?),
                u128::from(s.samples()),
                s.total(),
                u128::from(s.latest().ok_or(E::Input)?),
                u128::from(histogram.aggregate().samples()),
                histogram.aggregate().total(),
                u128::from(histogram.bucket_counts()[0]),
                u128::from(histogram.bucket_counts()[1]),
            ],
            missing: h
                .store
                .load(&key("missing")?, &identity(epoch)?, &C::ZERO)
                .map_err(error)?
                .is_none(),
            memory_id: h.id,
            build: u8::from(cfg!(feature = "upgrade")),
        })
    })
}
fn append_value(epoch: u64, amount: u64) -> Result<(), E> {
    host(|h| {
        let mut value = load(h, "live", epoch, &C::ZERO)?;
        value.add(u128::from(amount));
        save(h, "live", epoch, &value)
    })
}
#[ic_cdk::update]
fn append(epoch: u64, amount: u64) -> Result<(), E> {
    append_value(epoch, amount)
}
#[ic_cdk::query]
fn query_append(epoch: u64, amount: u64) -> Result<(), E> {
    append_value(epoch, amount)
}
#[ic_cdk::update]
fn trap_after_write(epoch: u64, amount: u64) {
    append_value(epoch, amount).expect("fixture append must succeed before explicit trap");
    ic_cdk::trap("deliberate rollback after durable counter write");
}
#[ic_cdk::update]
fn reject(which: u8, epoch: u64) -> Result<(), E> {
    host(|h| match which {
        0 => save(h, "live", epoch, &C::ZERO),
        1 => save(
            h,
            "overflow",
            epoch,
            &C::from_parts(u128::MAX, false).map_err(|_| E::Input)?,
        ),
        2 => h
            .store
            .save(
                &key("live")?,
                &MetricIdentity::new("bytes", epoch).map_err(error)?,
                &C::ZERO,
            )
            .map_err(error),
        3 => save(h, "live", epoch.checked_add(1).ok_or(E::Input)?, &C::ZERO),
        4 => save(h, "live", epoch, &A::EMPTY),
        _ => Err(E::Input),
    })
}
#[ic_cdk::update]
fn reset(old_epoch: u64) -> Result<(), E> {
    let next = old_epoch.checked_add(1).ok_or(E::Input)?;
    host(|h| {
        for name in COUNTERS
            .into_iter()
            .chain(["aggregate", "summary", "histogram"])
        {
            h.store
                .remove(&key(name)?, &identity(old_epoch)?)
                .map_err(error)?;
        }
        Ok(())
    })?;
    seed(next)
}
#[ic_cdk::update]
fn measure(iterations: u64, cadence: u64, nonce: u64) -> Result<Measured, E> {
    if iterations > 256 || cadence == 0 {
        return Err(E::Input);
    }
    host(|h| {
        let key = key(&format!("cost-{nonce}"))?;
        let identity = identity(0)?;
        let mut value = C::ZERO;
        let before = ic_cdk::api::call_context_instruction_counter();
        for index in 1..=iterations {
            value.add(7);
            if index % cadence == 0 || index == iterations {
                h.store.save(&key, &identity, &value).map_err(error)?;
            }
        }
        let after = ic_cdk::api::call_context_instruction_counter();
        Ok(Measured {
            before,
            after,
            total: value.total(),
        })
    })
}
ic_cdk::export_candid!();
