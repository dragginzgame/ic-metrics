//! Independent oracle for the frozen IC counter fixture; no native cost estimates.
use candid::{Principal, decode_one, encode_args};
use ic_testkit::pic::{PocketIc, PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use stable_protocol::{Measured, ProbeError as E, Snapshot};
use std::{error::Error, fmt, fs, io::Write, path::PathBuf, time::Duration};

#[derive(Debug)]
enum Failure {
    Arguments,
    Check(&'static str),
    Rejected(ic_testkit::pic::RejectResponse),
    Probe(E),
}
impl fmt::Display for Failure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Arguments => f.write_str("expected fixture and fresh output paths"),
            Self::Check(case) => write!(f, "qualification failed: {case}"),
            Self::Rejected(e) => write!(f, "IC rejected: {e}"),
            Self::Probe(e) => write!(f, "probe rejected: {e:?}"),
        }
    }
}
impl Error for Failure {}
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn check(ok: bool, case: &'static str, log: &mut fs::File) -> Result<()> {
    writeln!(log, "{case}\t{}", if ok { "pass" } else { "fail" })?;
    if ok {
        Ok(())
    } else {
        Err(Failure::Check(case).into())
    }
}
fn update(pic: &PocketIc, id: Principal, method: &str, args: Vec<u8>) -> Result<Vec<u8>> {
    Ok(pic
        .update_call(id, Principal::anonymous(), method, args)
        .map_err(Failure::Rejected)?)
}
fn action(pic: &PocketIc, id: Principal, method: &str, args: Vec<u8>) -> Result<()> {
    decode_one::<std::result::Result<(), E>>(&update(pic, id, method, args)?)?
        .map_err(Failure::Probe)?;
    Ok(())
}
fn read(pic: &PocketIc, id: Principal, epoch: u64) -> Result<std::result::Result<Snapshot, E>> {
    Ok(decode_one(
        &pic.query_call(
            id,
            Principal::anonymous(),
            "snapshot",
            encode_args((epoch,))?,
        )
        .map_err(Failure::Rejected)?,
    )?)
}
fn expected(id: u8, build: u8, addition: u128) -> Snapshot {
    Snapshot {
        counters: vec![
            (u128::from(u64::MAX) + 5 + addition, false),
            (0, false),
            (u128::MAX, false),
            (u128::MAX, true),
        ],
        existing: vec![2, 7, 7, 2, 7, 7, 2, 7, 1, 1],
        missing: true,
        memory_id: id,
        build,
    }
}
fn main() -> Result<()> {
    let mut args = std::env::args_os().skip(1);
    let (Some(root), Some(output), None) = (args.next(), args.next(), args.next()) else {
        return Err(Failure::Arguments.into());
    };
    let root = PathBuf::from(root);
    let output = PathBuf::from(output);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new()
        .with_application_subnet()
        .try_build(config)?;
    let mut log = fs::File::create(output.join("qualification.tsv"))?;
    writeln!(log, "case\tresult")?;
    let mut states = fs::File::create(output.join("states.txt"))?;
    let wasm = fs::read(root.join("artifacts/initial.wasm"))?;
    let upgrade = fs::read(root.join("artifacts/upgrade.wasm"))?;
    let mut sizes = fs::File::create(output.join("sizes.csv"))?;
    writeln!(
        sizes,
        "variant,raw_wasm_bytes\ninitial,{}\nupgrade,{}",
        wasm.len(),
        upgrade.len()
    )?;
    let id = pic.create_canister();
    pic.add_cycles(id, 100_000_000_000_000);
    pic.install_canister(id, wasm.clone(), encode_args(())?, None);
    check(
        read(&pic, id, 0)? == Err(E::Missing),
        "absent before seed",
        &mut log,
    )?;
    action(&pic, id, "seed", encode_args((0_u64,))?)?;
    let initial = read(&pic, id, 0)?.map_err(Failure::Probe)?;
    writeln!(states, "initial: {initial:?}")?;
    let memory_id = initial.memory_id;
    check(
        initial == expected(memory_id, 0, 0),
        "mixed kinds, wide, zero, exact cap, actual overflow",
        &mut log,
    )?;
    action(&pic, id, "seed", encode_args((0_u64,))?)?;
    check(
        read(&pic, id, 0)? == Ok(initial.clone()),
        "identical checkpoint",
        &mut log,
    )?;
    for (which, error) in [
        (0_u8, E::Regression),
        (1, E::Regression),
        (2, E::Identity),
        (3, E::Identity),
        (4, E::Kind),
    ] {
        let response = decode_one::<std::result::Result<(), E>>(&update(
            &pic,
            id,
            "reject",
            encode_args((which, 0_u64))?,
        )?)?;
        check(
            response == Err(error),
            "typed incompatible checkpoint",
            &mut log,
        )?;
        check(
            read(&pic, id, 0)? == Ok(initial.clone()),
            "rejection preserves all rows",
            &mut log,
        )?;
    }
    let response = pic
        .query_call(
            id,
            Principal::anonymous(),
            "query_append",
            encode_args((0_u64, 9_u64))?,
        )
        .map_err(Failure::Rejected)?;
    check(
        decode_one::<std::result::Result<(), E>>(&response)? == Ok(()),
        "query executes counter write",
        &mut log,
    )?;
    check(
        read(&pic, id, 0)? == Ok(initial.clone()),
        "query counter write discarded",
        &mut log,
    )?;
    check(
        matches!(pic.update_call(id, Principal::anonymous(), "trap_after_write", encode_args((0_u64, 9_u64))?),
        Err(ref e) if e.error_code == ic_testkit::pocket_ic::ErrorCode::CanisterCalledTrap),
        "explicit trap after counter write",
        &mut log,
    )?;
    check(
        read(&pic, id, 0)? == Ok(initial),
        "trapping update rolls counter back",
        &mut log,
    )?;
    pic.upgrade_canister(id, upgrade, encode_args(())?, None)
        .map_err(Failure::Rejected)?;
    check(
        read(&pic, id, 0)? == Ok(expected(memory_id, 1, 0)),
        "first upgrade retains every kind and memory ID",
        &mut log,
    )?;
    action(&pic, id, "append", encode_args((0_u64, 11_u64))?)?;
    check(
        read(&pic, id, 0)? == Ok(expected(memory_id, 1, 11)),
        "continued counter after upgrade",
        &mut log,
    )?;
    pic.upgrade_canister(id, wasm, encode_args(())?, None)
        .map_err(Failure::Rejected)?;
    check(
        read(&pic, id, 0)? == Ok(expected(memory_id, 0, 11)),
        "second upgrade retains continuation and ID",
        &mut log,
    )?;
    writeln!(states, "continued: {:?}", read(&pic, id, 0)?)?;
    action(&pic, id, "reset", encode_args((0_u64,))?)?;
    check(
        read(&pic, id, 0)? == Err(E::Identity),
        "old identity refused after reset",
        &mut log,
    )?;
    check(
        read(&pic, id, 1)? == Ok(expected(memory_id, 0, 0)),
        "explicit reset retains one memory ID",
        &mut log,
    )?;
    writeln!(states, "reset: {:?}", read(&pic, id, 1)?)?;
    // A fresh canister for one complete cost trajectory, outside lifecycle assertions.
    let cost_id = pic.create_canister();
    pic.add_cycles(cost_id, 100_000_000_000_000);
    pic.install_canister(
        cost_id,
        fs::read(root.join("artifacts/initial.wasm"))?,
        encode_args(())?,
        None,
    );
    let mut costs = fs::File::create(output.join("costs.csv"))?;
    writeln!(
        costs,
        "iterations,cadence,repeat,nonce,before,after,instructions,cycles_before,cycles_after,cycles,total"
    )?;
    let mut nonce = 0;
    for iterations in [0_u64, 1, 16, 256] {
        for cadence in [1_u64, 16, 256] {
            for repeat in 0..3 {
                let cycles_before = pic.cycle_balance(cost_id);
                let value = decode_one::<std::result::Result<Measured, E>>(&update(
                    &pic,
                    cost_id,
                    "measure",
                    encode_args((iterations, cadence, nonce))?,
                )?)?
                .map_err(Failure::Probe)?;
                let cycles_after = pic.cycle_balance(cost_id);
                check(
                    value.total == u128::from(iterations) * 7,
                    "cost trajectory exact total",
                    &mut log,
                )?;
                let instructions = value
                    .after
                    .checked_sub(value.before)
                    .ok_or(Failure::Check("instruction identity"))?;
                let cycles = cycles_before
                    .checked_sub(cycles_after)
                    .ok_or(Failure::Check("cycle balance"))?;
                writeln!(
                    costs,
                    "{iterations},{cadence},{repeat},{nonce},{},{},{instructions},{cycles_before},{cycles_after},{cycles},{}",
                    value.before, value.after, value.total
                )?;
                nonce += 1;
            }
        }
    }
    println!("IC durable counter lifecycle and 36 raw cost replies pass");
    Ok(())
}
