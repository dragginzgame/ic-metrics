macro_owner::direct!(Direct);
macro_owner::conditional!(Conditional);
fn main() {
    assert_eq!(Direct(7).clone().0, 7);
    assert_eq!(Conditional(11).clone().0, 11);
    assert_eq!(format!("{:?} {:?}", Direct(7), Conditional(11)), "Direct(7) Conditional(11)");
}
