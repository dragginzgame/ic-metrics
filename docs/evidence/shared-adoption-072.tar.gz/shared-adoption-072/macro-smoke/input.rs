pub mod exports { pub use std::{clone::Clone, fmt::Debug}; }
#[macro_export]
macro_rules! direct { ($name:ident) => {
    #[derive($crate::exports::Debug, $crate::exports::Clone)]
    pub struct $name(pub u64);
}; }
#[macro_export]
macro_rules! conditional { ($name:ident) => {
    #[cfg_attr(all(), derive($crate::exports::Debug, $crate::exports::Clone))]
    pub struct $name(pub u64);
}; }
