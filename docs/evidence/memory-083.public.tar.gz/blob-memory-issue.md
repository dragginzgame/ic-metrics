## Problem

IC Memory 0.36.0 is published at `834fb71b09d84655dc64bd89b6bfb4c0c9b35c9d`. It replaces global registration and borrowed sealing with explicit owned component request lists, and renames declaration failures to `MemoryDeclarationError`. Stable allocation keys, retained IDs and ledger bytes remain unchanged.

Read-only observation of Blob Storage working source over HEAD `de19bbc019fd18dac3206841a404db6b390719e7` selects `ic-memory = "0.35"`. `installation::requests` and `stores::grants::requests` still return `StaticMemoryDeclarationError`; `tests/memory_composition.rs` still calls the global `sealed_declaration_snapshot()` and seals borrowed requests. Other native fixtures also seal borrowed requests. No sibling edits or build acceptance are claimed by this observation.

## Requested integration

- Select Memory 0.36 coherently with the embedding host/framework. Keep one Memory package identity in the deployed composition; Metrics' pending optional stable adapter selects 0.36, while arithmetic-only Metrics remains independent.
- Retain the existing explicit complete installation/store request factories, updating their typed declaration errors. Supply their owned lists to the host's single `SealedDeclarationSnapshot::new(requests)` before runtime bootstrap; opening stores must not register requests or bootstrap again.
- Update native composition and service fixtures to the explicit request contract, retaining the actual allocation inventory, permanent keys, one bootstrap owner and fail-before-write behavior. Do not reset deployed memory.
- Run Blob Storage's own focused native/Wasm checks and advertised Rust-floor gates. Any application/IC acceptance stays with its owning host and exact selected graph.

Related host adoption: [Canic #527](https://github.com/dragginzgame/canic/issues/527), [IcyDB #355](https://github.com/dragginzgame/icydb/issues/355). [Memory migration notes](https://github.com/dragginzgame/ic-memory/blob/v0.36.0/docs/changelog/0.36.md).
