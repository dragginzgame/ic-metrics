#!/usr/bin/env bash
set -euo pipefail
[[ $# == 1 && "$1" == /* ]] || { echo 'usage: replay.sh ABSOLUTE_METRICS_TARGET_DIR' >&2; exit 2; }
root="$(cd "${BASH_SOURCE[0]%/*}" && pwd -P)"
: "${POCKET_IC_BIN:?Prepare PocketIC 16.1.0 explicitly}"
[[ "$(shasum -a 256 "$POCKET_IC_BIN")" == b44e1eccd66e02328146b3e209e3403e3a3428a25d25555aca2f67500e5ae9db* ]]
[[ "$(rustc --version)" == 'rustc 1.99.0 (b940084d7 2026-09-28)' ]]
(cd "$root" && shasum -a 256 -c SHA256SUMS) > /dev/null
mkdir -p "$1"
scratch="$(mktemp -d "$1/governed-store-replay.XXXXXX")"
cp -R "$root/fixture" "$scratch/fixture"
# A fresh target prevents package-name collisions with unrelated experiment drivers.
build="$scratch/build"
for variant in baseline governed; do
    for package in ic-metrics ic-metrics-stable; do
        rm -r "$scratch/fixture/crates/$package/src"
        cp -R "$root/$variant/$package/src" "$scratch/fixture/crates/$package/src"
        find "$scratch/fixture/crates/$package/src" -type f -exec touch {} +
    done
    cargo build --manifest-path "$scratch/fixture/Cargo.toml" --target-dir "$build" --locked --offline --release -p stable-probe --target wasm32-unknown-unknown --features "$variant"
    cmp "$build/wasm32-unknown-unknown/release/stable_probe.wasm" "$root/fixture/$variant.wasm"
done
find "$scratch/fixture/crates/driver/src" "$scratch/fixture/crates/protocol/src" -type f -exec touch {} +
cargo build --manifest-path "$scratch/fixture/Cargo.toml" --target-dir "$build" --locked --offline -p stable-driver
"$build/debug/stable-driver" "$scratch/fixture" "$scratch/results"
cmp "$root/results/run-1/costs.csv" "$scratch/results/costs.csv"
for file in "$root/results/run-1"/*.did; do
    cmp "$file" "$scratch/results/${file##*/}"
done
printf 'Both Wasms, retained records, allocation identity and all raw observations reproduced: %s\n' "$scratch"
