//! Local PocketIC qualification, including retained bytes and reverse reading.
use candid::{Principal, decode_args, encode_args};
use ic_testkit::pic::{PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use std::{error::Error, fs, io::Write, path::PathBuf, time::Duration};
type Reply = (u64, u128, Vec<(Vec<u8>, Vec<u8>)>, u8);
fn main() -> Result<(), Box<dyn Error>> {
    let root = PathBuf::from(std::env::args_os().nth(1).ok_or("root required")?);
    let output = PathBuf::from(std::env::args_os().nth(2).ok_or("output required")?);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?.with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new().with_application_subnet().try_build(config)?;
    let id = pic.create_canister(); pic.add_cycles(id, 100_000_000_000_000);
    pic.install_canister(id, fs::read(root.join("baseline.wasm"))?, encode_args(())?, None);
    pic.update_call(id, Principal::anonymous(), "seed", encode_args(())?).map_err(|e| format!("{e:?}"))?;
    let mut csv = fs::File::create(output.join("costs.csv"))?;
    writeln!(csv, "stage,iterations,repeat,instructions,cycles,sink,memory_id")?;
    let mut original = None;
    let mut appended = None;
    let mut original_id = None;
    for stage in ["baseline", "governed", "appended", "reverse"] {
        if stage == "governed" { pic.upgrade_canister(id, fs::read(root.join("governed.wasm"))?, encode_args(())?, None).map_err(|e| format!("{e:?}"))?; }
        if stage == "appended" { pic.update_call(id, Principal::anonymous(), "append", encode_args(())?).map_err(|e| format!("{e:?}"))?; }
        if stage == "reverse" { pic.upgrade_canister(id, fs::read(root.join("baseline.wasm"))?, encode_args(())?, None).map_err(|e| format!("{e:?}"))?; }
        for iterations in [0_u32, 64] {
            for repeat in 0..3 {
                let balance = pic.cycle_balance(id);
                let reply = pic.update_call(id, Principal::anonymous(), "check", encode_args((iterations,))?).map_err(|e| format!("{e:?}"))?;
                let (instructions, sink, rows, memory_id): Reply = decode_args(&reply)?;
                if stage == "baseline" { original = Some(rows.clone()); original_id = Some(memory_id); }
                if stage == "governed" && original.as_ref() != Some(&rows) { return Err("retained rows changed on upgrade".into()); }
                if stage == "appended" { if original.as_ref() == Some(&rows) { return Err("checkpoint did not change rows".into()); } appended = Some(rows.clone()); }
                if stage == "reverse" && appended.as_ref() != Some(&rows) { return Err("original adapter cannot read governed checkpoint".into()); }
                if original_id != Some(memory_id) { return Err("allocation key moved".into()); }
                writeln!(csv, "{stage},{iterations},{repeat},{instructions},{},{sink},{memory_id}", balance - pic.cycle_balance(id))?;
                fs::write(output.join(format!("{stage}-{iterations}-{repeat}.did")), encode_args((rows, memory_id))?)?;
            }
        }
    }
    Ok(())
}
