//! Isolated IC upgrade/measurement probe; no maintained product endpoint.
use std::{cell::RefCell, hint::black_box};
use ic_memory::{GenericAllocationPolicy, MemoryAllocationPool, MemoryAuthority, MemoryRequest, MemoryRuntime, SealedDeclarationSnapshot, ic_stable_structures::DefaultMemoryImpl};
use ic_metrics::{MeasurementAggregate as Aggregate, MeasurementCounter as Counter, MeasurementHistogram as Histogram, MeasurementSummary as Summary};
use ic_metrics_stable::{MetricIdentity, MetricKey, MetricsMap, MetricsStore};
#[cfg(feature = "baseline")]
type Store = MetricsStore<ic_memory::RuntimeMemory<DefaultMemoryImpl>>;
#[cfg(feature = "governed")]
type Store = MetricsStore<DefaultMemoryImpl>;
const KEY: &str = "probe.metrics.v1";
thread_local! {
    static RUNTIME: RefCell<Option<MemoryRuntime<DefaultMemoryImpl>>> = const { RefCell::new(None) };
    static STORE: RefCell<Option<Store>> = const { RefCell::new(None) };
}
fn with_store<T>(operation: impl FnOnce(&mut Store) -> T) -> T {
    STORE.with(|slot| {
        if slot.borrow().is_none() {
            let mut runtime = MemoryRuntime::new(DefaultMemoryImpl::default()).unwrap();
            let pool = MemoryAllocationPool::new(vec![MemoryAuthority::new("probe", "probe.").unwrap()], vec![]).unwrap();
            let requests = SealedDeclarationSnapshot::new(vec![MemoryRequest::new("probe", KEY).unwrap()]).unwrap();
            runtime.bootstrap(&requests, &pool, &GenericAllocationPolicy).unwrap();
            let map = MetricsMap::init(runtime.open_memory(KEY).unwrap());
            RUNTIME.with(|slot| *slot.borrow_mut() = Some(runtime));
            *slot.borrow_mut() = Some(MetricsStore::new(map));
        }
        operation(slot.borrow_mut().as_mut().unwrap())
    })
}
fn key(name: &str) -> MetricKey { MetricKey::new("probe", name).unwrap() }
fn identity() -> MetricIdentity { MetricIdentity::new("items", 3).unwrap() }
#[ic_cdk::update]
fn seed() {
    with_store(|store| {
        let (mut a, mut s, mut h) = (Aggregate::EMPTY, Summary::EMPTY, Histogram::new([0, 10, u64::MAX]).unwrap());
        for value in [0, u64::MAX] { a.record(value); s.record(value); h.record(value); }
        let id = identity();
        store.save_aggregate(&key("aggregate"), &id, &a).unwrap();
        store.save_summary(&key("summary"), &id, &s).unwrap();
        store.save_histogram(&key("histogram"), &id, &h).unwrap();
        store.save_counter(&key("counter"), &id, &Counter::from_parts(u128::MAX, false).unwrap()).unwrap();
    });
}
#[ic_cdk::update]
fn append() {
    with_store(|store| {
        let id = identity();
        let mut a = store.load_aggregate(&key("aggregate"), &id).unwrap().unwrap(); a.record(1);
        let mut s = store.load_summary(&key("summary"), &id).unwrap().unwrap(); s.record(1);
        let mut h = store.load_histogram(&key("histogram"), &id, &[0, 10, u64::MAX]).unwrap().unwrap(); h.record(1);
        let mut c = store.load_counter(&key("counter"), &id).unwrap().unwrap(); c.add(1);
        store.save_aggregate(&key("aggregate"), &id, &a).unwrap();
        store.save_summary(&key("summary"), &id, &s).unwrap();
        store.save_histogram(&key("histogram"), &id, &h).unwrap();
        store.save_counter(&key("counter"), &id, &c).unwrap();
    });
}
#[ic_cdk::update]
fn check(iterations: u32) -> (u64, u128, Vec<(Vec<u8>, Vec<u8>)>, u8) {
    assert!(iterations <= 128);
    let (instructions, sink) = with_store(|store| {
        let id = identity();
        let keys = [key("aggregate"), key("summary"), key("histogram"), key("counter")];
        let mut sink = 0_u128;
        let start = ic_cdk::api::instruction_counter();
        for _ in 0..iterations {
            let a = black_box(store.load_aggregate(black_box(&keys[0]), black_box(&id)).unwrap().unwrap());
            let s = black_box(store.load_summary(black_box(&keys[1]), black_box(&id)).unwrap().unwrap());
            let h = black_box(store.load_histogram(black_box(&keys[2]), black_box(&id), black_box(&[0, 10, u64::MAX])).unwrap().unwrap());
            let c = black_box(store.load_counter(black_box(&keys[3]), black_box(&id)).unwrap().unwrap());
            sink = sink.wrapping_add(a.total()).wrapping_add(s.aggregate().total()).wrapping_add(h.aggregate().total()).wrapping_add(c.total()).wrapping_add(u128::from(c.total_overflowed()));
            black_box(sink);
        }
        (ic_cdk::api::instruction_counter() - start, sink)
    });
    let rows = STORE.with(|slot| {
        let map = slot.borrow_mut().take().unwrap().into_map();
        let rows = map.iter().map(|entry| entry.into_pair()).collect();
        *slot.borrow_mut() = Some(MetricsStore::new(map));
        rows
    });
    let id = RUNTIME.with(|slot| slot.borrow().as_ref().unwrap().memory_id(KEY).unwrap());
    (instructions, sink, rows, id)
}
