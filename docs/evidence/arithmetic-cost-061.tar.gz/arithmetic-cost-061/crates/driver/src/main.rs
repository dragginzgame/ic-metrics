//! Independent projection oracle and real IC execution for frozen kernels.
use arithmetic_cost_probe::{ProbeError, ProbeReply};
use candid::{Principal, decode_one, encode_args};
use ic_testkit::pic::{PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use std::{error::Error, fmt, fs, io::Write, path::PathBuf, time::Duration};

const VARIANTS: [&str; 11] = [
    "count",
    "old-summary",
    "summary",
    "aggregate",
    "old-histogram",
    "histogram",
    "aggregate-merge",
    "histogram-merge",
    "aggregate-query",
    "histogram-query",
    "histogram-mismatch",
];
#[derive(Debug)]
enum ReplayError {
    Arguments,
    CounterRegression,
    CycleIncrease,
    ProbeRejected,
    Rejected(ic_testkit::pic::RejectResponse),
    Projection {
        expected: [u64; 11],
        actual: [u64; 11],
    },
}
impl fmt::Display for ReplayError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Rejected(r) => write!(f, "IC call rejected: {r:?}"),
            Self::Projection { expected, actual } => {
                write!(f, "expected {expected:?}, got {actual:?}")
            }
            _ => write!(f, "replay failed: {self:?}"),
        }
    }
}
impl Error for ReplayError {}
fn expected(variant: &str, iterations: u32, value: u64) -> [u64; 11] {
    let mut s = [0; 11];
    if variant.ends_with("query") || variant == "histogram-mismatch" {
        s[0] = 5;
        s[1] = 2_110_001;
        s[2] = 1_000_001;
        if variant != "aggregate-query" {
            s[5..10].copy_from_slice(&[1, 1, 1, 1, 1]);
        }
        let per_iteration = match variant {
            "aggregate-query" => 422_000 + 3 + 2_100_001 + 700_000,
            "histogram-query" => 3 + 10_000 + 100_000 + 2 + 1_000_000 + 1,
            _ => 3,
        };
        s[10] = per_iteration * u64::from(iterations);
        return s;
    }
    let count = u64::from(iterations) * if variant.ends_with("merge") { 16 } else { 1 };
    let total = u128::from(count) * u128::from(value);
    s[0] = count;
    s[1] = total.min(u128::from(u64::MAX)) as u64;
    if variant != "count" && count != 0 {
        s[2] = value;
    }
    if matches!(variant, "old-summary" | "summary" | "old-histogram") && count != 0 {
        s[3] = value;
    }
    if !matches!(variant, "count" | "old-summary" | "old-histogram") && total > u128::from(u64::MAX)
    {
        s[4] = 2;
    }
    if variant.contains("histogram") {
        let index = match value {
            0 => 5,
            1..=10_000 => 6,
            10_001..=100_000 => 7,
            100_001..=1_000_000 => 8,
            _ => 9,
        };
        s[index] = count;
    }
    s
}
fn main() -> Result<(), Box<dyn Error>> {
    let mut args = std::env::args_os().skip(1);
    let (Some(directory), Some(output), None) = (args.next(), args.next(), args.next()) else {
        return Err(ReplayError::Arguments.into());
    };
    let directory = PathBuf::from(directory);
    let output = PathBuf::from(output);
    fs::create_dir(&output)?;
    let config = PocketIcStartupConfig::from_env(Duration::from_secs(30))?
        .with_server_output_files(output.join("server.stdout"), output.join("server.stderr"));
    let pic = PocketIcBuilder::new()
        .with_application_subnet()
        .try_build(config)?;
    let mut csv = fs::File::create(output.join("results.csv"))?;
    writeln!(
        csv,
        "variant,phase,value,iterations,repeat,before,after,instructions,cycles_before,cycles_after,cycles,samples,total,maximum,latest,flags,bucket0,bucket1,bucket2,bucket3,overflow,sink"
    )?;
    let mut sizes = fs::File::create(output.join("sizes.csv"))?;
    writeln!(sizes, "variant,raw_wasm_bytes")?;
    let mut validated = 0;
    for variant in VARIANTS {
        let wasm = fs::read(directory.join("artifacts").join(format!("{variant}.wasm")))?;
        writeln!(sizes, "{variant},{}", wasm.len())?;
        let canister = pic.create_canister();
        // Fund before install; installation costs are outside all balance readings.
        pic.add_cycles(canister, 100_000_000_000_000);
        pic.install_canister(canister, wasm, encode_args(())?, None);
        let mut cases = vec![("cold", 0, 1, 0)];
        let values = if variant.ends_with("query") || variant == "histogram-mismatch" {
            vec![0]
        } else {
            vec![0, 10_000, 10_001, 100_000, 1_000_000, 1_000_001, u64::MAX]
        };
        for value in values {
            for iterations in [0, 1, 1_000] {
                for repeat in 0..3 {
                    cases.push(("warm", value, iterations, repeat));
                }
            }
        }
        // Same 16,000 observations as 1,000 merges of a prepared 16-sample batch.
        if matches!(variant, "aggregate" | "histogram") {
            for value in [10_000, 1_000_001] {
                for repeat in 0..3 {
                    cases.push(("matched-batch", value, 16_000, repeat));
                }
            }
        }
        for (phase, value, iterations, repeat) in cases {
            let cycles_before = pic.cycle_balance(canister);
            let response = pic
                .update_call(
                    canister,
                    Principal::anonymous(),
                    "probe",
                    encode_args((iterations, value))?,
                )
                .map_err(ReplayError::Rejected)?;
            let cycles_after = pic.cycle_balance(canister);
            let reply =
                decode_one::<ProbeReply>(&response)?.map_err(|_| ReplayError::ProbeRejected)?;
            let expectation = expected(variant, iterations, value);
            if reply.state != expectation {
                return Err(ReplayError::Projection {
                    expected: expectation,
                    actual: reply.state,
                }
                .into());
            }
            let instructions = reply
                .after
                .checked_sub(reply.before)
                .ok_or(ReplayError::CounterRegression)?;
            let cycles = cycles_before
                .checked_sub(cycles_after)
                .ok_or(ReplayError::CycleIncrease)?;
            write!(
                csv,
                "{variant},{phase},{value},{iterations},{repeat},{},{},{instructions},{cycles_before},{cycles_after},{cycles}",
                reply.before, reply.after
            )?;
            for part in reply.state {
                write!(csv, ",{part}")?;
            }
            writeln!(csv)?;
            validated += 1;
        }
        let response = pic
            .update_call(
                canister,
                Principal::anonymous(),
                "probe",
                encode_args((100_001_u32, 1_u64))?,
            )
            .map_err(ReplayError::Rejected)?;
        if !matches!(
            decode_one::<ProbeReply>(&response)?,
            Err(ProbeError::TooManyIterations)
        ) {
            return Err(ReplayError::ProbeRejected.into());
        }
        writeln!(
            csv,
            "{variant},admission-rejected,1,100001,0,,,,,,,,,,,,,,,,,"
        )?;
    }
    println!("Validated {validated} measured replies and 11 typed admission rejections.");
    Ok(())
}
