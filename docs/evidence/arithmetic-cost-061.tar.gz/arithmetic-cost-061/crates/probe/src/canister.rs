//! One selected arithmetic kernel per independently built canister.
use crate::{ProbeError, ProbeReading, ProbeReply};
use metrics_current::{MeasurementAggregate, MeasurementHistogram, MeasurementSummary};
use std::hint::black_box;

const BOUNDS: [u64; 4] = [0, 10_000, 100_000, 1_000_000];
const VARIANTS: usize = cfg!(feature = "count") as usize
    + cfg!(feature = "old-summary") as usize
    + cfg!(feature = "summary") as usize
    + cfg!(feature = "aggregate") as usize
    + cfg!(feature = "old-histogram") as usize
    + cfg!(feature = "histogram") as usize
    + cfg!(feature = "aggregate-merge") as usize
    + cfg!(feature = "histogram-merge") as usize
    + cfg!(feature = "aggregate-query") as usize
    + cfg!(feature = "histogram-query") as usize
    + cfg!(feature = "histogram-mismatch") as usize;
const _: () = assert!(VARIANTS == 1, "select exactly one experimental kernel");

fn aggregate(a: MeasurementAggregate) -> [u64; 11] {
    let mut out = [0; 11];
    out[0] = a.samples();
    out[1] = a.total();
    out[2] = a.maximum().unwrap_or(0);
    out[4] = u64::from(a.samples_saturated()) | (u64::from(a.total_saturated()) << 1);
    out
}
fn histogram(h: &MeasurementHistogram<4>) -> [u64; 11] {
    let mut out = aggregate(h.aggregate());
    out[5..9].copy_from_slice(h.bucket_counts());
    out[9] = h.overflow();
    for (i, flag) in h.bucket_saturation().iter().enumerate() {
        out[4] |= u64::from(*flag) << (i + 2);
    }
    out[4] |= u64::from(h.overflow_saturated()) << 6;
    out
}
fn current_histogram() -> Result<MeasurementHistogram<4>, ProbeError> {
    MeasurementHistogram::new(BOUNDS).map_err(|_| ProbeError::Arithmetic)
}
fn bounds_range(h: &MeasurementHistogram<4>, n: u64, d: u64) -> Result<u64, ProbeError> {
    let r = h
        .quantile_bucket(black_box(n), black_box(d))
        .map_err(|_| ProbeError::Arithmetic)?
        .ok_or(ProbeError::Arithmetic)?;
    Ok(r.lower_exclusive()
        .unwrap_or(0)
        .wrapping_add(r.upper_inclusive().unwrap_or(0))
        .wrapping_add(u64::from(r.lower_exclusive().is_some()))
        .wrapping_add(u64::from(r.upper_inclusive().is_some())))
}
#[ic_cdk::update]
fn probe(iterations: u32, value: u64) -> ProbeReply {
    if iterations > 100_000 {
        return Err(ProbeError::TooManyIterations);
    }
    let mut raw = [0_u64; 2];
    let mut old_summary = metrics_baseline::MeasurementSummary::EMPTY;
    let mut summary = MeasurementSummary::EMPTY;
    let mut a = MeasurementAggregate::EMPTY;
    let mut old_h =
        metrics_baseline::MeasurementHistogram::new(BOUNDS).map_err(|_| ProbeError::Arithmetic)?;
    let mut h = current_histogram()?;
    let mut batch = MeasurementAggregate::EMPTY;
    let mut histogram_batch = current_histogram()?;
    for _ in 0..16 {
        batch.record(value);
        histogram_batch.record(value);
    }
    let mut previous = MeasurementAggregate::EMPTY;
    if cfg!(feature = "aggregate-query")
        || cfg!(feature = "histogram-query")
        || cfg!(feature = "histogram-mismatch")
    {
        for (i, v) in [0, 10_000, 100_000, 1_000_000, 1_000_001]
            .into_iter()
            .enumerate()
        {
            a.record(v);
            h.record(v);
            if i == 1 {
                previous = a;
            }
        }
    }
    let mismatch = MeasurementHistogram::new([0, 10_000, 100_000, 1_000_001])
        .map_err(|_| ProbeError::Arithmetic)?;
    let mut sink = 0_u64;
    let before = ic_cdk::api::call_context_instruction_counter();
    for _ in 0..iterations {
        if cfg!(feature = "count") {
            let [samples, total] = &mut raw;
            metrics_current::record_sample(samples, total, black_box(value));
        }
        if cfg!(feature = "old-summary") {
            old_summary.record(black_box(value));
        }
        if cfg!(feature = "summary") {
            summary.record(black_box(value));
        }
        if cfg!(feature = "aggregate") {
            a.record(black_box(value));
        }
        if cfg!(feature = "old-histogram") {
            old_h.record(black_box(value));
        }
        if cfg!(feature = "histogram") {
            h.record(black_box(value));
        }
        if cfg!(feature = "aggregate-merge") {
            a.merge(black_box(batch));
        }
        if cfg!(feature = "histogram-merge") {
            h.merge(black_box(&histogram_batch))
                .map_err(|_| ProbeError::Arithmetic)?;
        }
        if cfg!(feature = "aggregate-query") {
            let mean = black_box(a)
                .mean()
                .map_err(|_| ProbeError::Arithmetic)?
                .ok_or(ProbeError::Arithmetic)?;
            let interval = black_box(a)
                .interval_since(black_box(previous))
                .map_err(|_| ProbeError::Arithmetic)?;
            let interval_mean = interval.mean().ok_or(ProbeError::Arithmetic)?;
            sink = sink
                .wrapping_add(mean)
                .wrapping_add(interval.samples())
                .wrapping_add(interval.total())
                .wrapping_add(interval_mean);
        }
        if cfg!(feature = "histogram-query") {
            let count = black_box(&h)
                .cumulative_count(black_box(2))
                .map_err(|_| ProbeError::Arithmetic)?;
            sink = sink
                .wrapping_add(count)
                .wrapping_add(bounds_range(black_box(&h), 1, 2)?)
                .wrapping_add(bounds_range(black_box(&h), 95, 100)?);
        }
        if cfg!(feature = "histogram-mismatch") {
            match h.merge(black_box(&mismatch)) {
                Err(e) if e.index() == 3 => {
                    sink = sink.wrapping_add(3);
                }
                _ => return Err(ProbeError::Arithmetic),
            }
        }
    }
    let after = ic_cdk::api::call_context_instruction_counter();
    let mut state = if cfg!(feature = "count") {
        let mut s = [0; 11];
        s[..2].copy_from_slice(&raw);
        s
    } else if cfg!(feature = "old-summary") || cfg!(feature = "old-histogram") {
        let old = if cfg!(feature = "old-summary") {
            old_summary
        } else {
            old_h.summary()
        };
        let mut s = [0; 11];
        s[0] = old.samples();
        s[1] = old.total();
        s[2] = old.maximum().unwrap_or(0);
        s[3] = old.latest().unwrap_or(0);
        if cfg!(feature = "old-histogram") {
            s[5..9].copy_from_slice(old_h.bucket_counts());
            s[9] = old_h.overflow();
        }
        s
    } else if cfg!(feature = "summary") {
        let mut s = aggregate(summary.aggregate());
        s[3] = summary.latest().unwrap_or(0);
        s
    } else if cfg!(feature = "aggregate")
        || cfg!(feature = "aggregate-merge")
        || cfg!(feature = "aggregate-query")
    {
        aggregate(a)
    } else {
        histogram(&h)
    };
    state[10] = sink;
    Ok(ProbeReading {
        before,
        after,
        state,
    })
}
