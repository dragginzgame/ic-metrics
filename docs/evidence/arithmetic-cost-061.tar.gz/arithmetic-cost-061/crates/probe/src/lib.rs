//! Wire types for a frozen IC arithmetic experiment, not a product endpoint.
#[cfg(target_arch = "wasm32")]
mod canister;
/// Admission or arithmetic failure in the private experiment.
#[derive(candid::CandidType, serde::Deserialize, Debug)]
pub enum ProbeError {
    /// Maximum admitted iteration count was exceeded before measurement.
    TooManyIterations,
    /// An expected valid arithmetic operation failed.
    Arithmetic,
}
/// Raw IC readings and independently checked arithmetic state.
#[derive(candid::CandidType, serde::Deserialize, Debug)]
pub struct ProbeReading {
    /// Counter immediately before the workload.
    pub before: u64,
    /// Counter immediately after the workload.
    pub after: u64,
    /// Samples, total, maximum, latest, overflow flags, four buckets, overflow, sink.
    pub state: [u64; 11],
}
/// Typed result; failed admission performs no measured workload.
pub type ProbeReply = Result<ProbeReading, ProbeError>;
