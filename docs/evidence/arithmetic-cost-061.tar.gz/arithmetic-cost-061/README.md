# Frozen 0.6.1 IC arithmetic cost experiment

This is a retained experimental artifact, not a maintained member of the Metrics
workspace, a runtime dependency, a product reader or a CI gate. Its independent
virtual root owns the complete catalog/lock for its copied source and private
probe/driver. The maintainer selected this one-off actual IC experiment. Do not
update its source, graph or server to replay a later version under this identity.
The source-less packages are owned inside this artifact; no sibling path
package is used. There are no package support-floor claims for this experiment.
Rust 1.99.0 is its frozen compiler, not the arithmetic library's MSRV.

`crates/baseline/src` is byte-exact released Metrics 0.5.6
392d1e2cbffb434dea591df8cb3165e8c625ab01; `crates/current/src` is released 0.6.1
39b357eb4e53051b5ad9afcfcd0a8c147c68a524. Only the private manifests rename the
copies and inherit this artifact's metadata. `inputs/seed.lock` is a captured
Backup lock; `graph-admission.txt` compares all 293 retained external identities.
It is a dependency-selection seed, not Backup source or consumer qualification.
`metadata.json` records original resolution paths, not replay directory choices.

The fixed four bounds are [0, 10,000, 100,000, 1,000,000]. Every update starts
with fresh local state. Initial construction, a prepared 16-observation batch,
query seed and mismatch source are outside the instruction bracket. The bracket
contains the selected kernel loop, runtime black boxes, result/error handling
and checksum arithmetic. Projection and Candid encoding are outside it. All
count/total/max/latest/flag/bucket writes are projected and independently checked.
Query seeds are [0, 10,000, 100,000, 1,000,000, 1,000,001]. Aggregate query cohorts
perform mean, interval_since the two-observation prefix and interval mean;
histogram cohorts perform cumulative_count(2), p50 and p95 range projections.
Quantile fractions and references are black-boxed. Mismatch merges must reject
index 3 and leave the preseeded destination projection unchanged.

The host checks integer projections using u128 oracle arithmetic, counter
monotonicity and actual cycle-balance decreases. Whole-update cycles include
setup, projection, Candid and execution fees; they are separate observed values,
not a conversion of bracketed instructions. Each canister receives an additional 100
trillion cycles before install; the CSV retains the actual measured balances.
No mainnet spending, consumer attribution, native timing or callback behavior is
claimed. Old histograms retain latest; new histograms retain actual-overflow
provenance. Numeric comparison is not same-contract optimization evidence.

`final-1` and `final-2` contain two finalized, byte-identical CSVs: 554 measured
replies and 11 typed iteration-limit
rejections. Every warm matrix case is repeated three times. `run-1` and `run-2`
retain the preliminary 542-reply matrix, before adding matched 16,000-record
cases; `inputs/driver-initial.rs` is that driver's exact source. Their CSVs agree
byte-for-byte; their canister Wasms are the same final frozen Wasms. `final-2` is a fresh-extraction
rebuild and replay: all 11 rebuilt Wasms and both result/size CSVs agree byte-for-byte.
`logs/fresh-replay.log` and `inputs/final-verification.txt` retain the checks. Zero-loop
controls, cold observations, one-sample exact caps and 1,000-sample overflow are
retained independently; do not divide or subtract them into a universal cost.
The bounded workload does not reach sample-count or bucket-count overflow.

IC Testkit 0.33.3 owns fallible startup and admission; PocketIC client/server
16.1.0, CDK 0.20.3 and Candid 0.10.37 are locked. The original read-only
`ic-testkit-server check --directory ...` succeeded; `inputs/server-check.log`
and `server-path.txt` retain that receipt. `server-sha256.txt` binds the CLI
executable used, server executable and official archive. It does not prove the
CLI was built from the current dirty sibling source. No sibling was modified
or built. Replays require the exact server payload hash, not merely any stable
16.x version accepted by the Testkit API.

From an extracted archive, verify all payloads before compiling. Supply an
explicit server prepared/admitted by IC Testkit's owning setup/check contract,
with the executable hash recorded here. The script never installs anything.
Use the Metrics repository's target/ for builds and a new result directory;
source caches must already be prepared for this exact lock. Missing cache,
changed compiler/server, source corruption, nonidentical rebuilds, mismatched
projections or changed raw results fail; no online fallback is attempted.

```sh
# From the extracted arithmetic-cost-061 directory:
sha256sum -c inputs.sha256
export POCKET_IC_BIN=/absolute/path/to/admitted/pocket-ic
unset IC_TESTKIT_POCKET_IC_URL
bash replay.sh /absolute/metrics/target/evidence/cost-061/rebuild \
  /absolute/metrics/target/evidence/cost-061/new-results
```

Release profile: opt-level=z, LTO, one codegen unit, stripped symbols, panic abort.
No Wasm postprocessing. All final probe variants and the driver pass warning-denied
Clippy, inherited manifest ordering and selected-package formatting. Root
arithmetic, locks, pins and package versions are separately checked unchanged.
The server is deliberately not included: its official archive and binary hashes
identify the explicit owner-prepared executable required for replay.

Zero-loop controls have variable whole-update cycle deltas on some repeats,
while bracketed instruction deltas agree. These exact trajectories reproduce
in both complete runs. `inputs/control-variations.json` preserves the affected
cases; 1, 1,000 and 16,000-iteration repeats agree on both deltas.
