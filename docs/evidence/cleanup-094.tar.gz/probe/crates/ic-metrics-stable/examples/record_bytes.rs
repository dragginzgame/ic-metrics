//! Native paired V1 byte comparison; not IC performance evidence.
use ic_memory::ic_stable_structures::{BTreeMap, VectorMemory};
use ic_metrics::{MeasurementAggregate as Aggregate, MeasurementSummary as Summary, MeasurementHistogram as Histogram};
use ic_metrics_stable::{DurableMetric, MetricIdentity, MetricKey, MetricsStore};

fn row<T: DurableMetric>(name: &str, value: &T) {
    let mut store = MetricsStore::new(BTreeMap::init(VectorMemory::default()));
    let identity = MetricIdentity::new(&"x".repeat(64), u64::MAX).unwrap();
    let key = MetricKey::new("qualification", name).unwrap();
    store.save(&key, &identity, value).unwrap();
    let map = store.into_map();
    let bytes = map.get(&format!("qualification\0{name}").into_bytes()).unwrap();
    print!("{name}\t");
    for byte in bytes { print!("{byte:02x}"); }
    println!();
}

fn main() {
    row("aggregate-empty", &Aggregate::EMPTY);
    let mut aggregate = Aggregate::EMPTY;
    aggregate.record(0);
    row("aggregate-zero", &aggregate);
    aggregate.record(u64::MAX);
    aggregate.record(u64::MAX);
    row("aggregate-wide", &aggregate);
    let overflowed = Aggregate::from_parts(u64::MAX, u128::MAX, Some(u64::MAX), true, true).unwrap();
    row("aggregate-overflowed", &overflowed);
    row("summary-empty", &Summary::EMPTY);
    let mut summary = Summary::EMPTY;
    summary.record(0);
    row("summary-zero", &summary);
    summary.record(9);
    summary.record(u64::MAX);
    row("summary-latest", &summary);
    row("summary-overflowed", &Summary::from_parts(overflowed, Some(u64::MAX)).unwrap());
    let mut zero = Histogram::new([]).unwrap();
    zero.record(0);
    row("histogram-zero-bounds", &zero);
    row("histogram-overflowed", &Histogram::from_parts([], [], u64::MAX, [], true, overflowed).unwrap());
    let mut one = Histogram::new([0]).unwrap();
    one.record(0);
    one.record(u64::MAX);
    row("histogram-one-bound", &one);
    let mut many = Histogram::new(std::array::from_fn::<_, 256, _>(|i| i as u64)).unwrap();
    for value in [0, 127, 255, 256, u64::MAX] { many.record(value); }
    row("histogram-max-bounds", &many);
}
